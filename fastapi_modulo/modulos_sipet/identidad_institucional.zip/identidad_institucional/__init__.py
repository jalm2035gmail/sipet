"""Modulo identidad_institucional."""
