from __future__ import annotations

from functools import lru_cache
from typing import Dict, List

from fastapi import Request

from fastapi_modulo.core.module_registry import get_active_app_access_names, get_active_module_keys, is_module_enabled, list_modules_payload
from fastapi_modulo.modulos_sipet.web.servicios.access_service import (
    get_user_app_access,
    get_user_screen_access_levels,
    is_admin_or_superadmin,
    is_superadmin,
)
from fastapi_modulo.modulos_sipet.web.servicios.icon_catalog_service import resolve_module_icon


@lru_cache(maxsize=1)
def _cached_modules_payload() -> tuple[dict, ...]:
    return tuple(list_modules_payload())


def invalidate_module_catalog_cache() -> None:
    _cached_modules_payload.cache_clear()


def _screen_access_enabled(entry: object) -> bool:
    if isinstance(entry, bool):
        return entry
    if not isinstance(entry, dict):
        return False
    return any(
        bool(entry.get(level_key, False))
        for level_key in ("full_access", "read_only", "department_only", "user_only", "special_permissions")
    )


def _has_capacitacion_role_assignment(request: Request) -> bool:
    if is_admin_or_superadmin(request):
        return True
    access_levels = get_user_screen_access_levels(request)
    for key in ("capacitacion", "Capacitacion", "Capacitación"):
        if _screen_access_enabled(access_levels.get(key)):
            return True
    for key, value in access_levels.items():
        if str(key or "").strip().lower().startswith("capacitacion.") and _screen_access_enabled(value):
            return True
    return False


def build_sidebar_modules(request: Request) -> List[Dict[str, str]]:
    user_access = set(get_user_app_access(request))
    superadmin = is_superadmin(request)
    tenant_key = str(getattr(request.state, "tenant_key", "") or "")
    sidebar_modules: List[Dict[str, str]] = []
    for item in _cached_modules_payload():
        key = str(item.get("key") or "").strip()
        route = str(item.get("route") or "").strip()
        if not route:
            continue
        if not is_module_enabled(key, tenant_key=tenant_key or None):
            continue
        if not bool(item.get("sidebar_visible")) and not (key in ("system_admin", "backend") and superadmin):
            continue
        if key in ("system_admin", "backend") and not superadmin:
            continue
        if key == "capacitacion" and not _has_capacitacion_role_assignment(request):
            continue
        app_access_name = str(item.get("app_access_name") or "").strip()
        if app_access_name and not superadmin and app_access_name not in user_access:
            continue
        sidebar_modules.append(
            {
                "key": key,
                "label": str(item.get("label") or key),
                "route": route,
                "icon": resolve_module_icon(key, str(item.get("icon") or "")),
                "icon_url": "" if key in {"multiempresa", "empresa"} else str(item.get("icon_url") or ""),
                "route_match": "exact" if key == "brujula" else "",
                "sequence": str(item.get("sequence") or ""),
            }
        )
    return sidebar_modules


def get_backend_catalog_context(request: Request) -> dict:
    modules_payload = list(_cached_modules_payload())
    return {
        "user_app_access": get_user_app_access(request),
        "active_module_keys": get_active_module_keys(),
        "modules_payload": modules_payload,
        "modules_payload_map": {item["key"]: item for item in modules_payload},
        "sidebar_modules": build_sidebar_modules(request),
        "active_system_modules": get_active_app_access_names(),
    }
