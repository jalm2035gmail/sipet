from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse, RedirectResponse

from fastapi_modulo.core import tenant_context
from fastapi_modulo.core.database_router import can_connect_current_database
from fastapi_modulo.modulos_sipet.web.servicios.access_service import get_user_screen_access_levels, has_screen_access
from fastapi_modulo.modulos_sipet.web.servicios.session_service import (
    AUTH_COOKIE_NAME,
    AUTH_COOKIE_SECRET,
    CSRF_PROTECTION_ENABLED,
    clear_auth_cookies,
    is_same_origin_request,
    is_session_bound_to_request,
    normalize_tenant_id,
    read_session_cookie,
    validate_csrf_request,
)
from fastapi_modulo.modulos_sipet.web.servicios.template_context_service import build_not_found_context

SETUP_AUTH_COOKIE_NAME = "sipet_setup_auth"
DEFAULT_SETUP_USERNAME_B64 = "MGtvbm9taXlha2k="

PUBLIC_PATHS = {
    "/",
    "/backend",
    "/backend/descripcion",
    "/backend/funcionalidades",
    "/backend/404",
    "/backend/login",
    "/logout",
    "/health",
    "/healthz",
    "/favicon.ico",
    "/manifest.webmanifest",
    "/sw.js",
    "/offline",
    "/api/ajustes/pwa/logo",
    "/api/backend/me",
    "/tiendas",
    "/tiendas/",
    "/multitienda/tiendas",
    "/multitienda/tiendas/",
    "/multitienda/public/tiendas",
}


def _path_analytics_context(path: str) -> dict[str, str]:
    cleaned = str(path or "").strip("/")
    parts = [part for part in cleaned.split("/") if part]
    screen_name = "/" + cleaned if cleaned else "/"
    module_name = "backend"
    if parts:
        if parts[0] == "backend" and len(parts) > 1:
            module_name = parts[1]
        elif parts[0] not in {"api", "backend"}:
            module_name = parts[0]
    return {"module_name": module_name, "screen_name": screen_name}


def is_public_backend_path(request: Request, path: str) -> bool:
    enable_api_docs = (request.app.docs_url is not None) if getattr(request, "app", None) else False
    public_paths = set(PUBLIC_PATHS)
    if enable_api_docs:
        public_paths.update({"/docs", "/redoc", "/openapi.json"})
    if getattr(request.app.state, "database_setup_required", False):
        if path.startswith("/base_datos/") or path.startswith("/api/base_datos/"):
            return True
    frontend_public = False
    if not getattr(request.app.state, "database_setup_required", False):
        try:
            frontend_public = __import__(
                "fastapi_modulo.modulos_sipet.frontend.controladores.frontend",
                fromlist=["_is_public_frontend_page_path"],
            )._is_public_frontend_page_path(path)
        except Exception:
            frontend_public = False
    return bool(
        request.method == "OPTIONS"
        or path in public_paths
        or path == "/web"
        or path == "/web/"
        or path.startswith("/web/")
        or frontend_public
        or path.startswith("/api/public/")
        or path.startswith("/backend/passkey/")
        or path.startswith("/identidad-institucional")
        or path.startswith("/templates/")
        or path.startswith("/static/")
        or path.startswith("/icon/")
        or path.startswith("/imagenes/")
        or path.startswith("/modulos_sipet/")
        or path.startswith("/docs/")
        or path.startswith("/redoc/")
    )


def _screen_access_denied(request: Request, path: str) -> bool:
    if path.startswith("/api/"):
        return False
    analytics_context = _path_analytics_context(path)
    access_levels = get_user_screen_access_levels(request)
    if not access_levels:
        return False
    if analytics_context["screen_name"] in {"/", "/inicio"}:
        return False
    return not has_screen_access(request, analytics_context["screen_name"], app_name=analytics_context["module_name"])


def _decode_b64(value: str) -> str:
    import base64

    return base64.b64decode(value.encode("utf-8")).decode("utf-8")


def request_env(name: str) -> str:
    import os

    return str(os.environ.get(name) or "")


def _setup_username() -> str:
    return (request_env("SYSTEM_SUPERADMIN_USERNAME") or _decode_b64(DEFAULT_SETUP_USERNAME_B64)).strip()


def _is_setup_authenticated_request(request: Request) -> bool:
    import hashlib
    import hmac

    token = str(request.cookies.get(SETUP_AUTH_COOKIE_NAME) or "").strip()
    if "." not in token:
        return False
    payload, signature = token.rsplit(".", 1)
    expected = hmac.new(
        AUTH_COOKIE_SECRET.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(signature, expected) and payload == _setup_username()


def _record_screen_view_async(
    request: Request,
    session_data: dict,
    path: str,
) -> None:
    try:
        from fastapi_modulo.modulos_sipet.web.servicios.audit_service import record_security_event

        analytics_context = _path_analytics_context(path)
        record_security_event(
            request,
            "screen_view",
            username=session_data["username"],
            metadata={
                "path": path,
                "role": session_data["role"],
                "module_name": analytics_context["module_name"],
                "screen_name": analytics_context["screen_name"],
            },
        )
    except Exception:
        pass


async def enforce_backend_login(request: Request, call_next):
    binding = None
    if getattr(request.state, "tenant_context", None) is None:
        binding = tenant_context.bind_request_tenant_context(request)
    path = request.url.path
    setup_public_prefixes = (
        "/base_datos",
        "/api/base_datos",
        "/static/",
        "/templates/",
        "/icon/",
        "/modulo_base/static/",
        "/modulos_sipet/",
        "/health",
        "/healthz",
        "/docs/",
        "/redoc/",
    )

    setup_allowed_path = any(path == prefix.rstrip("/") or path.startswith(prefix) for prefix in setup_public_prefixes)
    if not setup_allowed_path:
        request_host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.hostname
        ok, error = can_connect_current_database(request_host)
        if ok:
            request.app.state.database_setup_required = False
            request.app.state.database_setup_error = ""
        else:
            request.app.state.database_setup_required = True
            request.app.state.database_setup_error = str(error or "Base de datos no inicializada")

    if getattr(request.app.state, "database_setup_required", False):
        if not setup_allowed_path:
            try:
                return RedirectResponse(url="/base_datos/inicializar", status_code=303)
            finally:
                if binding is not None:
                    tenant_context.reset_request_tenant_context(binding)

    if is_public_backend_path(request, path):
        try:
            return await call_next(request)
        finally:
            if binding is not None:
                tenant_context.reset_request_tenant_context(binding)

    if _is_setup_authenticated_request(request) and (
        path.startswith("/base_datos/") or path.startswith("/api/base_datos/")
    ):
        try:
            return await call_next(request)
        finally:
            if binding is not None:
                tenant_context.reset_request_tenant_context(binding)

    session_data = read_session_cookie(request.cookies.get(AUTH_COOKIE_NAME, ""))
    if session_data and not is_session_bound_to_request(request, session_data):
        session_data = None
    if not session_data:
        try:
            if path.startswith("/api/") or path.startswith("/guardar-colores"):
                return JSONResponse({"success": False, "error": "No autenticado"}, status_code=401)
            return RedirectResponse(url="/backend/login", status_code=303)
        finally:
            if binding is not None:
                tenant_context.reset_request_tenant_context(binding)

    try:
        request.state.user_name = session_data["username"]
        request.state.user_role = session_data["role"]
        request.state.tenant_id = normalize_tenant_id(session_data.get("tenant_id"))

        try:
            from fastapi_modulo.modulos_sipet.web.servicios import auth_service

            session_db = auth_service.get_session_local()()
            try:
                if not auth_service.is_password_fingerprint_valid(
                    session_db,
                    session_data["username"],
                    str(session_data.get("password_fingerprint") or ""),
                ):
                    response = RedirectResponse(url="/backend/login", status_code=303)
                    clear_auth_cookies(response)
                    return response
            finally:
                session_db.close()
        except Exception:
            pass

        if (
            CSRF_PROTECTION_ENABLED
            and request.method in {"POST", "PUT", "PATCH", "DELETE"}
            and not path.startswith("/backend/passkey/")
            and not path.startswith("/identidad-institucional")
        ):
            # Evita consumir bodies multipart same-origin en middleware.
            # La validación basada en token se mantiene para requests cross-origin.
            csrf_ok = is_same_origin_request(request)
            if not csrf_ok:
                csrf_ok = await validate_csrf_request(request)
            if not csrf_ok:
                if path.startswith("/api/") or path.startswith("/guardar-colores"):
                    return JSONResponse({"success": False, "error": "CSRF validation failed"}, status_code=403)
                from fastapi_modulo.modulos_sipet.web.servicios.template_service import get_templates

                return get_templates(request).TemplateResponse(
                    "not_found.html",
                    build_not_found_context(request, title="Solicitud no válida"),
                    status_code=403,
                )

        if _screen_access_denied(request, path):
            if path.startswith("/api/"):
                return JSONResponse({"success": False, "error": "Sin permisos para esta pantalla"}, status_code=403)
            from fastapi_modulo.modulos_sipet.web.servicios.template_service import render_no_access_module_page

            return render_no_access_module_page(
                request,
                title="Sin acceso",
                description="No tienes permisos para esta pantalla",
                message="Sin acceso a esta pantalla, consulte con el administrador",
            )

        response = await call_next(request)

        if request.method == "GET" and not path.startswith("/api/") and response.status_code < 400:
            _record_screen_view_async(request, session_data, path)

        return response

    finally:
        if binding is not None:
            tenant_context.reset_request_tenant_context(binding)
