from __future__ import annotations

import json
import os
import re
from pathlib import Path

from fastapi import APIRouter, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import Column, DateTime, Integer, MetaData, String, Table, Text, func, insert, select, text
from fastapi_modulo.modulos.multitienda.marketplace.backend.core.db import SessionLocal


BACKEND_ROOT_PATH = os.getenv("BACKEND_ROOT_PATH", "")
BACKEND_ROUTE_PREFIX = os.getenv("BACKEND_ROUTE_PREFIX", "").rstrip("/")
if BACKEND_ROUTE_PREFIX and not BACKEND_ROUTE_PREFIX.startswith("/"):
    BACKEND_ROUTE_PREFIX = f"/{BACKEND_ROUTE_PREFIX}"

PROJECT_ROOT = Path(__file__).resolve().parents[1]
STATIC_DIR = PROJECT_ROOT / "static"

marketplace_router = APIRouter()
_business_type_metadata = MetaData()
store_business_types = Table(
    "store_business_types",
    _business_type_metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("name", String(160), nullable=False),
    Column("code", String(40), nullable=False, unique=True, index=True),
    Column("description", Text, nullable=False, default=""),
    Column("created_at", DateTime, nullable=False, server_default=func.now()),
)


def _ensure_business_types_schema(bind) -> None:
    _business_type_metadata.create_all(bind=bind, tables=[store_business_types], checkfirst=True)


def bootstrap_business_types_schema(bind=None) -> None:
    target_bind = bind or SessionLocal.kw["bind"] if hasattr(SessionLocal, "kw") else None
    if target_bind is None:
        db = SessionLocal()
        try:
            target_bind = db.bind
        finally:
            db.close()
    _ensure_business_types_schema(target_bind)


def _default_business_types() -> list[dict[str, str]]:
    return [
        {"name": "Restaurante", "code": "REST", "description": "Negocios de alimentos y bebidas."},
        {"name": "Moda", "code": "MODA", "description": "Ropa, calzado y accesorios."},
        {"name": "Ferretería", "code": "FERR", "description": "Herramientas y materiales para construcción."},
    ]


def _list_business_types(db) -> list[dict[str, str]]:
    rows = db.execute(
        select(
            store_business_types.c.id,
            store_business_types.c.name,
            store_business_types.c.code,
            store_business_types.c.description,
        ).order_by(store_business_types.c.name.asc())
    ).mappings().all()
    if rows:
        return [dict(row) for row in rows]
    defaults = _default_business_types()
    db.execute(insert(store_business_types), defaults)
    db.commit()
    seeded = db.execute(
        select(
            store_business_types.c.id,
            store_business_types.c.name,
            store_business_types.c.code,
            store_business_types.c.description,
        ).order_by(store_business_types.c.name.asc())
    ).mappings().all()
    return [dict(row) for row in seeded]


def _slugify_store_name(value: str) -> str:
    raw = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower()).strip("-")
    return raw or "tienda"


def _serialize_store_theme(theme: dict) -> str:
    return json.dumps(theme, ensure_ascii=True)


def _deserialize_store_theme(raw_value) -> dict:
    current = raw_value
    for _ in range(3):
        if isinstance(current, dict):
            return current
        if not isinstance(current, str):
            return {}
        try:
            current = json.loads(current)
        except json.JSONDecodeError:
            return {}
    return {}


@marketplace_router.post(f"{BACKEND_ROUTE_PREFIX}/admin/store-settings")
async def save_store_settings(request: Request, payload_override: dict | None = None):
    payload = payload_override if isinstance(payload_override, dict) else await request.json()
    store_name = str(payload.get("store_name") or "").strip()
    admin_id_raw = str(payload.get("admin_user_id") or "").strip()
    store_id_raw = str(payload.get("store_id") or "").strip()
    is_edit = bool(payload.get("is_edit", False))
    if not store_name:
        raise HTTPException(status_code=422, detail="Store name is required")
    if not admin_id_raw:
        raise HTTPException(status_code=422, detail="Admin user is required")
    try:
        admin_user_id = int(admin_id_raw)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail="Admin user is invalid") from exc

    db = SessionLocal()
    try:
        admin_user = db.execute(
            text("SELECT id FROM users WHERE id = :admin_user_id LIMIT 1"),
            {"admin_user_id": admin_user_id},
        ).first()
        if not admin_user:
            raise HTTPException(status_code=404, detail="Admin user not found")

        store = None
        if is_edit:
            if not store_id_raw:
                raise HTTPException(status_code=422, detail="Falta el identificador de la tienda a editar.")
            try:
                store_id = int(store_id_raw)
            except ValueError as exc:
                raise HTTPException(status_code=422, detail="El identificador de la tienda es inválido.") from exc
            store = db.execute(
                text(
                    """
                    SELECT id, vendor_id, store_name, store_slug, store_theme, is_featured, is_active
                    FROM vendors
                    WHERE id = :store_id
                    LIMIT 1
                    """
                ),
                {"store_id": store_id},
            ).mappings().first()
            if not store:
                raise HTTPException(status_code=404, detail="No se encontró la tienda a editar.")
            conflicting_store = db.execute(
                text(
                    """
                    SELECT id, store_name
                    FROM vendors
                    WHERE vendor_id = :admin_user_id
                      AND id <> :store_id
                    LIMIT 1
                    """
                ),
                {"admin_user_id": admin_user_id, "store_id": store_id},
            ).mappings().first()
            if conflicting_store:
                raise HTTPException(
                    status_code=409,
                    detail=f"El administrador seleccionado ya tiene una tienda asignada: {conflicting_store['store_name'] or 'Sin nombre'}. Usa otro usuario o edita esa tienda.",
                )
        else:
            store = db.execute(
                text(
                    """
                    SELECT id, vendor_id, store_name, store_slug, store_theme, is_featured, is_active
                    FROM vendors
                    WHERE vendor_id = :admin_user_id
                    LIMIT 1
                    """
                ),
                {"admin_user_id": admin_user_id},
            ).mappings().first()
        if store and not is_edit:
            raise HTTPException(
                status_code=409,
                detail=f"El usuario seleccionado ya tiene una tienda asignada: {store['store_name'] or 'Sin nombre'}. No puede tener dos tiendas.",
            )
        theme = _deserialize_store_theme(store["store_theme"]) if store else {}
        theme.update(
            {
                "store_type": str(payload.get("store_type") or "").strip(),
                "store_type_name": str(payload.get("store_type_name") or payload.get("store_type_label") or "").strip(),
                "membership": str(payload.get("membership") or "").strip(),
                "inventory_enabled": bool(payload.get("inventory_enabled", False)),
                "validity": str(payload.get("validity") or "").strip(),
                "referrals": str(payload.get("referrals") or "").strip(),
                "fidelizacion": str(payload.get("fidelizacion") or "").strip(),
                "pwa_notifications": str(payload.get("pwa_notifications") or "").strip(),
                "appointments": str(payload.get("appointments") or "").strip(),
                "coupons": str(payload.get("coupons") or "").strip(),
                "whatsapp": str(payload.get("whatsapp") or "").strip(),
                "max_internal_users": max(0, int(payload.get("max_internal_users") or 0)),
                "max_portal_users": max(0, int(payload.get("max_portal_users") or 0)),
                "can_upload_videos": bool(payload.get("can_upload_videos", False)),
                "can_use_providers": bool(payload.get("can_use_providers", False)),
                "can_use_ai": bool(payload.get("can_use_ai", False)),
                "can_use_financial": bool(payload.get("can_use_financial", False)),
                "can_use_layaway": bool(payload.get("can_use_layaway", False)),
                "can_use_auctions": bool(payload.get("can_use_auctions", False)),
            }
        )

        if store is None:
            base_slug = _slugify_store_name(store_name)
            slug = base_slug
            suffix = 2
            while db.execute(
                text("SELECT 1 FROM vendors WHERE store_slug = :slug LIMIT 1"),
                {"slug": slug},
            ).first():
                slug = f"{base_slug}-{suffix}"
                suffix += 1
            created = db.execute(
                text(
                    """
                    INSERT INTO vendors (
                        vendor_id, store_name, store_slug, store_theme, is_featured, status, is_active
                    ) VALUES (
                        :vendor_id, :store_name, :store_slug, :store_theme, :is_featured, :status, :is_active
                    )
                    RETURNING id, vendor_id, store_name
                    """
                ),
                {
                    "vendor_id": admin_user_id,
                    "store_name": store_name,
                    "store_slug": slug,
                    "store_theme": _serialize_store_theme(theme),
                    "is_featured": bool(payload.get("is_featured", False)),
                    "status": "approved" if bool(payload.get("is_active", True)) else "pending",
                    "is_active": bool(payload.get("is_active", True)),
                },
            ).mappings().first()
        else:
            db.execute(
                text(
                    """
                    UPDATE vendors
                    SET vendor_id = :vendor_id,
                        store_name = :store_name,
                        store_theme = :store_theme,
                        is_featured = :is_featured,
                        is_active = :is_active,
                        status = :status
                    WHERE id = :id
                    """
                ),
                {
                    "id": store["id"],
                    "vendor_id": admin_user_id,
                    "store_name": store_name,
                    "store_theme": _serialize_store_theme(theme),
                    "is_featured": bool(payload.get("is_featured", False)),
                    "is_active": bool(payload.get("is_active", True)),
                    "status": "approved" if bool(payload.get("is_active", True)) else "pending",
                },
            )
            created = db.execute(
                text("SELECT id, vendor_id, store_name FROM vendors WHERE id = :id"),
                {"id": store["id"]},
            ).mappings().first()

        db.commit()
        return JSONResponse(
            {
                "id": created["id"],
                "store_name": created["store_name"],
                "vendor_id": created["vendor_id"],
                "max_internal_users": theme.get("max_internal_users", 0),
                "max_portal_users": theme.get("max_portal_users", 0),
            },
            status_code=201,
        )
    finally:
        db.close()


@marketplace_router.get(f"{BACKEND_ROUTE_PREFIX}/admin/business-types")
def list_business_types():
    db = SessionLocal()
    try:
        return _list_business_types(db)
    finally:
        db.close()


@marketplace_router.post(f"{BACKEND_ROUTE_PREFIX}/admin/business-types")
async def create_business_type(request: Request):
    payload = await request.json()
    name = str(payload.get("name") or "").strip()
    code = str(payload.get("code") or "").strip().upper()
    description = str(payload.get("description") or "").strip()
    if not name or not code or not description:
        raise HTTPException(status_code=422, detail="Completa Giro de negocio, Código y Descripción.")

    db = SessionLocal()
    try:
        existing = db.execute(
            select(store_business_types.c.id).where(
                (store_business_types.c.code == code) | (store_business_types.c.name == name)
            )
        ).first()
        if existing:
            raise HTTPException(status_code=409, detail="Ese giro o código ya existe.")

        db.execute(
            insert(store_business_types).values(
                name=name,
                code=code,
                description=description,
            )
        )
        db.commit()
        created = db.execute(
            select(
                store_business_types.c.id,
                store_business_types.c.name,
                store_business_types.c.code,
                store_business_types.c.description,
            ).where(store_business_types.c.code == code)
        ).mappings().first()
        return JSONResponse(dict(created), status_code=201)
    finally:
        db.close()


@marketplace_router.get(f"{BACKEND_ROUTE_PREFIX}/health")
def health():
    return {"status": "ok", "prefix": BACKEND_ROUTE_PREFIX or "/"}


def build_marketplace_backend_app() -> FastAPI:
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.employees.routes import router as employees_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.coupons.routes import router as coupons_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.layaways.routes import router as layaways_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.followers.routes import router as followers_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.videos.routes import router as videos_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.suppliers.routes import router as suppliers_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.whatsapp_config.routes import router as whatsapp_config_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.ai_config.routes import router as ai_config_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.messaging.routes import router as messaging_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.domains.routes import router as domains_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.wishlist.routes import router as wishlist_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.cart.routes import router as cart_router
    from fastapi_modulo.modulos.multitienda.marketplace.backend.apps.payments.routes import router as payments_router

    app = FastAPI(title="MultiTiendApp API", root_path=BACKEND_ROOT_PATH)

    if STATIC_DIR.is_dir():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    app.include_router(marketplace_router)
    app.include_router(employees_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(coupons_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(layaways_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(followers_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(videos_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(suppliers_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(whatsapp_config_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(ai_config_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(messaging_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(domains_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(wishlist_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(cart_router, prefix=BACKEND_ROUTE_PREFIX)
    app.include_router(payments_router, prefix=BACKEND_ROUTE_PREFIX)

    return app


__all__ = ["BACKEND_ROUTE_PREFIX", "build_marketplace_backend_app", "marketplace_router"]
