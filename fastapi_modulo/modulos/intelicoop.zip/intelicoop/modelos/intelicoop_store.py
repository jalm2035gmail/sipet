from __future__ import annotations

import json
import re
from datetime import datetime, time, timedelta
from typing import Any, Dict, List

from sqlalchemy import func, inspect as sa_inspect, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from fastapi_modulo.core import db as core_db
from fastapi_modulo.core.db import MAIN
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_db_models import (
    IntelicoopAhorroFeatureSnapshot,
    IntelicoopAnalyticCut,
    IntelicoopAuditLog,
    IntelicoopBatchAlert,
    IntelicoopBatchJobState,
    IntelicoopBatchRun,
    IntelicoopBusinessRule,
    IntelicoopCampania,
    IntelicoopCampaniaFeatureSnapshot,
    IntelicoopContactoCampania,
    IntelicoopCohorteSnapshot,
    IntelicoopCredito,
    IntelicoopCreditoFeatureSnapshot,
    IntelicoopCuenta,
    IntelicoopDataQualitySnapshot,
    IntelicoopGovernanceSnapshot,
    IntelicoopHistorialPago,
    IntelicoopKpiSnapshot,
    IntelicoopModelVersionRegistry,
    IntelicoopModelDriftSnapshot,
    IntelicoopModelRecalibration,
    IntelicoopProspecto,
    IntelicoopProspectoFeatureSnapshot,
    IntelicoopScoringResult,
    IntelicoopScoringTraza,
    IntelicoopSeguimientoCampania,
    IntelicoopSocioFeatureSnapshot,
    IntelicoopSocio,
    IntelicoopTransaccion,
)
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_scoring import evaluate_scoring_v2

_SCHEMA_READY_HOSTS: set[str] = set()
_EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_VALID_TX_TIPOS = {"deposito", "retiro"}
_VALID_CREDITO_ESTADOS = {"solicitado", "aprobado", "rechazado", "vigente", "liquidado", "mora"}
FOUNDATION_FEATURE_VERSION = "intelicoop_foundation_v1"
FEATURE_ENGINEERING_VERSION = "intelicoop_features_v1"
BATCH_VERSION = "intelicoop_batch_v1"
GOVERNANCE_VERSION = "intelicoop_governance_v1"
BATCH_JOB_CATALOG = [
    {
        "job_key": "foundation_refresh",
        "job_label": "Recalculo de features y snapshots",
        "cadence_minutes": 1440,
        "config": {"cut_type": "daily_close"},
    },
    {
        "job_key": "segmentation_refresh",
        "job_label": "Recalculo de segmentos automaticos",
        "cadence_minutes": 1440,
        "config": {},
    },
    {
        "job_key": "scoring_refresh",
        "job_label": "Recalculo batch de scoring",
        "cadence_minutes": 1440,
        "config": {},
    },
    {
        "job_key": "alerts_refresh",
        "job_label": "Generacion batch de alertas",
        "cadence_minutes": 720,
        "config": {},
    },
    {
        "job_key": "governance_refresh",
        "job_label": "Monitoreo, drift y auditoria",
        "cadence_minutes": 1440,
        "config": {},
    },
]
BUSINESS_RULE_CATALOG = [
    {
        "rule_key": "max_high_risk_share",
        "rule_label": "Participacion maxima de alto riesgo",
        "description": "El porcentaje de scoring alto no debe superar el umbral definido.",
        "severity": "alta",
        "threshold_value": 0.35,
        "config": {},
    },
    {
        "rule_key": "max_ratio_deuda_ingreso_avg",
        "rule_label": "Ratio deuda/ingreso promedio",
        "description": "El ratio deuda/ingreso promedio no debe exceder el umbral.",
        "severity": "media",
        "threshold_value": 0.55,
        "config": {},
    },
    {
        "rule_key": "max_drift_score",
        "rule_label": "Drift maximo aceptado",
        "description": "El drift por feature no debe superar el umbral configurado.",
        "severity": "alta",
        "threshold_value": 0.20,
        "config": {},
    },
]

# ── Catálogo de KPIs: define tipo observado/estimado y umbrales de semáforo ──
# direction "higher" = mayor es mejor; "lower" = menor es mejor
# verde/amarillo son los umbrales de corte
KPI_CATALOG: Dict[str, Any] = {
    "socios_total":     {"label": "Total socios",           "group": "fundamentos", "metric_type": "observado",  "direction": "higher", "verde": 10,   "amarillo": 1},
    "creditos_total":   {"label": "Total créditos",         "group": "fundamentos", "metric_type": "observado",  "direction": "higher", "verde": 5,    "amarillo": 1},
    "campanas_total":   {"label": "Total campañas",         "group": "fundamentos", "metric_type": "observado",  "direction": "higher", "verde": 2,    "amarillo": 1},
    "prospectos_total": {"label": "Total prospectos",       "group": "fundamentos", "metric_type": "observado",  "direction": "higher", "verde": 5,    "amarillo": 1},
    "scoring_total":    {"label": "Total evaluaciones",     "group": "fundamentos", "metric_type": "observado",  "direction": "higher", "verde": 5,    "amarillo": 1},
    "imor_pct":         {"label": "IMOR estimado %",        "group": "riesgo",      "metric_type": "estimado",   "direction": "lower",  "verde": 5.0,  "amarillo": 10.0},
    "captacion_neta":   {"label": "Captación neta",         "group": "captacion",   "metric_type": "observado",  "direction": "higher", "verde": 1000, "amarillo": 0},
    "conversion_pct":   {"label": "Conversión comercial %", "group": "comercial",   "metric_type": "observado",  "direction": "higher", "verde": 20.0, "amarillo": 10.0},
}


def _compute_semaforo(kpi_key: str, value: float) -> str:
    cat = KPI_CATALOG.get(kpi_key)
    if not cat:
        return "sin_umbral"
    verde = cat.get("verde")
    amarillo = cat.get("amarillo")
    if cat["direction"] == "higher":
        if verde is not None and value >= verde:
            return "verde"
        if amarillo is not None and value >= amarillo:
            return "amarillo"
        return "rojo"
    else:
        if verde is not None and value <= verde:
            return "verde"
        if amarillo is not None and value <= amarillo:
            return "amarillo"
        return "rojo"
TRANSACTIONAL_ENTITY_DEFINITIONS = [
    {"key": "socios", "table": "intelicoop_socios", "grain": "1 fila por socio"},
    {"key": "creditos", "table": "intelicoop_creditos", "grain": "1 fila por credito"},
    {"key": "historial_pagos", "table": "intelicoop_historial_pagos", "grain": "1 fila por pago"},
    {"key": "cuentas", "table": "intelicoop_cuentas", "grain": "1 fila por cuenta"},
    {"key": "transacciones", "table": "intelicoop_transacciones", "grain": "1 fila por transaccion"},
    {"key": "campanas", "table": "intelicoop_campanas", "grain": "1 fila por campana"},
    {"key": "prospectos", "table": "intelicoop_prospectos", "grain": "1 fila por prospecto"},
    {"key": "contactos_campania", "table": "intelicoop_contactos_campania", "grain": "1 fila por contacto"},
    {"key": "seguimiento_campania", "table": "intelicoop_seguimiento_campania", "grain": "1 fila por seguimiento"},
    {"key": "scoring_results", "table": "intelicoop_scoring_results", "grain": "1 fila por inferencia"},
]
ANALYTICAL_ENTITY_DEFINITIONS = [
    {"key": "scoring_trazas", "table": "intelicoop_scoring_trazas", "grain": "1 fila por traza de inferencia"},
    {"key": "model_versions", "table": "intelicoop_model_versions", "grain": "1 fila por version de modelo"},
    {"key": "analytic_cuts", "table": "intelicoop_analytic_cuts", "grain": "1 fila por corte analitico"},
    {"key": "data_quality_snapshots", "table": "intelicoop_data_quality_snapshots", "grain": "1 fila por regla y corte"},
    {"key": "socio_feature_snapshots", "table": "intelicoop_socio_feature_snapshots", "grain": "1 fila por socio y corte"},
    {"key": "credito_feature_snapshots", "table": "intelicoop_credito_feature_snapshots", "grain": "1 fila por credito y corte"},
    {"key": "ahorro_feature_snapshots", "table": "intelicoop_ahorro_feature_snapshots", "grain": "1 fila por cuenta y corte"},
    {"key": "campania_feature_snapshots", "table": "intelicoop_campania_feature_snapshots", "grain": "1 fila por campana y corte"},
    {"key": "prospecto_feature_snapshots", "table": "intelicoop_prospecto_feature_snapshots", "grain": "1 fila por prospecto y corte"},
    {"key": "cohorte_snapshots", "table": "intelicoop_cohorte_snapshots", "grain": "1 fila por dimension+bucket+metrica y corte"},
    {"key": "kpi_snapshots", "table": "intelicoop_kpi_snapshots", "grain": "1 fila por KPI y corte"},
    {"key": "batch_job_states", "table": "intelicoop_batch_job_states", "grain": "1 fila por job programado"},
    {"key": "batch_runs", "table": "intelicoop_batch_runs", "grain": "1 fila por ejecucion batch"},
    {"key": "batch_alerts", "table": "intelicoop_batch_alerts", "grain": "1 fila por alerta batch"},
    {"key": "governance_snapshots", "table": "intelicoop_governance_snapshots", "grain": "1 fila por snapshot de gobernanza"},
    {"key": "model_drift_snapshots", "table": "intelicoop_model_drift_snapshots", "grain": "1 fila por feature monitoreada"},
    {"key": "model_recalibrations", "table": "intelicoop_model_recalibrations", "grain": "1 fila por evento de recalibracion"},
    {"key": "audit_logs", "table": "intelicoop_audit_logs", "grain": "1 fila por evento auditable"},
    {"key": "business_rules", "table": "intelicoop_business_rules", "grain": "1 fila por regla de negocio"},
]
FOUNDATION_RELATIONSHIPS = [
    {"from": "socios", "to": "creditos", "type": "1:N", "key": "socios.id -> creditos.socio_id"},
    {"from": "creditos", "to": "historial_pagos", "type": "1:N", "key": "creditos.id -> historial_pagos.credito_id"},
    {"from": "socios", "to": "cuentas", "type": "1:N", "key": "socios.id -> cuentas.socio_id"},
    {"from": "cuentas", "to": "transacciones", "type": "1:N", "key": "cuentas.id -> transacciones.cuenta_id"},
    {"from": "campanas", "to": "contactos_campania", "type": "1:N", "key": "campanas.id -> contactos_campania.campania_id"},
    {"from": "socios", "to": "contactos_campania", "type": "1:N", "key": "socios.id -> contactos_campania.socio_id"},
    {"from": "campanas", "to": "seguimiento_campania", "type": "1:N", "key": "campanas.id -> seguimiento_campania.campania_id"},
    {"from": "socios", "to": "seguimiento_campania", "type": "1:N", "key": "socios.id -> seguimiento_campania.socio_id"},
    {"from": "socios", "to": "scoring_results", "type": "1:N", "key": "socios.id -> scoring_results.socio_id"},
    {"from": "creditos", "to": "scoring_results", "type": "1:N", "key": "creditos.id -> scoring_results.credito_id"},
    {"from": "socios", "to": "socio_feature_snapshots", "type": "1:N", "key": "socios.id -> socio_feature_snapshots.socio_id"},
]


def _migrate_intelicoop_schema(engine) -> None:
    """Aplica migraciones de esquema de intelicoop de forma idempotente.

    Cubiertas:
    - intelicoop_creditos: agrega fecha_desembolso y fecha_vencimiento si faltan.
    - intelicoop_campanas: convierte fecha_inicio/fecha_fin de VARCHAR a DATETIME.
    """
    inspector = sa_inspect(engine)
    existing_tables = set(inspector.get_table_names())
    dialect = engine.dialect.name

    # ── helper: agregar columnas nullable de forma idempotente ────────────────
    def _add_cols(table: str, cols: List[tuple]) -> None:
        if table not in existing_tables:
            return
        existing_cols = {c["name"] for c in inspector.get_columns(table)}
        with engine.begin() as conn:
            for col_name, col_type in cols:
                if col_name not in existing_cols:
                    if dialect == "postgresql":
                        conn.execute(text(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {col_name} {col_type}"))
                    else:
                        conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}"))

    # ── 1. intelicoop_creditos: columnas DateTime nuevas ─────────────────────
    dt = "TIMESTAMP" if dialect == "postgresql" else "DATETIME"
    _add_cols("intelicoop_creditos", [
        ("fecha_desembolso", dt),
        ("fecha_vencimiento", dt),
    ])

    # ── 2. intelicoop_campanas: VARCHAR → DATETIME en fecha_inicio/fecha_fin ──
    if "intelicoop_campanas" in existing_tables:
        cols = {c["name"]: c for c in inspector.get_columns("intelicoop_campanas")}
        fecha_col = cols.get("fecha_inicio")
        if fecha_col is not None:
            col_type_str = str(fecha_col["type"]).upper()
            needs_migration = any(t in col_type_str for t in ("VARCHAR", "TEXT", "CHAR"))
            if needs_migration:
                with engine.begin() as conn:
                    if dialect == "postgresql":
                        conn.execute(text(
                            "ALTER TABLE intelicoop_campanas "
                            "ALTER COLUMN fecha_inicio TYPE TIMESTAMP "
                            "  USING NULLIF(fecha_inicio, '')::TIMESTAMP, "
                            "ALTER COLUMN fecha_fin TYPE TIMESTAMP "
                            "  USING NULLIF(fecha_fin, '')::TIMESTAMP"
                        ))
                    else:
                        # SQLite no soporta ALTER COLUMN: reconstruir la tabla
                        conn.execute(text(
                            "CREATE TABLE intelicoop_campanas_mig_tmp ("
                            "  id INTEGER PRIMARY KEY,"
                            "  nombre VARCHAR(150) NOT NULL,"
                            "  tipo VARCHAR(100) NOT NULL,"
                            "  fecha_inicio DATETIME,"
                            "  fecha_fin DATETIME,"
                            "  estado VARCHAR(20) NOT NULL DEFAULT 'borrador',"
                            "  fecha_creacion DATETIME NOT NULL"
                            ")"
                        ))
                        conn.execute(text(
                            "INSERT INTO intelicoop_campanas_mig_tmp"
                            "  (id, nombre, tipo, fecha_inicio, fecha_fin, estado, fecha_creacion)"
                            " SELECT id, nombre, tipo,"
                            "  CASE WHEN fecha_inicio IS NULL OR fecha_inicio = ''"
                            "       THEN NULL ELSE datetime(fecha_inicio) END,"
                            "  CASE WHEN fecha_fin IS NULL OR fecha_fin = ''"
                            "       THEN NULL ELSE datetime(fecha_fin) END,"
                            "  estado, fecha_creacion"
                            " FROM intelicoop_campanas"
                        ))
                        conn.execute(text("DROP TABLE intelicoop_campanas"))
                        conn.execute(text(
                            "ALTER TABLE intelicoop_campanas_mig_tmp"
                            " RENAME TO intelicoop_campanas"
                        ))

    # ── 3. intelicoop_kpi_snapshots: columnas de Fase 3 ──────────────────────
    _add_cols("intelicoop_kpi_snapshots", [
        ("metric_type", "VARCHAR(20) NOT NULL DEFAULT 'observado'"),
        ("semaforo",    "VARCHAR(20) NOT NULL DEFAULT 'sin_umbral'"),
    ])

    # ── 4. intelicoop_socio_feature_snapshots: columnas de Fase 2 ────────────
    int_default0 = "INTEGER NOT NULL DEFAULT 0"
    float_default0 = "FLOAT NOT NULL DEFAULT 0"
    _add_cols("intelicoop_socio_feature_snapshots", [
        ("creditos_activos", int_default0),
        ("creditos_mora", int_default0),
        ("tasa_cumplimiento_pagos", float_default0),
        ("ratio_deuda_ingreso", float_default0),
        ("campanas_participadas", int_default0),
        ("campanas_convertidas", int_default0),
        ("dias_como_socio", int_default0),
        ("num_productos", int_default0),
    ])

    # ── 5. intelicoop_scoring_results: columnas de scoring operativo ─────────
    _add_cols("intelicoop_scoring_results", [
        ("confianza", "FLOAT"),
        ("motor", "VARCHAR(20) NOT NULL DEFAULT 'reglas'"),
        ("explicacion_json", "TEXT NOT NULL DEFAULT '{}'"),
    ])


def ensure_intelicoop_schema() -> None:
    current_host = str(core_db.get_request_host() or "").strip()
    cache_key = current_host or "__default__"
    if cache_key in _SCHEMA_READY_HOSTS:
        return
    engine = core_db.get_engine_for_host(current_host)
    _migrate_intelicoop_schema(engine)
    MAIN.metadata.create_all(
        bind=engine,
        tables=[
            IntelicoopSocio.__table__,
            IntelicoopCredito.__table__,
            IntelicoopHistorialPago.__table__,
            IntelicoopCuenta.__table__,
            IntelicoopTransaccion.__table__,
            IntelicoopCampania.__table__,
            IntelicoopProspecto.__table__,
            IntelicoopContactoCampania.__table__,
            IntelicoopSeguimientoCampania.__table__,
            IntelicoopScoringResult.__table__,
            IntelicoopScoringTraza.__table__,
            IntelicoopModelVersionRegistry.__table__,
            IntelicoopAnalyticCut.__table__,
            IntelicoopDataQualitySnapshot.__table__,
            IntelicoopSocioFeatureSnapshot.__table__,
            IntelicoopCreditoFeatureSnapshot.__table__,
            IntelicoopAhorroFeatureSnapshot.__table__,
            IntelicoopCampaniaFeatureSnapshot.__table__,
            IntelicoopProspectoFeatureSnapshot.__table__,
            IntelicoopCohorteSnapshot.__table__,
            IntelicoopKpiSnapshot.__table__,
            IntelicoopBatchJobState.__table__,
            IntelicoopBatchRun.__table__,
            IntelicoopBatchAlert.__table__,
            IntelicoopGovernanceSnapshot.__table__,
            IntelicoopModelDriftSnapshot.__table__,
            IntelicoopModelRecalibration.__table__,
            IntelicoopAuditLog.__table__,
            IntelicoopBusinessRule.__table__,
        ],
        checkfirst=True,
    )
    _SCHEMA_READY_HOSTS.add(cache_key)


def _db() -> Session:
    current_host = str(core_db.get_request_host() or "").strip()
    ensure_intelicoop_schema()
    session_factory = core_db.get_session_factory_for_host(current_host)
    return session_factory()


def _json_dump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, default=str)


def _json_load(raw: str | None, fallback: Any) -> Any:
    if not raw:
        return fallback
    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return fallback


def _utcnow() -> datetime:
    return datetime.utcnow()


def _batch_run_dict(obj: IntelicoopBatchRun) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "run_key": obj.run_key,
        "job_key": obj.job_key,
        "trigger_type": obj.trigger_type,
        "cut_key": obj.cut_key,
        "status": obj.status,
        "quality_status": obj.quality_status,
        "records_processed": int(obj.records_processed or 0),
        "records_created": int(obj.records_created or 0),
        "metrics": _json_load(obj.metrics_json, {}),
        "quality_summary": _json_load(obj.quality_summary_json, {}),
        "error_message": obj.error_message or "",
        "started_at": obj.started_at.isoformat() if obj.started_at else "",
        "finished_at": obj.finished_at.isoformat() if obj.finished_at else "",
    }


def _batch_job_state_dict(obj: IntelicoopBatchJobState) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "job_key": obj.job_key,
        "job_label": obj.job_label,
        "cadence_minutes": int(obj.cadence_minutes or 0),
        "enabled": bool(obj.enabled),
        "last_run_at": obj.last_run_at.isoformat() if obj.last_run_at else "",
        "next_run_at": obj.next_run_at.isoformat() if obj.next_run_at else "",
        "last_status": obj.last_status,
        "config": _json_load(obj.config_json, {}),
    }


def _batch_alert_dict(obj: IntelicoopBatchAlert) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "batch_run_id": obj.batch_run_id,
        "cut_key": obj.cut_key,
        "alert_type": obj.alert_type,
        "severity": obj.severity,
        "entity_type": obj.entity_type,
        "entity_id": obj.entity_id,
        "entity_label": obj.entity_label,
        "score": round(float(obj.score or 0), 4),
        "status": obj.status,
        "details": _json_load(obj.details_json, {}),
        "created_at": obj.created_at.isoformat() if obj.created_at else "",
    }


def _governance_snapshot_dict(obj: IntelicoopGovernanceSnapshot) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "cut_key": obj.cut_key,
        "model_version": obj.model_version,
        "monitoring": _json_load(obj.monitoring_json, {}),
        "drift": _json_load(obj.drift_json, {}),
        "explainability": _json_load(obj.explainability_json, {}),
        "governance_status": obj.governance_status,
        "created_at": obj.created_at.isoformat() if obj.created_at else "",
    }


def _drift_snapshot_dict(obj: IntelicoopModelDriftSnapshot) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "cut_key": obj.cut_key,
        "model_version": obj.model_version,
        "feature_key": obj.feature_key,
        "baseline_value": round(float(obj.baseline_value or 0), 4),
        "current_value": round(float(obj.current_value or 0), 4),
        "drift_score": round(float(obj.drift_score or 0), 4),
        "drift_level": obj.drift_level,
        "details": _json_load(obj.details_json, {}),
        "created_at": obj.created_at.isoformat() if obj.created_at else "",
    }


def _recalibration_dict(obj: IntelicoopModelRecalibration) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "model_version": obj.model_version,
        "trigger_reason": obj.trigger_reason,
        "status": obj.status,
        "notes": obj.notes,
        "before_metrics": _json_load(obj.before_metrics_json, {}),
        "after_metrics": _json_load(obj.after_metrics_json, {}),
        "created_at": obj.created_at.isoformat() if obj.created_at else "",
    }


def _audit_log_dict(obj: IntelicoopAuditLog) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "event_type": obj.event_type,
        "entity_type": obj.entity_type,
        "entity_id": obj.entity_id,
        "actor": obj.actor,
        "model_version": obj.model_version,
        "details": _json_load(obj.details_json, {}),
        "created_at": obj.created_at.isoformat() if obj.created_at else "",
    }


def _business_rule_dict(obj: IntelicoopBusinessRule) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "rule_key": obj.rule_key,
        "rule_label": obj.rule_label,
        "description": obj.description,
        "severity": obj.severity,
        "enabled": bool(obj.enabled),
        "threshold_value": float(obj.threshold_value) if obj.threshold_value is not None else None,
        "config": _json_load(obj.config_json, {}),
        "created_at": obj.created_at.isoformat() if obj.created_at else "",
        "updated_at": obj.updated_at.isoformat() if obj.updated_at else "",
    }


def _ensure_batch_job_states(db: Session) -> List[IntelicoopBatchJobState]:
    now = _utcnow()
    rows: List[IntelicoopBatchJobState] = []
    for item in BATCH_JOB_CATALOG:
        row = db.query(IntelicoopBatchJobState).filter(IntelicoopBatchJobState.job_key == item["job_key"]).first()
        if row is None:
            row = IntelicoopBatchJobState(
                job_key=item["job_key"],
                job_label=item["job_label"],
                cadence_minutes=int(item["cadence_minutes"]),
                enabled=1,
                last_status="pending",
                next_run_at=now - timedelta(minutes=1),
                config_json=_json_dump(item.get("config", {})),
            )
            db.add(row)
        else:
            row.job_label = item["job_label"]
            row.cadence_minutes = int(item["cadence_minutes"])
            if not row.config_json:
                row.config_json = _json_dump(item.get("config", {}))
            if row.next_run_at is None:
                row.next_run_at = now
        row.updated_at = now
        rows.append(row)
    db.flush()
    return rows


def _ensure_business_rules(db: Session) -> List[IntelicoopBusinessRule]:
    now = _utcnow()
    rows: List[IntelicoopBusinessRule] = []
    for item in BUSINESS_RULE_CATALOG:
        row = db.query(IntelicoopBusinessRule).filter(IntelicoopBusinessRule.rule_key == item["rule_key"]).first()
        if row is None:
            row = IntelicoopBusinessRule(
                rule_key=item["rule_key"],
                rule_label=item["rule_label"],
                description=item["description"],
                severity=item["severity"],
                enabled=1,
                threshold_value=item.get("threshold_value"),
                config_json=_json_dump(item.get("config", {})),
                updated_at=now,
            )
            db.add(row)
        else:
            row.rule_label = item["rule_label"]
            row.description = item["description"]
            row.severity = item["severity"]
            if row.threshold_value is None:
                row.threshold_value = item.get("threshold_value")
            if not row.config_json:
                row.config_json = _json_dump(item.get("config", {}))
            row.updated_at = now
        rows.append(row)
    db.flush()
    return rows


def _create_audit_log(
    db: Session,
    event_type: str,
    entity_type: str,
    entity_id: int | None = None,
    actor: str = "system",
    model_version: str = "",
    details: Dict[str, Any] | None = None,
) -> None:
    db.add(
        IntelicoopAuditLog(
            event_type=event_type,
            entity_type=entity_type,
            entity_id=entity_id,
            actor=actor,
            model_version=model_version,
            details_json=_json_dump(details or {}),
        )
    )
    db.flush()


def _derive_batch_quality_status(summary: Dict[str, Any]) -> str:
    failed = int(summary.get("failed_rules", 0))
    warned = int(summary.get("warn_rules", 0))
    if failed > 0:
        return "fail"
    if warned > 0:
        return "warn"
    return "pass"


def _governance_status(levels: List[str]) -> str:
    if "fail" in levels:
        return "fail"
    if "warn" in levels:
        return "warn"
    return "pass"


def _drift_level(score: float) -> str:
    if score >= 0.2:
        return "alto"
    if score >= 0.1:
        return "medio"
    return "bajo"


def _cut_context(reference_at: datetime | None = None, cut_type: str = "daily_close") -> Dict[str, Any]:
    effective = reference_at or datetime.utcnow()
    day_start = datetime.combine(effective.date(), time.min)
    next_day = day_start + timedelta(days=1)
    month_start = day_start.replace(day=1)
    if month_start.month == 12:
        next_month = month_start.replace(year=month_start.year + 1, month=1)
    else:
        next_month = month_start.replace(month=month_start.month + 1)
    if cut_type == "monthly_close":
        return {
            "cut_key": f"month:{month_start.strftime('%Y%m')}",
            "cut_type": "monthly_close",
            "cut_date": month_start,
            "window_start": month_start,
            "window_end": next_month,
            "month_start": month_start,
            "month_end": next_month,
        }
    return {
        "cut_key": f"day:{day_start.strftime('%Y%m%d')}",
        "cut_type": "daily_close",
        "cut_date": day_start,
        "window_start": day_start,
        "window_end": next_day,
        "month_start": month_start,
        "month_end": next_month,
    }


def _socio_dict(obj: IntelicoopSocio) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "nombre": obj.nombre,
        "email": obj.email,
        "telefono": obj.telefono,
        "direccion": obj.direccion,
        "segmento": obj.segmento,
        "fecha_registro": obj.fecha_registro.isoformat() if obj.fecha_registro else "",
    }


def _credito_dict(obj: IntelicoopCredito, socio_nombre: str = "") -> Dict[str, Any]:
    return {
        "id": obj.id,
        "socio_id": obj.socio_id,
        "socio_nombre": socio_nombre,
        "monto": round(float(obj.monto or 0), 2),
        "plazo": obj.plazo,
        "ingreso_mensual": round(float(obj.ingreso_mensual or 0), 2),
        "deuda_actual": round(float(obj.deuda_actual or 0), 2),
        "antiguedad_meses": obj.antiguedad_meses,
        "estado": obj.estado,
        "fecha_desembolso": obj.fecha_desembolso.isoformat() if obj.fecha_desembolso else None,
        "fecha_vencimiento": obj.fecha_vencimiento.isoformat() if obj.fecha_vencimiento else None,
        "fecha_creacion": obj.fecha_creacion.isoformat() if obj.fecha_creacion else "",
    }


def _historial_pago_dict(obj: IntelicoopHistorialPago) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "credito_id": obj.credito_id,
        "monto": round(float(obj.monto or 0), 2),
        "fecha": obj.fecha.isoformat() if obj.fecha else "",
    }


def _campania_dict(obj: IntelicoopCampania) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "nombre": obj.nombre,
        "tipo": obj.tipo,
        "fecha_inicio": obj.fecha_inicio.isoformat() if obj.fecha_inicio else None,
        "fecha_fin": obj.fecha_fin.isoformat() if obj.fecha_fin else None,
        "estado": obj.estado,
        "fecha_creacion": obj.fecha_creacion.isoformat() if obj.fecha_creacion else "",
    }


def _prospecto_dict(obj: IntelicoopProspecto) -> Dict[str, Any]:
    return {
        "id": obj.id,
        "nombre": obj.nombre,
        "telefono": obj.telefono,
        "direccion": obj.direccion,
        "fuente": obj.fuente,
        "score_propension": round(float(obj.score_propension or 0), 4),
        "fecha_creacion": obj.fecha_creacion.isoformat() if obj.fecha_creacion else "",
    }


def _contacto_campania_dict(obj: IntelicoopContactoCampania, campania_nombre: str = "", socio_nombre: str = "") -> Dict[str, Any]:
    return {
        "id": obj.id,
        "campania_id": obj.campania_id,
        "campania_nombre": campania_nombre,
        "socio_id": obj.socio_id,
        "socio_nombre": socio_nombre,
        "ejecutivo_id": obj.ejecutivo_id,
        "canal": obj.canal,
        "estado_contacto": obj.estado_contacto,
        "fecha_contacto": obj.fecha_contacto.isoformat() if obj.fecha_contacto else "",
    }


def _seguimiento_campania_dict(obj: IntelicoopSeguimientoCampania, campania_nombre: str = "", socio_nombre: str = "") -> Dict[str, Any]:
    return {
        "id": obj.id,
        "campania_id": obj.campania_id,
        "campania_nombre": campania_nombre,
        "socio_id": obj.socio_id,
        "socio_nombre": socio_nombre,
        "lista": obj.lista,
        "etapa": obj.etapa,
        "conversion": bool(obj.conversion),
        "monto_colocado": round(float(obj.monto_colocado or 0), 2),
        "fecha_evento": obj.fecha_evento.isoformat() if obj.fecha_evento else "",
    }


def _scoring_result_dict(obj: IntelicoopScoringResult) -> Dict[str, Any]:
    explicacion = _json_load(obj.explicacion_json, {})
    return {
        "id": obj.id,
        "solicitud_id": obj.solicitud_id,
        "socio_id": obj.socio_id,
        "credito_id": obj.credito_id,
        "ingreso_mensual": round(float(obj.ingreso_mensual or 0), 2),
        "deuda_actual": round(float(obj.deuda_actual or 0), 2),
        "antiguedad_meses": obj.antiguedad_meses,
        "score": round(float(obj.score or 0), 4),
        "recomendacion": obj.recomendacion,
        "riesgo": obj.riesgo,
        "model_version": obj.model_version,
        "confianza": round(float(obj.confianza or 0), 4) if obj.confianza is not None else None,
        "motor": obj.motor,
        "explicacion_json": explicacion,
        "razones": explicacion.get("razones", []),
        "reglas_aplicadas": explicacion.get("reglas_aplicadas", []),
        "traza_id": None,
        "traza_version": None,
        "fecha_creacion": obj.fecha_creacion.isoformat() if obj.fecha_creacion else "",
    }


def _cuenta_dict(obj: IntelicoopCuenta, socio_nombre: str = "") -> Dict[str, Any]:
    return {
        "id": obj.id,
        "socio_id": obj.socio_id,
        "socio_nombre": socio_nombre,
        "tipo": obj.tipo,
        "saldo": round(float(obj.saldo or 0), 2),
        "fecha_creacion": obj.fecha_creacion.isoformat() if obj.fecha_creacion else "",
    }


def _transaccion_dict(obj: IntelicoopTransaccion, socio_nombre: str = "") -> Dict[str, Any]:
    return {
        "id": obj.id,
        "cuenta_id": obj.cuenta_id,
        "socio_nombre": socio_nombre,
        "monto": round(float(obj.monto or 0), 2),
        "tipo": obj.tipo,
        "fecha": obj.fecha.isoformat() if obj.fecha else "",
    }


def list_socios() -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = db.query(IntelicoopSocio).order_by(IntelicoopSocio.id.desc()).all()
        return [_socio_dict(row) for row in rows]
    finally:
        db.close()


def get_socio(socio_id: int) -> Dict[str, Any] | None:
    db = _db()
    try:
        row = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == socio_id).first()
        return _socio_dict(row) if row else None
    finally:
        db.close()


def create_socio(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        email = payload["email"].strip().lower()
        existing = db.query(IntelicoopSocio).filter(func.lower(IntelicoopSocio.email) == email).first()
        if existing:
            raise ValueError("Ya existe un socio con ese correo.")
        row = IntelicoopSocio(
            nombre=payload["nombre"].strip(),
            email=email,
            telefono=payload.get("telefono", "").strip(),
            direccion=payload.get("direccion", "").strip(),
            segmento=payload.get("segmento", "inactivo").strip() or "inactivo",
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _socio_dict(row)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_creditos() -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = (
            db.query(IntelicoopCredito, IntelicoopSocio.nombre)
            .join(IntelicoopSocio, IntelicoopSocio.id == IntelicoopCredito.socio_id)
            .order_by(IntelicoopCredito.id.desc())
            .all()
        )
        return [_credito_dict(credito, socio_nombre or "") for credito, socio_nombre in rows]
    finally:
        db.close()


def get_credito(credito_id: int) -> Dict[str, Any] | None:
    db = _db()
    try:
        row = (
            db.query(IntelicoopCredito, IntelicoopSocio.nombre)
            .join(IntelicoopSocio, IntelicoopSocio.id == IntelicoopCredito.socio_id)
            .filter(IntelicoopCredito.id == credito_id)
            .first()
        )
        if not row:
            return None
        credito, socio_nombre = row
        return _credito_dict(credito, socio_nombre or "")
    finally:
        db.close()


def get_credito_detail(credito_id: int) -> Dict[str, Any] | None:
    db = _db()
    try:
        row = (
            db.query(IntelicoopCredito, IntelicoopSocio.nombre)
            .join(IntelicoopSocio, IntelicoopSocio.id == IntelicoopCredito.socio_id)
            .filter(IntelicoopCredito.id == credito_id)
            .first()
        )
        if not row:
            return None
        credito, socio_nombre = row
        pagos = (
            db.query(IntelicoopHistorialPago)
            .filter(IntelicoopHistorialPago.credito_id == credito_id)
            .order_by(IntelicoopHistorialPago.fecha.desc(), IntelicoopHistorialPago.id.desc())
            .all()
        )
        total_pagado = sum(float(item.monto or 0) for item in pagos)
        return {
            **_credito_dict(credito, socio_nombre or ""),
            "historial_pagos": [_historial_pago_dict(item) for item in pagos],
            "resumen_pagos": {
                "total_pagos": len(pagos),
                "monto_pagado": round(total_pagado, 2),
                "saldo_estimado": round(max(0.0, float(credito.monto or 0) - total_pagado), 2),
            },
        }
    finally:
        db.close()


def create_credito(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        socio = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == int(payload["socio_id"])).first()
        if not socio:
            raise ValueError("El socio indicado no existe en intelicoop.")
        row = IntelicoopCredito(
            socio_id=int(payload["socio_id"]),
            monto=float(payload["monto"]),
            plazo=int(payload["plazo"]),
            ingreso_mensual=float(payload.get("ingreso_mensual", 0)),
            deuda_actual=float(payload.get("deuda_actual", 0)),
            antiguedad_meses=int(payload.get("antiguedad_meses", 0)),
            estado=payload.get("estado", "solicitado"),
            fecha_desembolso=payload.get("fecha_desembolso"),
            fecha_vencimiento=payload.get("fecha_vencimiento"),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _credito_dict(row, socio.nombre)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_historial_pagos(credito_id: int | None = None) -> List[Dict[str, Any]]:
    db = _db()
    try:
        query = db.query(IntelicoopHistorialPago)
        if credito_id is not None:
            query = query.filter(IntelicoopHistorialPago.credito_id == credito_id)
        rows = query.order_by(IntelicoopHistorialPago.fecha.desc(), IntelicoopHistorialPago.id.desc()).all()
        return [_historial_pago_dict(row) for row in rows]
    finally:
        db.close()


def create_historial_pago(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        credito = db.query(IntelicoopCredito).filter(IntelicoopCredito.id == int(payload["credito_id"])).first()
        if not credito:
            raise ValueError("El credito indicado no existe en intelicoop.")
        row = IntelicoopHistorialPago(
            credito_id=int(payload["credito_id"]),
            monto=float(payload["monto"]),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _historial_pago_dict(row)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def get_ahorros_resumen() -> Dict[str, Any]:
    db = _db()
    try:
        cuentas = db.query(func.count(IntelicoopCuenta.id)).scalar() or 0
        movimientos = db.query(func.count(IntelicoopTransaccion.id)).scalar() or 0
        captacion = db.query(func.coalesce(func.sum(IntelicoopCuenta.saldo), 0)).scalar() or 0
        return {
            "cuentas": int(cuentas),
            "movimientos": int(movimientos),
            "captacion": round(float(captacion), 2),
        }
    finally:
        db.close()


def list_cuentas() -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = (
            db.query(IntelicoopCuenta, IntelicoopSocio.nombre)
            .join(IntelicoopSocio, IntelicoopSocio.id == IntelicoopCuenta.socio_id)
            .order_by(IntelicoopCuenta.id.desc())
            .all()
        )
        return [_cuenta_dict(cuenta, socio_nombre or "") for cuenta, socio_nombre in rows]
    finally:
        db.close()


def create_cuenta(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        socio = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == int(payload["socio_id"])).first()
        if not socio:
            raise ValueError("El socio indicado no existe en intelicoop.")
        row = IntelicoopCuenta(
            socio_id=int(payload["socio_id"]),
            tipo=str(payload.get("tipo", "ahorro")).strip() or "ahorro",
            saldo=float(payload.get("saldo", 0)),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _cuenta_dict(row, socio.nombre)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_transacciones() -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = (
            db.query(IntelicoopTransaccion, IntelicoopSocio.nombre)
            .join(IntelicoopCuenta, IntelicoopCuenta.id == IntelicoopTransaccion.cuenta_id)
            .join(IntelicoopSocio, IntelicoopSocio.id == IntelicoopCuenta.socio_id)
            .order_by(IntelicoopTransaccion.id.desc())
            .all()
        )
        return [_transaccion_dict(tx, socio_nombre or "") for tx, socio_nombre in rows]
    finally:
        db.close()


def create_transaccion(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        cuenta = db.query(IntelicoopCuenta).filter(IntelicoopCuenta.id == int(payload["cuenta_id"])).first()
        if not cuenta:
            raise ValueError("La cuenta indicada no existe en intelicoop.")
        tipo = str(payload.get("tipo", "deposito")).strip() or "deposito"
        monto = float(payload.get("monto", 0))
        if monto <= 0:
            raise ValueError("El monto debe ser mayor a cero.")
        saldo_actual = float(cuenta.saldo or 0)
        if tipo == "retiro" and monto > saldo_actual:
            raise ValueError("Saldo insuficiente para registrar el retiro.")
        cuenta.saldo = saldo_actual + monto if tipo == "deposito" else saldo_actual - monto
        tx = IntelicoopTransaccion(
            cuenta_id=cuenta.id,
            monto=monto,
            tipo=tipo,
        )
        db.add(tx)
        db.commit()
        db.refresh(tx)
        socio = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == cuenta.socio_id).first()
        return _transaccion_dict(tx, socio.nombre if socio else "")
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_campanas() -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = db.query(IntelicoopCampania).order_by(IntelicoopCampania.id.desc()).all()
        return [_campania_dict(row) for row in rows]
    finally:
        db.close()


def create_campana(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        row = IntelicoopCampania(
            nombre=payload["nombre"].strip(),
            tipo=payload["tipo"].strip(),
            fecha_inicio=payload.get("fecha_inicio"),
            fecha_fin=payload.get("fecha_fin"),
            estado=payload.get("estado", "borrador").strip() or "borrador",
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _campania_dict(row)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_prospectos() -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = db.query(IntelicoopProspecto).order_by(IntelicoopProspecto.id.desc()).all()
        return [_prospecto_dict(row) for row in rows]
    finally:
        db.close()


def create_prospecto(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        row = IntelicoopProspecto(
            nombre=payload["nombre"].strip(),
            telefono=payload.get("telefono", "").strip(),
            direccion=payload.get("direccion", "").strip(),
            fuente=payload.get("fuente", "").strip(),
            score_propension=float(payload.get("score_propension", 0)),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _prospecto_dict(row)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_contactos_campania(campania_id: int | None = None) -> List[Dict[str, Any]]:
    db = _db()
    try:
        query = (
            db.query(IntelicoopContactoCampania, IntelicoopCampania.nombre, IntelicoopSocio.nombre)
            .join(IntelicoopCampania, IntelicoopCampania.id == IntelicoopContactoCampania.campania_id)
            .join(IntelicoopSocio, IntelicoopSocio.id == IntelicoopContactoCampania.socio_id)
        )
        if campania_id is not None:
            query = query.filter(IntelicoopContactoCampania.campania_id == campania_id)
        rows = query.order_by(IntelicoopContactoCampania.id.desc()).all()
        return [
            _contacto_campania_dict(contacto, campania_nombre or "", socio_nombre or "")
            for contacto, campania_nombre, socio_nombre in rows
        ]
    finally:
        db.close()


def create_contacto_campania(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        campania = db.query(IntelicoopCampania).filter(IntelicoopCampania.id == int(payload["campania_id"])).first()
        socio = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == int(payload["socio_id"])).first()
        if not campania:
            raise ValueError("La campana indicada no existe en intelicoop.")
        if not socio:
            raise ValueError("El socio indicado no existe en intelicoop.")
        row = IntelicoopContactoCampania(
            campania_id=int(payload["campania_id"]),
            socio_id=int(payload["socio_id"]),
            ejecutivo_id=str(payload.get("ejecutivo_id", "ejecutivo_general")).strip() or "ejecutivo_general",
            canal=str(payload.get("canal", "telefono")).strip() or "telefono",
            estado_contacto=str(payload.get("estado_contacto", "pendiente")).strip() or "pendiente",
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _contacto_campania_dict(row, campania.nombre, socio.nombre)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_seguimientos_campania(campania_id: int | None = None) -> List[Dict[str, Any]]:
    db = _db()
    try:
        query = (
            db.query(IntelicoopSeguimientoCampania, IntelicoopCampania.nombre, IntelicoopSocio.nombre)
            .join(IntelicoopCampania, IntelicoopCampania.id == IntelicoopSeguimientoCampania.campania_id)
            .join(IntelicoopSocio, IntelicoopSocio.id == IntelicoopSeguimientoCampania.socio_id)
        )
        if campania_id is not None:
            query = query.filter(IntelicoopSeguimientoCampania.campania_id == campania_id)
        rows = query.order_by(IntelicoopSeguimientoCampania.id.desc()).all()
        return [
            _seguimiento_campania_dict(item, campania_nombre or "", socio_nombre or "")
            for item, campania_nombre, socio_nombre in rows
        ]
    finally:
        db.close()


def create_seguimiento_campania(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        campania = db.query(IntelicoopCampania).filter(IntelicoopCampania.id == int(payload["campania_id"])).first()
        socio = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == int(payload["socio_id"])).first()
        if not campania:
            raise ValueError("La campana indicada no existe en intelicoop.")
        if not socio:
            raise ValueError("El socio indicado no existe en intelicoop.")
        row = IntelicoopSeguimientoCampania(
            campania_id=int(payload["campania_id"]),
            socio_id=int(payload["socio_id"]),
            lista=str(payload.get("lista", "general")).strip() or "general",
            etapa=str(payload.get("etapa", "contactado")).strip() or "contactado",
            conversion=1 if payload.get("conversion") else 0,
            monto_colocado=float(payload.get("monto_colocado", 0)),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return _seguimiento_campania_dict(row, campania.nombre, socio.nombre)
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def list_scoring_results() -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = db.query(IntelicoopScoringResult).order_by(IntelicoopScoringResult.id.desc()).all()
        traza_ids = {
            scoring_result_id: (traza_id, traza_version)
            for scoring_result_id, traza_id, traza_version in db.query(
                IntelicoopScoringTraza.scoring_result_id,
                IntelicoopScoringTraza.id,
                IntelicoopScoringTraza.traza_version,
            )
            .filter(IntelicoopScoringTraza.scoring_result_id.isnot(None))
            .all()
        }
        payload = []
        for row in rows:
            item = _scoring_result_dict(row)
            traza_meta = traza_ids.get(row.id)
            if traza_meta:
                item["traza_id"], item["traza_version"] = traza_meta
            payload.append(item)
        return payload
    finally:
        db.close()


def _register_scoring_model_version(db: Session, payload: Dict[str, Any]) -> None:
    version_key = str(payload.get("model_version", "intelicoop_scoring_v1")).strip() or "intelicoop_scoring_v1"
    row = (
        db.query(IntelicoopModelVersionRegistry)
        .filter(IntelicoopModelVersionRegistry.version_key == version_key)
        .first()
    )
    if row:
        return
    features = sorted(list(dict.fromkeys(
        list((payload.get("inputs") or {}).keys()) + list((payload.get("features_calculados") or {}).keys())
    )))
    row = IntelicoopModelVersionRegistry(
        version_key=version_key,
        algoritmo=str(payload.get("motor", "reglas")).strip() or "reglas",
        descripcion="Scoring operativo Intelicoop con trazabilidad y explicacion.",
        features_json=_json_dump(features),
        umbrales_json=_json_dump({
            "aprobar": 0.80,
            "evaluar": 0.55,
        }),
        metricas_json=_json_dump({
            "confianza_default": payload.get("confianza"),
        }),
        activo=1,
    )
    db.add(row)
    db.flush()


def _create_scoring_trace(db: Session, scoring_result_id: int, payload: Dict[str, Any]) -> IntelicoopScoringTraza:
    row = IntelicoopScoringTraza(
        scoring_result_id=scoring_result_id,
        solicitud_id=str(payload["solicitud_id"]).strip(),
        socio_id=payload.get("socio_id"),
        credito_id=payload.get("credito_id"),
        inputs_json=_json_dump(payload.get("inputs", {})),
        features_calculados_json=_json_dump(payload.get("features_calculados", {})),
        outputs_json=_json_dump({
            "score": payload.get("score"),
            "recomendacion": payload.get("recomendacion"),
            "riesgo": payload.get("riesgo"),
        }),
        razones_json=_json_dump(payload.get("razones", [])),
        reglas_aplicadas_json=_json_dump(payload.get("reglas_aplicadas", [])),
        confianza=float(payload.get("confianza", 0) or 0),
        tiempo_ms=int(payload.get("tiempo_ms", 0) or 0),
        motor=str(payload.get("motor", "reglas")).strip() or "reglas",
        model_version=str(payload.get("model_version", "intelicoop_scoring_v1")).strip() or "intelicoop_scoring_v1",
        traza_version=str(payload.get("traza_version", "intelicoop_traza_v1")).strip() or "intelicoop_traza_v1",
    )
    db.add(row)
    db.flush()
    return row


def create_scoring_result(payload: Dict[str, Any]) -> Dict[str, Any]:
    db = _db()
    try:
        solicitud_id = str(payload["solicitud_id"]).strip()
        explicacion = {
            "razones": list(payload.get("razones", [])),
            "reglas_aplicadas": list(payload.get("reglas_aplicadas", [])),
            "inputs": dict(payload.get("inputs", {})),
            "features_calculados": dict(payload.get("features_calculados", {})),
        }
        row = IntelicoopScoringResult(
            solicitud_id=solicitud_id,
            socio_id=payload.get("socio_id"),
            credito_id=payload.get("credito_id"),
            ingreso_mensual=float(payload.get("ingreso_mensual", 0)),
            deuda_actual=float(payload.get("deuda_actual", 0)),
            antiguedad_meses=int(payload.get("antiguedad_meses", 0)),
            score=float(payload.get("score", 0)),
            recomendacion=str(payload.get("recomendacion", "evaluar")),
            riesgo=str(payload.get("riesgo", "medio")),
            model_version=str(payload.get("model_version", "intelicoop_scoring_v1")),
            confianza=float(payload["confianza"]) if payload.get("confianza") is not None else None,
            motor=str(payload.get("motor", "reglas")),
            explicacion_json=_json_dump(explicacion),
        )
        db.add(row)
        db.flush()
        _register_scoring_model_version(db, payload)
        traza = _create_scoring_trace(db, row.id, {**payload, "solicitud_id": solicitud_id})
        _create_audit_log(
            db,
            event_type="scoring_created",
            entity_type="scoring_result",
            entity_id=row.id,
            actor="system",
            model_version=row.model_version,
            details={"solicitud_id": solicitud_id, "traza_id": traza.id},
        )
        db.commit()
        db.refresh(row)
        result = _scoring_result_dict(row)
        result["traza_id"] = traza.id
        result["traza_version"] = traza.traza_version
        return result
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def get_scoring_trace(scoring_result_id: int) -> Dict[str, Any] | None:
    db = _db()
    try:
        traza = (
            db.query(IntelicoopScoringTraza)
            .filter(IntelicoopScoringTraza.scoring_result_id == scoring_result_id)
            .order_by(IntelicoopScoringTraza.id.desc())
            .first()
        )
        if not traza:
            return None
        return {
            "id": traza.id,
            "scoring_result_id": traza.scoring_result_id,
            "solicitud_id": traza.solicitud_id,
            "socio_id": traza.socio_id,
            "credito_id": traza.credito_id,
            "inputs": _json_load(traza.inputs_json, {}),
            "features_calculados": _json_load(traza.features_calculados_json, {}),
            "outputs": _json_load(traza.outputs_json, {}),
            "razones": _json_load(traza.razones_json, []),
            "reglas_aplicadas": _json_load(traza.reglas_aplicadas_json, []),
            "confianza": round(float(traza.confianza or 0), 4),
            "tiempo_ms": int(traza.tiempo_ms or 0),
            "motor": traza.motor,
            "model_version": traza.model_version,
            "traza_version": traza.traza_version,
            "created_at": traza.created_at.isoformat() if traza.created_at else "",
        }
    finally:
        db.close()


def _foundation_quality_report(db: Session) -> List[Dict[str, Any]]:
    socios = db.query(IntelicoopSocio).all()
    prospectos = db.query(IntelicoopProspecto).all()
    cuentas = db.query(IntelicoopCuenta).all()
    transacciones = db.query(IntelicoopTransaccion).all()
    scoring_rows = db.query(IntelicoopScoringResult).all()

    creditos_orfanos = int(
        db.query(func.count(IntelicoopCredito.id))
        .outerjoin(IntelicoopSocio, IntelicoopSocio.id == IntelicoopCredito.socio_id)
        .filter(IntelicoopSocio.id.is_(None))
        .scalar()
        or 0
    )
    pagos_orfanos = int(
        db.query(func.count(IntelicoopHistorialPago.id))
        .outerjoin(IntelicoopCredito, IntelicoopCredito.id == IntelicoopHistorialPago.credito_id)
        .filter(IntelicoopCredito.id.is_(None))
        .scalar()
        or 0
    )
    contactos_orfanos = int(
        db.query(func.count(IntelicoopContactoCampania.id))
        .outerjoin(IntelicoopCampania, IntelicoopCampania.id == IntelicoopContactoCampania.campania_id)
        .outerjoin(IntelicoopSocio, IntelicoopSocio.id == IntelicoopContactoCampania.socio_id)
        .filter((IntelicoopCampania.id.is_(None)) | (IntelicoopSocio.id.is_(None)))
        .scalar()
        or 0
    )
    seguimientos_orfanos = int(
        db.query(func.count(IntelicoopSeguimientoCampania.id))
        .outerjoin(IntelicoopCampania, IntelicoopCampania.id == IntelicoopSeguimientoCampania.campania_id)
        .outerjoin(IntelicoopSocio, IntelicoopSocio.id == IntelicoopSeguimientoCampania.socio_id)
        .filter((IntelicoopCampania.id.is_(None)) | (IntelicoopSocio.id.is_(None)))
        .scalar()
        or 0
    )

    creditos_all = db.query(IntelicoopCredito).all()
    campanas_all = db.query(IntelicoopCampania).all()

    rules = [
        {
            "scope": "socios",
            "rule_key": "email_valido_requerido",
            "total_records": len(socios),
            "failed_records": sum(1 for row in socios if not _EMAIL_PATTERN.match(str(row.email or "").strip().lower())),
            "threshold_fail": 0,
        },
        {
            "scope": "socios",
            "rule_key": "nombre_no_vacio",
            "total_records": len(socios),
            "failed_records": sum(1 for row in socios if not str(row.nombre or "").strip()),
            "threshold_fail": 0,
        },
        {
            "scope": "creditos",
            "rule_key": "integridad_socio_fk",
            "total_records": int(db.query(func.count(IntelicoopCredito.id)).scalar() or 0),
            "failed_records": creditos_orfanos,
            "threshold_fail": 0,
        },
        {
            "scope": "creditos",
            "rule_key": "monto_positivo",
            "total_records": len(creditos_all),
            "failed_records": sum(1 for row in creditos_all if float(row.monto or 0) <= 0),
            "threshold_fail": 0,
        },
        {
            "scope": "creditos",
            "rule_key": "plazo_minimo_1",
            "total_records": len(creditos_all),
            "failed_records": sum(1 for row in creditos_all if int(row.plazo or 0) < 1),
            "threshold_fail": 0,
        },
        {
            "scope": "historial_pagos",
            "rule_key": "integridad_credito_fk",
            "total_records": int(db.query(func.count(IntelicoopHistorialPago.id)).scalar() or 0),
            "failed_records": pagos_orfanos,
            "threshold_fail": 0,
        },
        {
            "scope": "cuentas",
            "rule_key": "saldo_no_negativo",
            "total_records": len(cuentas),
            "failed_records": sum(1 for row in cuentas if float(row.saldo or 0) < 0),
            "threshold_fail": 0,
        },
        {
            "scope": "transacciones",
            "rule_key": "monto_positivo",
            "total_records": len(transacciones),
            "failed_records": sum(1 for row in transacciones if float(row.monto or 0) <= 0),
            "threshold_fail": 0,
        },
        {
            "scope": "transacciones",
            "rule_key": "tipo_valido",
            "total_records": len(transacciones),
            "failed_records": sum(1 for row in transacciones if str(row.tipo or "") not in _VALID_TX_TIPOS),
            "threshold_fail": 0,
        },
        {
            "scope": "campanas",
            "rule_key": "fechas_coherentes",
            "total_records": len(campanas_all),
            "failed_records": sum(
                1 for row in campanas_all
                if row.fecha_inicio and row.fecha_fin and row.fecha_fin < row.fecha_inicio
            ),
            "threshold_fail": 0,
        },
        {
            "scope": "prospectos",
            "rule_key": "score_propension_rango_0_1",
            "total_records": len(prospectos),
            "failed_records": sum(1 for row in prospectos if not 0 <= float(row.score_propension or 0) <= 1),
            "threshold_fail": 0,
        },
        {
            "scope": "contactos_campania",
            "rule_key": "integridad_fk",
            "total_records": int(db.query(func.count(IntelicoopContactoCampania.id)).scalar() or 0),
            "failed_records": contactos_orfanos,
            "threshold_fail": 0,
        },
        {
            "scope": "seguimiento_campania",
            "rule_key": "integridad_fk",
            "total_records": int(db.query(func.count(IntelicoopSeguimientoCampania.id)).scalar() or 0),
            "failed_records": seguimientos_orfanos,
            "threshold_fail": 0,
        },
        {
            "scope": "scoring_results",
            "rule_key": "score_rango_0_1",
            "total_records": len(scoring_rows),
            "failed_records": sum(1 for row in scoring_rows if not 0 <= float(row.score or 0) <= 1),
            "threshold_fail": 0,
        },
        {
            "scope": "scoring_results",
            "rule_key": "solicitud_id_no_vacio",
            "total_records": len(scoring_rows),
            "failed_records": sum(1 for row in scoring_rows if not str(row.solicitud_id or "").strip()),
            "threshold_fail": 0,
        },
    ]
    for rule in rules:
        failed = int(rule["failed_records"])
        total = int(rule["total_records"])
        if failed > int(rule["threshold_fail"]):
            status = "fail"
        elif total == 0:
            status = "warn"
        else:
            status = "pass"
        rule["status"] = status
    return rules


def get_foundation_overview() -> Dict[str, Any]:
    db = _db()
    try:
        cut_context = _cut_context()
        latest_cut = (
            db.query(IntelicoopAnalyticCut)
            .order_by(IntelicoopAnalyticCut.cut_date.desc(), IntelicoopAnalyticCut.id.desc())
            .first()
        )
        quality_rules = _foundation_quality_report(db)
        transactional_entities = []
        analytical_entities = []
        table_counts = {
            "intelicoop_socios": int(db.query(func.count(IntelicoopSocio.id)).scalar() or 0),
            "intelicoop_creditos": int(db.query(func.count(IntelicoopCredito.id)).scalar() or 0),
            "intelicoop_historial_pagos": int(db.query(func.count(IntelicoopHistorialPago.id)).scalar() or 0),
            "intelicoop_cuentas": int(db.query(func.count(IntelicoopCuenta.id)).scalar() or 0),
            "intelicoop_transacciones": int(db.query(func.count(IntelicoopTransaccion.id)).scalar() or 0),
            "intelicoop_campanas": int(db.query(func.count(IntelicoopCampania.id)).scalar() or 0),
            "intelicoop_prospectos": int(db.query(func.count(IntelicoopProspecto.id)).scalar() or 0),
            "intelicoop_contactos_campania": int(db.query(func.count(IntelicoopContactoCampania.id)).scalar() or 0),
            "intelicoop_seguimiento_campania": int(db.query(func.count(IntelicoopSeguimientoCampania.id)).scalar() or 0),
            "intelicoop_scoring_results": int(db.query(func.count(IntelicoopScoringResult.id)).scalar() or 0),
            "intelicoop_analytic_cuts": int(db.query(func.count(IntelicoopAnalyticCut.id)).scalar() or 0),
            "intelicoop_data_quality_snapshots": int(db.query(func.count(IntelicoopDataQualitySnapshot.id)).scalar() or 0),
            "intelicoop_socio_feature_snapshots": int(db.query(func.count(IntelicoopSocioFeatureSnapshot.id)).scalar() or 0),
            "intelicoop_credito_feature_snapshots": int(db.query(func.count(IntelicoopCreditoFeatureSnapshot.id)).scalar() or 0),
            "intelicoop_ahorro_feature_snapshots": int(db.query(func.count(IntelicoopAhorroFeatureSnapshot.id)).scalar() or 0),
            "intelicoop_campania_feature_snapshots": int(db.query(func.count(IntelicoopCampaniaFeatureSnapshot.id)).scalar() or 0),
            "intelicoop_prospecto_feature_snapshots": int(db.query(func.count(IntelicoopProspectoFeatureSnapshot.id)).scalar() or 0),
            "intelicoop_cohorte_snapshots": int(db.query(func.count(IntelicoopCohorteSnapshot.id)).scalar() or 0),
            "intelicoop_kpi_snapshots": int(db.query(func.count(IntelicoopKpiSnapshot.id)).scalar() or 0),
            "intelicoop_batch_job_states": int(db.query(func.count(IntelicoopBatchJobState.id)).scalar() or 0),
            "intelicoop_batch_runs": int(db.query(func.count(IntelicoopBatchRun.id)).scalar() or 0),
            "intelicoop_batch_alerts": int(db.query(func.count(IntelicoopBatchAlert.id)).scalar() or 0),
            "intelicoop_governance_snapshots": int(db.query(func.count(IntelicoopGovernanceSnapshot.id)).scalar() or 0),
            "intelicoop_model_drift_snapshots": int(db.query(func.count(IntelicoopModelDriftSnapshot.id)).scalar() or 0),
            "intelicoop_model_recalibrations": int(db.query(func.count(IntelicoopModelRecalibration.id)).scalar() or 0),
            "intelicoop_audit_logs": int(db.query(func.count(IntelicoopAuditLog.id)).scalar() or 0),
            "intelicoop_business_rules": int(db.query(func.count(IntelicoopBusinessRule.id)).scalar() or 0),
        }
        for item in TRANSACTIONAL_ENTITY_DEFINITIONS:
            transactional_entities.append({**item, "records": table_counts.get(item["table"], 0)})
        for item in ANALYTICAL_ENTITY_DEFINITIONS:
            analytical_entities.append({**item, "records": table_counts.get(item["table"], 0)})
        return {
            "entity_model": {
                "transactional": transactional_entities,
                "analytical": analytical_entities,
                "relationships": FOUNDATION_RELATIONSHIPS,
            },
            "time_cuts": {
                "transactional_mode": "event_time",
                "analytical_mode": "cut_time_snapshot",
                "active_cut_key": cut_context["cut_key"],
                "active_cut_date": cut_context["cut_date"].isoformat(),
                "daily_window_start": cut_context["window_start"].isoformat(),
                "daily_window_end": cut_context["window_end"].isoformat(),
                "monthly_window_start": cut_context["month_start"].isoformat(),
                "monthly_window_end": cut_context["month_end"].isoformat(),
            },
            "minimum_quality": quality_rules,
            "storage_contract": {
                "transactional_tables": [item["table"] for item in TRANSACTIONAL_ENTITY_DEFINITIONS],
                "analytical_tables": [item["table"] for item in ANALYTICAL_ENTITY_DEFINITIONS],
                "latest_materialized_cut": {
                    "cut_key": latest_cut.cut_key if latest_cut else "",
                    "cut_date": latest_cut.cut_date.isoformat() if latest_cut and latest_cut.cut_date else "",
                    "status": latest_cut.status if latest_cut else "pending",
                },
            },
        }
    finally:
        db.close()


def materialize_foundation_cut(
    reference_at: datetime | None = None,
    cut_type: str = "daily_close",
) -> Dict[str, Any]:
    db = _db()
    try:
        cut_context = _cut_context(reference_at, cut_type=cut_type)
        cut_key = str(cut_context["cut_key"])
        cut_date = cut_context["cut_date"]
        now = datetime.utcnow()

        # Limpiar snapshots previos del mismo corte (idempotente)
        for model in (
            IntelicoopDataQualitySnapshot,
            IntelicoopSocioFeatureSnapshot,
            IntelicoopCreditoFeatureSnapshot,
            IntelicoopAhorroFeatureSnapshot,
            IntelicoopCampaniaFeatureSnapshot,
            IntelicoopProspectoFeatureSnapshot,
            IntelicoopCohorteSnapshot,
            IntelicoopKpiSnapshot,
        ):
            db.query(model).filter(model.cut_key == cut_key).delete(synchronize_session=False)

        # Registrar el corte
        cut_row = db.query(IntelicoopAnalyticCut).filter(IntelicoopAnalyticCut.cut_key == cut_key).first()
        if cut_row is None:
            cut_row = IntelicoopAnalyticCut(cut_key=cut_key)
            db.add(cut_row)
        cut_row.cut_type = str(cut_context["cut_type"])
        cut_row.cut_date = cut_date
        cut_row.window_start = cut_context["window_start"]
        cut_row.window_end = cut_context["window_end"]
        cut_row.transactional_tables_json = _json_dump([item["table"] for item in TRANSACTIONAL_ENTITY_DEFINITIONS])
        cut_row.analytical_tables_json = _json_dump([item["table"] for item in ANALYTICAL_ENTITY_DEFINITIONS])
        cut_row.status = "ready"

        # ── Calidad (Fase 1) ────────────────────────────────────────────────
        quality_rules = _foundation_quality_report(db)
        for rule in quality_rules:
            db.add(
                IntelicoopDataQualitySnapshot(
                    cut_key=cut_key,
                    cut_date=cut_date,
                    scope=str(rule["scope"]),
                    rule_key=str(rule["rule_key"]),
                    total_records=int(rule["total_records"]),
                    failed_records=int(rule["failed_records"]),
                    status=str(rule["status"]),
                    details_json=_json_dump({
                        "threshold_fail": int(rule["threshold_fail"]),
                        "total_records": int(rule["total_records"]),
                        "failed_records": int(rule["failed_records"]),
                    }),
                )
            )

        # ── Agregados base ──────────────────────────────────────────────────
        socios = db.query(IntelicoopSocio).order_by(IntelicoopSocio.id.asc()).all()

        # creditos por socio
        creditos_agg: Dict[int, Dict[str, Any]] = {
            int(sid): {"creditos_total": int(tot or 0), "monto_total": float(monto or 0)}
            for sid, tot, monto in db.query(
                IntelicoopCredito.socio_id,
                func.count(IntelicoopCredito.id),
                func.coalesce(func.sum(IntelicoopCredito.monto), 0),
            ).group_by(IntelicoopCredito.socio_id).all()
        }
        # créditos activos (estado no rechazado/liquidado)
        creditos_activos_agg: Dict[int, int] = {
            int(sid): int(tot or 0)
            for sid, tot in db.query(
                IntelicoopCredito.socio_id,
                func.count(IntelicoopCredito.id),
            ).filter(IntelicoopCredito.estado.in_(["solicitado", "aprobado", "vigente", "mora"])).group_by(IntelicoopCredito.socio_id).all()
        }
        creditos_mora_agg: Dict[int, int] = {
            int(sid): int(tot or 0)
            for sid, tot in db.query(
                IntelicoopCredito.socio_id,
                func.count(IntelicoopCredito.id),
            ).filter(IntelicoopCredito.estado == "mora").group_by(IntelicoopCredito.socio_id).all()
        }
        # pagos totales por socio
        pagos_agg: Dict[int, float] = {
            int(sid): float(tot or 0)
            for sid, tot in db.query(
                IntelicoopCredito.socio_id,
                func.coalesce(func.sum(IntelicoopHistorialPago.monto), 0),
            ).join(IntelicoopHistorialPago, IntelicoopHistorialPago.credito_id == IntelicoopCredito.id)
            .group_by(IntelicoopCredito.socio_id).all()
        }
        # cuentas por socio
        cuentas_agg: Dict[int, Dict[str, Any]] = {
            int(sid): {"cuentas_total": int(tot or 0), "saldo_total": float(saldo or 0)}
            for sid, tot, saldo in db.query(
                IntelicoopCuenta.socio_id,
                func.count(IntelicoopCuenta.id),
                func.coalesce(func.sum(IntelicoopCuenta.saldo), 0),
            ).group_by(IntelicoopCuenta.socio_id).all()
        }
        # transacciones por socio
        tx_agg: Dict[int, int] = {
            int(sid): int(tot or 0)
            for sid, tot in db.query(
                IntelicoopCuenta.socio_id,
                func.count(IntelicoopTransaccion.id),
            ).join(IntelicoopTransaccion, IntelicoopTransaccion.cuenta_id == IntelicoopCuenta.id)
            .group_by(IntelicoopCuenta.socio_id).all()
        }
        # campañas por socio (participaciones y conversiones)
        campanas_part_agg: Dict[int, int] = {
            int(sid): int(tot or 0)
            for sid, tot in db.query(
                IntelicoopContactoCampania.socio_id,
                func.count(IntelicoopContactoCampania.id),
            ).group_by(IntelicoopContactoCampania.socio_id).all()
        }
        campanas_conv_agg: Dict[int, int] = {
            int(sid): int(tot or 0)
            for sid, tot in db.query(
                IntelicoopSeguimientoCampania.socio_id,
                func.count(IntelicoopSeguimientoCampania.id),
            ).filter(IntelicoopSeguimientoCampania.conversion == 1)
            .group_by(IntelicoopSeguimientoCampania.socio_id).all()
        }
        # último scoring por socio
        latest_scoring: Dict[int, Dict[str, Any]] = {}
        for row in db.query(IntelicoopScoringResult).filter(
            IntelicoopScoringResult.socio_id.isnot(None)
        ).order_by(
            IntelicoopScoringResult.socio_id.asc(),
            IntelicoopScoringResult.fecha_creacion.desc(),
            IntelicoopScoringResult.id.desc(),
        ).all():
            sid = int(row.socio_id or 0)
            if sid and sid not in latest_scoring:
                latest_scoring[sid] = {
                    "score": float(row.score or 0),
                    "riesgo": str(row.riesgo or "sin_dato"),
                    "ingreso_mensual": float(row.ingreso_mensual or 0),
                    "deuda_actual": float(row.deuda_actual or 0),
                }

        # ── Features por socio (Fase 2) ─────────────────────────────────────
        for socio in socios:
            sid = int(socio.id)
            c_agg = creditos_agg.get(sid, {})
            cu_agg = cuentas_agg.get(sid, {})
            sc = latest_scoring.get(sid, {})
            creditos_total = int(c_agg.get("creditos_total", 0))
            cuentas_total = int(cu_agg.get("cuentas_total", 0))
            monto_creditos_total = float(c_agg.get("monto_total", 0))
            pagos_total = float(pagos_agg.get(sid, 0))
            tasa_cumplimiento = round(pagos_total / monto_creditos_total, 4) if monto_creditos_total > 0 else 0.0
            ingreso = float(sc.get("ingreso_mensual", 0))
            deuda = float(sc.get("deuda_actual", 0))
            ratio_deuda_ingreso = round(deuda / ingreso, 4) if ingreso > 0 else 0.0
            dias_como_socio = (now - socio.fecha_registro).days if socio.fecha_registro else 0
            db.add(IntelicoopSocioFeatureSnapshot(
                cut_key=cut_key, cut_date=cut_date,
                socio_id=sid,
                socio_nombre=str(socio.nombre or ""),
                segmento_actual=str(socio.segmento or "inactivo"),
                creditos_total=creditos_total,
                creditos_activos=int(creditos_activos_agg.get(sid, 0)),
                creditos_mora=int(creditos_mora_agg.get(sid, 0)),
                monto_creditos_total=monto_creditos_total,
                pagos_total=pagos_total,
                tasa_cumplimiento_pagos=tasa_cumplimiento,
                ratio_deuda_ingreso=ratio_deuda_ingreso,
                cuentas_total=cuentas_total,
                saldo_cuentas_total=float(cu_agg.get("saldo_total", 0)),
                transacciones_total=int(tx_agg.get(sid, 0)),
                campanas_participadas=int(campanas_part_agg.get(sid, 0)),
                campanas_convertidas=int(campanas_conv_agg.get(sid, 0)),
                dias_como_socio=max(0, dias_como_socio),
                num_productos=creditos_total + cuentas_total,
                score_propension_referencia=0.0,
                score_scoring_reciente=float(sc.get("score", 0)),
                riesgo_scoring_reciente=str(sc.get("riesgo", "sin_dato")),
                feature_version=FEATURE_ENGINEERING_VERSION,
            ))

        # ── Features por crédito (Fase 2) ───────────────────────────────────
        creditos_all = db.query(IntelicoopCredito).order_by(IntelicoopCredito.id.asc()).all()
        # pagos agrupados por credito_id
        pagos_por_credito: Dict[int, Dict[str, Any]] = {
            int(cid): {"num_pagos": int(npagos or 0), "monto_pagado": float(monto or 0)}
            for cid, npagos, monto in db.query(
                IntelicoopHistorialPago.credito_id,
                func.count(IntelicoopHistorialPago.id),
                func.coalesce(func.sum(IntelicoopHistorialPago.monto), 0),
            ).group_by(IntelicoopHistorialPago.credito_id).all()
        }
        for cred in creditos_all:
            cid = int(cred.id)
            monto = float(cred.monto or 0)
            pinfo = pagos_por_credito.get(cid, {})
            num_pagos = int(pinfo.get("num_pagos", 0))
            monto_pagado = float(pinfo.get("monto_pagado", 0))
            saldo_pendiente = max(0.0, monto - monto_pagado)
            ratio_pagado = round(monto_pagado / monto, 4) if monto > 0 else 0.0
            plazo = int(cred.plazo or 0)
            tasa_cump = round(num_pagos / plazo, 4) if plazo > 0 else 0.0
            en_mora = 1 if str(cred.estado or "") == "mora" else 0
            dias_desde_desembolso = (now - cred.fecha_desembolso).days if cred.fecha_desembolso else None
            dias_hasta_vencimiento = (cred.fecha_vencimiento - now).days if cred.fecha_vencimiento else None
            db.add(IntelicoopCreditoFeatureSnapshot(
                cut_key=cut_key, cut_date=cut_date,
                credito_id=cid,
                socio_id=int(cred.socio_id),
                monto=monto,
                plazo=plazo,
                estado=str(cred.estado or "solicitado"),
                num_pagos=num_pagos,
                monto_pagado=monto_pagado,
                saldo_pendiente=saldo_pendiente,
                ratio_pagado=ratio_pagado,
                tasa_cumplimiento=tasa_cump,
                en_mora=en_mora,
                dias_desde_desembolso=dias_desde_desembolso,
                dias_hasta_vencimiento=dias_hasta_vencimiento,
                feature_version=FEATURE_ENGINEERING_VERSION,
            ))

        # ── Features por cuenta/ahorro (Fase 2) ────────────────────────────
        cuentas_all = db.query(IntelicoopCuenta).order_by(IntelicoopCuenta.id.asc()).all()
        tx_por_cuenta: Dict[int, List[Any]] = {}
        for tx in db.query(IntelicoopTransaccion).all():
            tx_por_cuenta.setdefault(int(tx.cuenta_id), []).append(tx)
        for cuenta in cuentas_all:
            txs = tx_por_cuenta.get(int(cuenta.id), [])
            depositos = [float(t.monto or 0) for t in txs if str(t.tipo or "") == "deposito"]
            retiros = [float(t.monto or 0) for t in txs if str(t.tipo or "") == "retiro"]
            total_depositos = sum(depositos)
            total_retiros = sum(retiros)
            prom_dep = round(total_depositos / len(depositos), 2) if depositos else 0.0
            prom_ret = round(total_retiros / len(retiros), 2) if retiros else 0.0
            ultima_tx = max((t.fecha for t in txs if t.fecha), default=None)
            dias_sin_mov = (now - ultima_tx).days if ultima_tx else (now - cuenta.fecha_creacion).days if cuenta.fecha_creacion else 0
            if total_depositos > total_retiros * 1.1:
                tendencia = "creciente"
            elif total_retiros > total_depositos * 1.1:
                tendencia = "decreciente"
            else:
                tendencia = "estable"
            db.add(IntelicoopAhorroFeatureSnapshot(
                cut_key=cut_key, cut_date=cut_date,
                cuenta_id=int(cuenta.id),
                socio_id=int(cuenta.socio_id),
                tipo=str(cuenta.tipo or "ahorro"),
                saldo_actual=round(float(cuenta.saldo or 0), 2),
                num_transacciones=len(txs),
                monto_depositos=round(total_depositos, 2),
                monto_retiros=round(total_retiros, 2),
                promedio_deposito=prom_dep,
                promedio_retiro=prom_ret,
                dias_sin_movimiento=max(0, dias_sin_mov),
                tendencia_saldo=tendencia,
                feature_version=FEATURE_ENGINEERING_VERSION,
            ))

        # ── Features por campaña (Fase 2) ──────────────────────────────────
        campanas_all = db.query(IntelicoopCampania).order_by(IntelicoopCampania.id.asc()).all()
        contactos_por_campana: Dict[int, int] = {
            int(cid): int(tot or 0)
            for cid, tot in db.query(
                IntelicoopContactoCampania.campania_id, func.count(IntelicoopContactoCampania.id)
            ).group_by(IntelicoopContactoCampania.campania_id).all()
        }
        seguimientos_por_campana: Dict[int, Dict[str, Any]] = {}
        for cid, tot, conv, monto_col in db.query(
            IntelicoopSeguimientoCampania.campania_id,
            func.count(IntelicoopSeguimientoCampania.id),
            func.coalesce(func.sum(IntelicoopSeguimientoCampania.conversion), 0),
            func.coalesce(func.sum(IntelicoopSeguimientoCampania.monto_colocado), 0),
        ).group_by(IntelicoopSeguimientoCampania.campania_id).all():
            seguimientos_por_campana[int(cid)] = {
                "total": int(tot or 0),
                "conversiones": int(conv or 0),
                "monto_colocado": float(monto_col or 0),
            }
        for camp in campanas_all:
            cid = int(camp.id)
            total_contactos = int(contactos_por_campana.get(cid, 0))
            seg = seguimientos_por_campana.get(cid, {})
            total_seg = int(seg.get("total", 0))
            conversiones = int(seg.get("conversiones", 0))
            monto_col = float(seg.get("monto_colocado", 0))
            tasa_conv = round(conversiones / total_contactos, 4) if total_contactos > 0 else 0.0
            duracion = None
            if camp.fecha_inicio and camp.fecha_fin:
                duracion = max(0, (camp.fecha_fin - camp.fecha_inicio).days)
            db.add(IntelicoopCampaniaFeatureSnapshot(
                cut_key=cut_key, cut_date=cut_date,
                campania_id=cid,
                estado=str(camp.estado or "borrador"),
                total_contactos=total_contactos,
                total_seguimientos=total_seg,
                conversiones=conversiones,
                tasa_conversion=tasa_conv,
                monto_colocado=round(monto_col, 2),
                duracion_dias=duracion,
                feature_version=FEATURE_ENGINEERING_VERSION,
            ))

        # ── Features por prospecto (Fase 2) ────────────────────────────────
        prospectos_all = db.query(IntelicoopProspecto).order_by(IntelicoopProspecto.id.asc()).all()
        # prospectos contactados en alguna campaña (via nombre/fuente no tenemos FK directa)
        # usamos set vacío; feature en_campana requiere relación explícita futura
        for prosp in prospectos_all:
            dias_prosp = (now - prosp.fecha_creacion).days if prosp.fecha_creacion else 0
            db.add(IntelicoopProspectoFeatureSnapshot(
                cut_key=cut_key, cut_date=cut_date,
                prospecto_id=int(prosp.id),
                score_propension=round(float(prosp.score_propension or 0), 4),
                fuente=str(prosp.fuente or ""),
                dias_como_prospecto=max(0, dias_prosp),
                en_campana=0,
                feature_version=FEATURE_ENGINEERING_VERSION,
            ))

        # ── KPIs con semáforo y tipo observado/estimado (Fase 3) ────────────
        dashboard = get_dashboard_resumen()
        kpi_raw = [
            ("socios_total",   float(dashboard.get("socios", 0))),
            ("creditos_total", float(dashboard.get("creditos", 0))),
            ("campanas_total", float(dashboard.get("campanas", 0))),
            ("prospectos_total", float(dashboard.get("prospectos", 0))),
            ("scoring_total",  float(dashboard.get("scoring_total", 0))),
            ("imor_pct",       float(((dashboard.get("salud_cartera") or {}).get("imor_pct", 0)) or 0)),
            ("captacion_neta", float(((dashboard.get("captacion") or {}).get("captacion_neta", 0)) or 0)),
            ("conversion_pct", float(((dashboard.get("comercial") or {}).get("conversion_pct", 0)) or 0)),
        ]
        for kpi_key, value in kpi_raw:
            cat = KPI_CATALOG.get(kpi_key, {})
            db.add(IntelicoopKpiSnapshot(
                cut_key=cut_key, cut_date=cut_date,
                kpi_key=kpi_key,
                metric_group=str(cat.get("group", "general")),
                metric_value=float(value),
                metric_label=str(cat.get("label", kpi_key)),
                metric_type=str(cat.get("metric_type", "observado")),
                semaforo=_compute_semaforo(kpi_key, float(value)),
            ))

        # ── Cohortes (Fase 3) ────────────────────────────────────────────────
        cohorte_rows = 0

        # Dimensión 1: socios por mes de registro
        for socio in socios:
            if socio.fecha_registro:
                bucket = socio.fecha_registro.strftime("%Y-%m")
            else:
                bucket = "sin_fecha"
            # acumulamos en dict para agregar
            pass

        # Agregación de socios por mes_registro
        mes_registro_map: Dict[str, Dict[str, Any]] = {}
        for socio in socios:
            b = socio.fecha_registro.strftime("%Y-%m") if socio.fecha_registro else "sin_fecha"
            entry = mes_registro_map.setdefault(b, {"n": 0, "cuentas": 0, "saldo": 0.0, "creditos": 0})
            entry["n"] += 1
            sid = int(socio.id)
            entry["cuentas"] += int(cuentas_agg.get(sid, {}).get("cuentas_total", 0))
            entry["saldo"] += float(cuentas_agg.get(sid, {}).get("saldo_total", 0))
            entry["creditos"] += int(creditos_agg.get(sid, {}).get("creditos_total", 0))
        for bucket, agg in mes_registro_map.items():
            n = int(agg["n"])
            for mkey, mval, mtype in [
                ("n_socios",          float(n),                              "observado"),
                ("avg_cuentas",       round(agg["cuentas"] / n, 2) if n else 0.0, "observado"),
                ("avg_saldo",         round(agg["saldo"] / n, 2) if n else 0.0,   "observado"),
                ("avg_creditos",      round(agg["creditos"] / n, 2) if n else 0.0,"observado"),
            ]:
                db.add(IntelicoopCohorteSnapshot(
                    cut_key=cut_key, cut_date=cut_date,
                    dimension="mes_registro_socio",
                    bucket=bucket,
                    metric_key=mkey,
                    metric_value=float(mval),
                    n_records=n,
                    metric_type=mtype,
                ))
                cohorte_rows += 1

        # Dimensión 2: créditos por estado
        estado_map: Dict[str, Dict[str, Any]] = {}
        for cred in creditos_all:
            b = str(cred.estado or "sin_estado")
            entry = estado_map.setdefault(b, {"n": 0, "monto": 0.0})
            entry["n"] += 1
            entry["monto"] += float(cred.monto or 0)
        total_creditos_n = sum(v["n"] for v in estado_map.values()) or 1
        for bucket, agg in estado_map.items():
            n = int(agg["n"])
            for mkey, mval, mtype in [
                ("n_creditos",   float(n),                              "observado"),
                ("monto_total",  round(agg["monto"], 2),                "observado"),
                ("pct_del_total", round(n / total_creditos_n * 100, 2), "observado"),
            ]:
                db.add(IntelicoopCohorteSnapshot(
                    cut_key=cut_key, cut_date=cut_date,
                    dimension="estado_credito",
                    bucket=bucket,
                    metric_key=mkey,
                    metric_value=float(mval),
                    n_records=n,
                    metric_type=mtype,
                ))
                cohorte_rows += 1

        # Dimensión 3: socios por segmento
        segmento_map: Dict[str, int] = {}
        for socio in socios:
            b = str(socio.segmento or "inactivo")
            segmento_map[b] = segmento_map.get(b, 0) + 1
        total_socios_n = len(socios) or 1
        for bucket, n in segmento_map.items():
            for mkey, mval, mtype in [
                ("n_socios",    float(n),                                "observado"),
                ("pct_socios",  round(n / total_socios_n * 100, 2),     "observado"),
            ]:
                db.add(IntelicoopCohorteSnapshot(
                    cut_key=cut_key, cut_date=cut_date,
                    dimension="segmento_socio",
                    bucket=bucket,
                    metric_key=mkey,
                    metric_value=float(mval),
                    n_records=n,
                    metric_type=mtype,
                ))
                cohorte_rows += 1

        # Dimensión 4: tendencia saldo por tipo de cuenta
        tipo_cuenta_map: Dict[str, Dict[str, Any]] = {}
        for cuenta in cuentas_all:
            b = str(cuenta.tipo or "ahorro")
            entry = tipo_cuenta_map.setdefault(b, {"n": 0, "saldo": 0.0})
            entry["n"] += 1
            entry["saldo"] += float(cuenta.saldo or 0)
        for bucket, agg in tipo_cuenta_map.items():
            n = int(agg["n"])
            for mkey, mval, mtype in [
                ("n_cuentas",    float(n),                              "observado"),
                ("saldo_total",  round(agg["saldo"], 2),                "observado"),
                ("saldo_promedio", round(agg["saldo"] / n, 2) if n else 0.0, "observado"),
            ]:
                db.add(IntelicoopCohorteSnapshot(
                    cut_key=cut_key, cut_date=cut_date,
                    dimension="tipo_cuenta",
                    bucket=bucket,
                    metric_key=mkey,
                    metric_value=float(mval),
                    n_records=n,
                    metric_type=mtype,
                ))
                cohorte_rows += 1

        db.commit()
        feature_rows_detail = {
            "socios": len(socios),
            "creditos": len(creditos_all),
            "cuentas": len(cuentas_all),
            "campanas": len(campanas_all),
            "prospectos": len(prospectos_all),
        }
        return {
            "cut_key": cut_key,
            "cut_type": cut_context["cut_type"],
            "cut_date": cut_date.isoformat(),
            "transactional_tables": [item["table"] for item in TRANSACTIONAL_ENTITY_DEFINITIONS],
            "analytical_tables": [item["table"] for item in ANALYTICAL_ENTITY_DEFINITIONS],
            "quality_rules": len(quality_rules),
            "feature_rows": sum(feature_rows_detail.values()),
            "feature_rows_detail": feature_rows_detail,
            "kpi_rows": len(kpi_raw),
            "cohorte_rows": cohorte_rows,
        }
    except SQLAlchemyError as exc:
        db.rollback()
        raise exc
    finally:
        db.close()


def get_descriptive_analytics() -> Dict[str, Any]:
    """KPIs con semáforo, cohortes y resumen de tendencias del último corte."""
    db = _db()
    try:
        latest_cut = (
            db.query(IntelicoopAnalyticCut)
            .order_by(IntelicoopAnalyticCut.cut_date.desc(), IntelicoopAnalyticCut.id.desc())
            .first()
        )
        if not latest_cut:
            return {"kpis": [], "cohortes": {}, "tendencias_resumen": [], "cut_key": None}

        cut_key = str(latest_cut.cut_key)

        # KPIs con semáforo
        kpi_rows = (
            db.query(IntelicoopKpiSnapshot)
            .filter(IntelicoopKpiSnapshot.cut_key == cut_key)
            .order_by(IntelicoopKpiSnapshot.metric_group.asc(), IntelicoopKpiSnapshot.kpi_key.asc())
            .all()
        )
        kpis = [
            {
                "kpi_key": row.kpi_key,
                "label": row.metric_label,
                "group": row.metric_group,
                "value": round(float(row.metric_value or 0), 4),
                "metric_type": row.metric_type,
                "semaforo": row.semaforo,
            }
            for row in kpi_rows
        ]

        # Cohortes agrupadas por dimensión
        cohorte_rows = (
            db.query(IntelicoopCohorteSnapshot)
            .filter(IntelicoopCohorteSnapshot.cut_key == cut_key)
            .order_by(
                IntelicoopCohorteSnapshot.dimension.asc(),
                IntelicoopCohorteSnapshot.bucket.asc(),
                IntelicoopCohorteSnapshot.metric_key.asc(),
            )
            .all()
        )
        cohortes: Dict[str, List[Dict[str, Any]]] = {}
        for row in cohorte_rows:
            dim = row.dimension
            cohortes.setdefault(dim, []).append({
                "bucket": row.bucket,
                "metric_key": row.metric_key,
                "metric_value": round(float(row.metric_value or 0), 4),
                "n_records": row.n_records,
                "metric_type": row.metric_type,
            })

        # Tendencias: últimos N cortes para cada KPI
        tendencias_resumen = _compute_tendencias_resumen(db)

        return {
            "cut_key": cut_key,
            "cut_date": latest_cut.cut_date.isoformat() if latest_cut.cut_date else "",
            "kpis": kpis,
            "cohortes": cohortes,
            "tendencias_resumen": tendencias_resumen,
        }
    finally:
        db.close()


def _compute_tendencias_resumen(db: Session, n_cuts: int = 6) -> List[Dict[str, Any]]:
    """Para cada KPI, devuelve los últimos n_cuts valores ordenados por fecha."""
    cuts = (
        db.query(IntelicoopAnalyticCut)
        .order_by(IntelicoopAnalyticCut.cut_date.desc())
        .limit(n_cuts)
        .all()
    )
    if not cuts:
        return []
    cut_keys = [c.cut_key for c in cuts]
    cut_date_by_key = {c.cut_key: c.cut_date.isoformat() if c.cut_date else "" for c in cuts}

    rows = (
        db.query(IntelicoopKpiSnapshot)
        .filter(IntelicoopKpiSnapshot.cut_key.in_(cut_keys))
        .order_by(IntelicoopKpiSnapshot.kpi_key.asc(), IntelicoopKpiSnapshot.cut_date.asc())
        .all()
    )
    by_kpi: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        by_kpi.setdefault(row.kpi_key, []).append({
            "cut_key": row.cut_key,
            "cut_date": cut_date_by_key.get(row.cut_key, ""),
            "value": round(float(row.metric_value or 0), 4),
            "semaforo": row.semaforo,
        })
    result = []
    for kpi_key, points in by_kpi.items():
        cat = KPI_CATALOG.get(kpi_key, {})
        result.append({
            "kpi_key": kpi_key,
            "label": cat.get("label", kpi_key),
            "metric_type": cat.get("metric_type", "observado"),
            "direction": cat.get("direction", "higher"),
            "puntos": sorted(points, key=lambda p: p["cut_date"]),
        })
    return result


def get_tendencias(kpi_key: str = "imor_pct", n_cuts: int = 12) -> Dict[str, Any]:
    """Devuelve la serie histórica de un KPI a través de todos los cortes disponibles."""
    db = _db()
    try:
        rows = (
            db.query(IntelicoopKpiSnapshot, IntelicoopAnalyticCut.cut_type)
            .join(IntelicoopAnalyticCut, IntelicoopAnalyticCut.cut_key == IntelicoopKpiSnapshot.cut_key)
            .filter(IntelicoopKpiSnapshot.kpi_key == kpi_key)
            .order_by(IntelicoopKpiSnapshot.cut_date.desc())
            .limit(n_cuts)
            .all()
        )
        cat = KPI_CATALOG.get(kpi_key, {})
        puntos = [
            {
                "cut_key": row.cut_key,
                "cut_date": row.cut_date.isoformat() if row.cut_date else "",
                "cut_type": ct,
                "value": round(float(row.metric_value or 0), 4),
                "semaforo": row.semaforo,
                "metric_type": row.metric_type,
            }
            for row, ct in rows
        ]
        return {
            "kpi_key": kpi_key,
            "label": cat.get("label", kpi_key),
            "metric_type": cat.get("metric_type", "observado"),
            "direction": cat.get("direction", "higher"),
            "umbrales": {
                "verde": cat.get("verde"),
                "amarillo": cat.get("amarillo"),
            },
            "puntos": sorted(puntos, key=lambda p: p["cut_date"]),
        }
    finally:
        db.close()


def get_cohortes(dimension: str | None = None) -> Dict[str, Any]:
    """Devuelve cohortes del último corte, opcionalmente filtradas por dimensión."""
    db = _db()
    try:
        latest_cut = (
            db.query(IntelicoopAnalyticCut)
            .order_by(IntelicoopAnalyticCut.cut_date.desc(), IntelicoopAnalyticCut.id.desc())
            .first()
        )
        if not latest_cut:
            return {"cohortes": {}, "cut_key": None}
        cut_key = str(latest_cut.cut_key)
        query = db.query(IntelicoopCohorteSnapshot).filter(IntelicoopCohorteSnapshot.cut_key == cut_key)
        if dimension:
            query = query.filter(IntelicoopCohorteSnapshot.dimension == dimension)
        rows = query.order_by(
            IntelicoopCohorteSnapshot.dimension.asc(),
            IntelicoopCohorteSnapshot.bucket.asc(),
            IntelicoopCohorteSnapshot.metric_key.asc(),
        ).all()
        cohortes: Dict[str, List[Dict[str, Any]]] = {}
        for row in rows:
            cohortes.setdefault(row.dimension, []).append({
                "bucket": row.bucket,
                "metric_key": row.metric_key,
                "metric_value": round(float(row.metric_value or 0), 4),
                "n_records": row.n_records,
                "metric_type": row.metric_type,
            })
        return {"cut_key": cut_key, "cohortes": cohortes}
    finally:
        db.close()


def get_basic_catalogs() -> Dict[str, Any]:
    db = _db()
    try:
        socios = db.query(IntelicoopSocio).order_by(IntelicoopSocio.nombre.asc()).all()
        return {
            "socios": [
                {
                    "id": row.id,
                    "nombre": row.nombre,
                    "segmento": row.segmento,
                }
                for row in socios
            ],
            "segmentos": [
                {"value": "hormiga", "label": "Ahorrador Hormiga"},
                {"value": "gran_ahorrador", "label": "Gran Ahorrador"},
                {"value": "inactivo", "label": "Inactivo"},
            ],
            "estados_credito": [
                {"value": "solicitado", "label": "Solicitado"},
                {"value": "aprobado", "label": "Aprobado"},
                {"value": "rechazado", "label": "Rechazado"},
            ],
            "estados_campana": [
                {"value": "borrador", "label": "Borrador"},
                {"value": "activa", "label": "Activa"},
                {"value": "finalizada", "label": "Finalizada"},
            ],
            "tipos_cuenta": [
                {"value": "ahorro", "label": "Ahorro"},
                {"value": "aportacion", "label": "Aportacion"},
            ],
            "tipos_transaccion": [
                {"value": "deposito", "label": "Deposito"},
                {"value": "retiro", "label": "Retiro"},
            ],
            "cuentas": [
                {
                    "id": row.id,
                    "socio_id": row.socio_id,
                    "tipo": row.tipo,
                    "saldo": round(float(row.saldo or 0), 2),
                }
                for row in db.query(IntelicoopCuenta).order_by(IntelicoopCuenta.id.asc()).all()
            ],
        }
    finally:
        db.close()


SEGMENTATION_LABELS = {
    "integral_fiel": "Integral fiel",
    "crecimiento": "Crecimiento",
    "ahorrador_activo": "Ahorrador activo",
    "alerta_temprana": "Alerta temprana",
    "pasivo": "Pasivo",
}


def _clamp01(value: float) -> float:
    return round(max(0.0, min(1.0, float(value))), 4)


def _score_level(value: float) -> str:
    if value >= 0.67:
        return "alto"
    if value >= 0.34:
        return "medio"
    return "bajo"


def _get_latest_cut_key(db: Session) -> str | None:
    latest_cut = (
        db.query(IntelicoopAnalyticCut)
        .order_by(IntelicoopAnalyticCut.cut_date.desc(), IntelicoopAnalyticCut.id.desc())
        .first()
    )
    if not latest_cut:
        return None
    return str(latest_cut.cut_key)


def _build_live_socio_features(db: Session) -> List[Dict[str, Any]]:
    now = datetime.utcnow()
    socios = db.query(IntelicoopSocio).order_by(IntelicoopSocio.id.asc()).all()
    creditos_agg: Dict[int, Dict[str, Any]] = {
        int(sid): {"creditos_total": int(total or 0), "monto_total": float(monto or 0)}
        for sid, total, monto in db.query(
            IntelicoopCredito.socio_id,
            func.count(IntelicoopCredito.id),
            func.coalesce(func.sum(IntelicoopCredito.monto), 0),
        ).group_by(IntelicoopCredito.socio_id).all()
    }
    creditos_activos_agg: Dict[int, int] = {
        int(sid): int(total or 0)
        for sid, total in db.query(
            IntelicoopCredito.socio_id,
            func.count(IntelicoopCredito.id),
        ).filter(
            IntelicoopCredito.estado.in_(["solicitado", "aprobado", "vigente", "mora"])
        ).group_by(IntelicoopCredito.socio_id).all()
    }
    creditos_mora_agg: Dict[int, int] = {
        int(sid): int(total or 0)
        for sid, total in db.query(
            IntelicoopCredito.socio_id,
            func.count(IntelicoopCredito.id),
        ).filter(IntelicoopCredito.estado == "mora").group_by(IntelicoopCredito.socio_id).all()
    }
    pagos_agg: Dict[int, float] = {
        int(sid): float(total or 0)
        for sid, total in db.query(
            IntelicoopCredito.socio_id,
            func.coalesce(func.sum(IntelicoopHistorialPago.monto), 0),
        ).join(
            IntelicoopHistorialPago,
            IntelicoopHistorialPago.credito_id == IntelicoopCredito.id,
        ).group_by(IntelicoopCredito.socio_id).all()
    }
    cuentas_agg: Dict[int, Dict[str, Any]] = {
        int(sid): {"cuentas_total": int(total or 0), "saldo_total": float(saldo or 0)}
        for sid, total, saldo in db.query(
            IntelicoopCuenta.socio_id,
            func.count(IntelicoopCuenta.id),
            func.coalesce(func.sum(IntelicoopCuenta.saldo), 0),
        ).group_by(IntelicoopCuenta.socio_id).all()
    }
    tx_agg: Dict[int, int] = {
        int(sid): int(total or 0)
        for sid, total in db.query(
            IntelicoopCuenta.socio_id,
            func.count(IntelicoopTransaccion.id),
        ).join(
            IntelicoopTransaccion,
            IntelicoopTransaccion.cuenta_id == IntelicoopCuenta.id,
        ).group_by(IntelicoopCuenta.socio_id).all()
    }
    campanas_part_agg: Dict[int, int] = {
        int(sid): int(total or 0)
        for sid, total in db.query(
            IntelicoopContactoCampania.socio_id,
            func.count(IntelicoopContactoCampania.id),
        ).group_by(IntelicoopContactoCampania.socio_id).all()
    }
    campanas_conv_agg: Dict[int, int] = {
        int(sid): int(total or 0)
        for sid, total in db.query(
            IntelicoopSeguimientoCampania.socio_id,
            func.count(IntelicoopSeguimientoCampania.id),
        ).filter(
            IntelicoopSeguimientoCampania.conversion == 1
        ).group_by(IntelicoopSeguimientoCampania.socio_id).all()
    }
    latest_scoring: Dict[int, Dict[str, Any]] = {}
    for row in db.query(IntelicoopScoringResult).filter(
        IntelicoopScoringResult.socio_id.isnot(None)
    ).order_by(
        IntelicoopScoringResult.socio_id.asc(),
        IntelicoopScoringResult.fecha_creacion.desc(),
        IntelicoopScoringResult.id.desc(),
    ).all():
        socio_id = int(row.socio_id or 0)
        if socio_id and socio_id not in latest_scoring:
            latest_scoring[socio_id] = {
                "score": float(row.score or 0),
                "riesgo": str(row.riesgo or "sin_dato"),
                "ingreso_mensual": float(row.ingreso_mensual or 0),
                "deuda_actual": float(row.deuda_actual or 0),
            }

    rows: List[Dict[str, Any]] = []
    for socio in socios:
        socio_id = int(socio.id)
        credito_data = creditos_agg.get(socio_id, {})
        cuenta_data = cuentas_agg.get(socio_id, {})
        scoring_data = latest_scoring.get(socio_id, {})
        monto_creditos_total = float(credito_data.get("monto_total", 0))
        pagos_total = float(pagos_agg.get(socio_id, 0))
        ingreso = float(scoring_data.get("ingreso_mensual", 0))
        deuda = float(scoring_data.get("deuda_actual", 0))
        rows.append(
            {
                "socio_id": socio_id,
                "socio_nombre": str(socio.nombre or ""),
                "segmento_actual": str(socio.segmento or "inactivo"),
                "creditos_total": int(credito_data.get("creditos_total", 0)),
                "creditos_activos": int(creditos_activos_agg.get(socio_id, 0)),
                "creditos_mora": int(creditos_mora_agg.get(socio_id, 0)),
                "monto_creditos_total": round(monto_creditos_total, 2),
                "pagos_total": round(pagos_total, 2),
                "tasa_cumplimiento_pagos": round(pagos_total / monto_creditos_total, 4) if monto_creditos_total > 0 else 0.0,
                "ratio_deuda_ingreso": round(deuda / ingreso, 4) if ingreso > 0 else 0.0,
                "cuentas_total": int(cuenta_data.get("cuentas_total", 0)),
                "saldo_cuentas_total": round(float(cuenta_data.get("saldo_total", 0)), 2),
                "transacciones_total": int(tx_agg.get(socio_id, 0)),
                "campanas_participadas": int(campanas_part_agg.get(socio_id, 0)),
                "campanas_convertidas": int(campanas_conv_agg.get(socio_id, 0)),
                "dias_como_socio": max(0, (now - socio.fecha_registro).days) if socio.fecha_registro else 0,
                "num_productos": int(credito_data.get("creditos_total", 0)) + int(cuenta_data.get("cuentas_total", 0)),
                "score_scoring_reciente": round(float(scoring_data.get("score", 0)), 4),
                "riesgo_scoring_reciente": str(scoring_data.get("riesgo", "sin_dato")),
            }
        )
    return rows


def _get_socio_features_for_segmentation(db: Session) -> tuple[str | None, List[Dict[str, Any]]]:
    cut_key = _get_latest_cut_key(db)
    if cut_key:
        rows = (
            db.query(IntelicoopSocioFeatureSnapshot)
            .filter(IntelicoopSocioFeatureSnapshot.cut_key == cut_key)
            .order_by(IntelicoopSocioFeatureSnapshot.socio_id.asc())
            .all()
        )
        if rows:
            return cut_key, [
                {
                    "socio_id": int(row.socio_id),
                    "socio_nombre": row.socio_nombre,
                    "segmento_actual": row.segmento_actual,
                    "creditos_total": int(row.creditos_total or 0),
                    "creditos_activos": int(row.creditos_activos or 0),
                    "creditos_mora": int(row.creditos_mora or 0),
                    "monto_creditos_total": round(float(row.monto_creditos_total or 0), 2),
                    "pagos_total": round(float(row.pagos_total or 0), 2),
                    "tasa_cumplimiento_pagos": round(float(row.tasa_cumplimiento_pagos or 0), 4),
                    "ratio_deuda_ingreso": round(float(row.ratio_deuda_ingreso or 0), 4),
                    "cuentas_total": int(row.cuentas_total or 0),
                    "saldo_cuentas_total": round(float(row.saldo_cuentas_total or 0), 2),
                    "transacciones_total": int(row.transacciones_total or 0),
                    "campanas_participadas": int(row.campanas_participadas or 0),
                    "campanas_convertidas": int(row.campanas_convertidas or 0),
                    "dias_como_socio": int(row.dias_como_socio or 0),
                    "num_productos": int(row.num_productos or 0),
                    "score_scoring_reciente": round(float(row.score_scoring_reciente or 0), 4),
                    "riesgo_scoring_reciente": row.riesgo_scoring_reciente,
                }
                for row in rows
            ]
    return None, _build_live_socio_features(db)


def _derive_automatic_segment(feature_row: Dict[str, Any]) -> str:
    if (
        int(feature_row.get("creditos_mora", 0)) > 0
        or float(feature_row.get("ratio_deuda_ingreso", 0)) >= 0.55
        or str(feature_row.get("riesgo_scoring_reciente", "")) == "alto"
    ):
        return "alerta_temprana"
    if (
        float(feature_row.get("saldo_cuentas_total", 0)) >= 5000
        and int(feature_row.get("transacciones_total", 0)) >= 4
        and int(feature_row.get("num_productos", 0)) >= 2
    ):
        return "integral_fiel"
    if (
        int(feature_row.get("campanas_convertidas", 0)) >= 1
        or (
            int(feature_row.get("creditos_activos", 0)) >= 1
            and float(feature_row.get("tasa_cumplimiento_pagos", 0)) >= 0.7
        )
    ):
        return "crecimiento"
    if (
        float(feature_row.get("saldo_cuentas_total", 0)) >= 1000
        or int(feature_row.get("transacciones_total", 0)) >= 2
    ):
        return "ahorrador_activo"
    return "pasivo"


def _build_segmentation_row(feature_row: Dict[str, Any]) -> Dict[str, Any]:
    segmento = _derive_automatic_segment(feature_row)
    riesgo_scoring = str(feature_row.get("riesgo_scoring_reciente", "sin_dato"))
    comercial = _clamp01(
        0.12
        + min(int(feature_row.get("num_productos", 0)), 3) * 0.10
        + min(int(feature_row.get("transacciones_total", 0)), 8) * 0.035
        + min(float(feature_row.get("saldo_cuentas_total", 0)) / 5000.0, 1.0) * 0.18
        + min(int(feature_row.get("campanas_participadas", 0)), 4) * 0.06
        + min(int(feature_row.get("campanas_convertidas", 0)), 2) * 0.12
        + (0.06 if riesgo_scoring == "bajo" else -0.08 if riesgo_scoring == "alto" else 0.0)
    )
    riesgo_temprano = _clamp01(
        0.04
        + min(int(feature_row.get("creditos_mora", 0)), 2) * 0.34
        + min(float(feature_row.get("ratio_deuda_ingreso", 0)), 1.0) * 0.42
        + max(0.0, 1.0 - float(feature_row.get("tasa_cumplimiento_pagos", 0))) * 0.18
        + (0.18 if riesgo_scoring == "alto" else 0.08 if riesgo_scoring == "medio" else 0.0)
    )
    abandono = _clamp01(
        0.06
        + (0.28 if int(feature_row.get("transacciones_total", 0)) == 0 else 0.0)
        + (0.18 if int(feature_row.get("creditos_activos", 0)) == 0 else 0.0)
        + (0.16 if float(feature_row.get("saldo_cuentas_total", 0)) < 250 else 0.0)
        + (0.10 if int(feature_row.get("campanas_participadas", 0)) == 0 else 0.0)
        + (0.08 if int(feature_row.get("dias_como_socio", 0)) > 180 and int(feature_row.get("num_productos", 0)) <= 1 else 0.0)
        - (0.16 if segmento == "integral_fiel" else 0.10 if segmento == "crecimiento" else 0.0)
    )
    conversion = _clamp01(
        0.08
        + comercial * 0.48
        + min(int(feature_row.get("campanas_participadas", 0)), 3) * 0.06
        + min(int(feature_row.get("campanas_convertidas", 0)), 2) * 0.12
        - riesgo_temprano * 0.16
        - abandono * 0.18
    )
    return {
        "socio_id": int(feature_row.get("socio_id", 0)),
        "socio_nombre": feature_row.get("socio_nombre", ""),
        "segmento_actual": feature_row.get("segmento_actual", "inactivo"),
        "segmento_automatico": segmento,
        "segmento_label": SEGMENTATION_LABELS.get(segmento, segmento),
        "comercial_score": comercial,
        "comercial_nivel": _score_level(comercial),
        "riesgo_temprano_score": riesgo_temprano,
        "riesgo_temprano_nivel": _score_level(riesgo_temprano),
        "conversion_score": conversion,
        "conversion_nivel": _score_level(conversion),
        "abandono_score": abandono,
        "abandono_nivel": _score_level(abandono),
        "num_productos": int(feature_row.get("num_productos", 0)),
        "saldo_cuentas_total": round(float(feature_row.get("saldo_cuentas_total", 0)), 2),
        "transacciones_total": int(feature_row.get("transacciones_total", 0)),
        "creditos_activos": int(feature_row.get("creditos_activos", 0)),
        "creditos_mora": int(feature_row.get("creditos_mora", 0)),
        "campanas_participadas": int(feature_row.get("campanas_participadas", 0)),
        "campanas_convertidas": int(feature_row.get("campanas_convertidas", 0)),
        "ratio_deuda_ingreso": round(float(feature_row.get("ratio_deuda_ingreso", 0)), 4),
        "tasa_cumplimiento_pagos": round(float(feature_row.get("tasa_cumplimiento_pagos", 0)), 4),
        "score_scoring_reciente": round(float(feature_row.get("score_scoring_reciente", 0)), 4),
        "riesgo_scoring_reciente": feature_row.get("riesgo_scoring_reciente", "sin_dato"),
    }


def get_segmentation_propensity_summary() -> Dict[str, Any]:
    db = _db()
    try:
        cut_key, feature_rows = _get_socio_features_for_segmentation(db)
        socios = [_build_segmentation_row(row) for row in feature_rows]
        socios.sort(
            key=lambda row: (
                -row["comercial_score"],
                row["abandono_score"],
                row["socio_nombre"],
            )
        )
        segments: Dict[str, List[Dict[str, Any]]] = {}
        for row in socios:
            segments.setdefault(row["segmento_automatico"], []).append(row)

        segmentos = [
            {
                "segmento": key,
                "label": SEGMENTATION_LABELS.get(key, key),
                "total": len(rows),
                "socios": [
                    {
                        "socio_id": row["socio_id"],
                        "socio_nombre": row["socio_nombre"],
                        "comercial_score": row["comercial_score"],
                        "riesgo_temprano_score": row["riesgo_temprano_score"],
                        "abandono_score": row["abandono_score"],
                    }
                    for row in rows[:5]
                ],
            }
            for key, rows in sorted(segments.items(), key=lambda item: (-len(item[1]), item[0]))
        ]

        top_oportunidades = sorted(
            socios,
            key=lambda row: (-row["comercial_score"], -row["conversion_score"], row["abandono_score"]),
        )[:5]
        alertas_tempranas = sorted(
            [row for row in socios if row["riesgo_temprano_score"] >= 0.5],
            key=lambda row: (-row["riesgo_temprano_score"], -row["ratio_deuda_ingreso"], row["socio_nombre"]),
        )[:5]
        riesgo_abandono = sorted(
            [row for row in socios if row["abandono_score"] >= 0.45],
            key=lambda row: (-row["abandono_score"], row["comercial_score"], row["socio_nombre"]),
        )[:5]
        prospectos = [
            {
                "id": row.id,
                "nombre": row.nombre,
                "fuente": row.fuente,
                "score_propension": round(float(row.score_propension or 0), 4),
                "conversion_estimada": _clamp01(0.12 + float(row.score_propension or 0) * 0.72),
            }
            for row in db.query(IntelicoopProspecto)
            .order_by(IntelicoopProspecto.score_propension.desc(), IntelicoopProspecto.id.desc())
            .limit(10)
            .all()
        ]
        total_socios = len(socios)
        avg = lambda key: round(sum(float(row.get(key, 0)) for row in socios) / total_socios, 4) if total_socios else 0.0
        return {
            "cut_key": cut_key,
            "resumen": {
                "total_socios": total_socios,
                "segmentos_total": len(segmentos),
                "comercial_promedio": avg("comercial_score"),
                "riesgo_temprano_promedio": avg("riesgo_temprano_score"),
                "conversion_promedio": avg("conversion_score"),
                "abandono_promedio": avg("abandono_score"),
                "oportunidades_comerciales": sum(1 for row in socios if row["comercial_score"] >= 0.6),
                "alertas_tempranas": sum(1 for row in socios if row["riesgo_temprano_score"] >= 0.5),
                "abandono_alto": sum(1 for row in socios if row["abandono_score"] >= 0.45),
            },
            "segmentos": segmentos,
            "socios": socios,
            "top_oportunidades": top_oportunidades,
            "alertas_tempranas": alertas_tempranas,
            "riesgo_abandono": riesgo_abandono,
            "prospectos": prospectos,
        }
    finally:
        db.close()


def _quality_summary_for_cut(db: Session, cut_key: str | None) -> Dict[str, Any]:
    if not cut_key:
        return {"total_rules": 0, "failed_rules": 0, "warn_rules": 0, "pass_rules": 0}
    rows = db.query(IntelicoopDataQualitySnapshot).filter(IntelicoopDataQualitySnapshot.cut_key == cut_key).all()
    return {
        "total_rules": len(rows),
        "failed_rules": sum(1 for row in rows if str(row.status) == "fail"),
        "warn_rules": sum(1 for row in rows if str(row.status) == "warn"),
        "pass_rules": sum(1 for row in rows if str(row.status) == "pass"),
    }


def _compute_batch_scoring_inputs(db: Session, socio_id: int) -> Dict[str, Any]:
    socio = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == socio_id).first()
    latest_scoring = (
        db.query(IntelicoopScoringResult)
        .filter(IntelicoopScoringResult.socio_id == socio_id)
        .order_by(IntelicoopScoringResult.fecha_creacion.desc(), IntelicoopScoringResult.id.desc())
        .first()
    )
    creditos = db.query(IntelicoopCredito).filter(IntelicoopCredito.socio_id == socio_id).all()
    pagos_por_credito = {
        int(credito_id): float(total or 0)
        for credito_id, total in db.query(
            IntelicoopHistorialPago.credito_id,
            func.coalesce(func.sum(IntelicoopHistorialPago.monto), 0),
        )
        .join(IntelicoopCredito, IntelicoopCredito.id == IntelicoopHistorialPago.credito_id)
        .filter(IntelicoopCredito.socio_id == socio_id)
        .group_by(IntelicoopHistorialPago.credito_id)
        .all()
    }
    ingreso = float(latest_scoring.ingreso_mensual or 0) if latest_scoring else 0.0
    if ingreso <= 0:
        ingreso = max((float(row.ingreso_mensual or 0) for row in creditos), default=0.0)
    deuda = 0.0
    for credito in creditos:
        monto = float(credito.monto or 0)
        pagado = float(pagos_por_credito.get(int(credito.id), 0))
        if str(credito.estado or "") not in {"rechazado", "liquidado"}:
            deuda += max(0.0, monto - pagado)
    if deuda <= 0 and latest_scoring:
        deuda = float(latest_scoring.deuda_actual or 0)
    antiguedad_meses = 0
    if socio and socio.fecha_registro:
        antiguedad_meses = max(0, (_utcnow() - socio.fecha_registro).days // 30)
    elif latest_scoring:
        antiguedad_meses = int(latest_scoring.antiguedad_meses or 0)
    credito_ref = max(creditos, key=lambda row: row.id, default=None)
    return {
        "socio_id": socio_id,
        "credito_id": int(credito_ref.id) if credito_ref else None,
        "ingreso_mensual": round(ingreso, 2),
        "deuda_actual": round(deuda, 2),
        "antiguedad_meses": int(antiguedad_meses),
    }


def _run_foundation_refresh(db: Session, reference_at: datetime | None = None) -> Dict[str, Any]:
    return materialize_foundation_cut(reference_at=reference_at, cut_type="daily_close")


def _run_segmentation_refresh(db: Session) -> Dict[str, Any]:
    cut_key, feature_rows = _get_socio_features_for_segmentation(db)
    updated = 0
    segments: Dict[str, int] = {}
    for feature_row in feature_rows:
        socio_id = int(feature_row.get("socio_id", 0))
        if not socio_id:
            continue
        segmento = _derive_automatic_segment(feature_row)
        socio = db.query(IntelicoopSocio).filter(IntelicoopSocio.id == socio_id).first()
        if socio and str(socio.segmento or "") != segmento:
            socio.segmento = segmento
            updated += 1
        segments[segmento] = segments.get(segmento, 0) + 1
    db.flush()
    return {
        "cut_key": cut_key,
        "socios_evaluados": len(feature_rows),
        "socios_actualizados": updated,
        "segmentos": segments,
    }


def _run_scoring_refresh(db: Session, cut_key: str | None) -> Dict[str, Any]:
    socios = db.query(IntelicoopSocio).order_by(IntelicoopSocio.id.asc()).all()
    created = 0
    with_data = 0
    for socio in socios:
        inputs = _compute_batch_scoring_inputs(db, int(socio.id))
        if inputs["ingreso_mensual"] <= 0 and inputs["deuda_actual"] <= 0 and inputs["antiguedad_meses"] <= 0:
            continue
        with_data += 1
        scoring_eval = evaluate_scoring_v2(
            ingreso_mensual=inputs["ingreso_mensual"],
            deuda_actual=inputs["deuda_actual"],
            antiguedad_meses=inputs["antiguedad_meses"],
            solicitud_id=f"batch-score-{cut_key or 'live'}-{socio.id}",
            socio_id=int(socio.id),
            credito_id=inputs["credito_id"],
        )
        create_scoring_result(
            {
                "ingreso_mensual": inputs["ingreso_mensual"],
                "deuda_actual": inputs["deuda_actual"],
                "antiguedad_meses": inputs["antiguedad_meses"],
                **scoring_eval,
            }
        )
        created += 1
    return {
        "cut_key": cut_key,
        "socios_total": len(socios),
        "socios_con_datos": with_data,
        "scorings_creados": created,
    }


def _run_alerts_refresh(db: Session, batch_run_id: int | None, cut_key: str | None) -> Dict[str, Any]:
    if cut_key:
        db.query(IntelicoopBatchAlert).filter(IntelicoopBatchAlert.cut_key == cut_key).delete(synchronize_session=False)
    segmentation = get_segmentation_propensity_summary()
    alerts: List[Dict[str, Any]] = []
    for row in segmentation.get("alertas_tempranas", []):
        alerts.append(
            {
                "alert_type": "riesgo_temprano",
                "severity": "alta" if float(row.get("riesgo_temprano_score", 0)) >= 0.75 else "media",
                "entity_type": "socio",
                "entity_id": int(row.get("socio_id", 0)) or None,
                "entity_label": str(row.get("socio_nombre", "")),
                "score": float(row.get("riesgo_temprano_score", 0)),
                "details": row,
            }
        )
    for row in segmentation.get("riesgo_abandono", []):
        alerts.append(
            {
                "alert_type": "abandono_probable",
                "severity": "alta" if float(row.get("abandono_score", 0)) >= 0.7 else "media",
                "entity_type": "socio",
                "entity_id": int(row.get("socio_id", 0)) or None,
                "entity_label": str(row.get("socio_nombre", "")),
                "score": float(row.get("abandono_score", 0)),
                "details": row,
            }
        )
    for row in segmentation.get("top_oportunidades", [])[:5]:
        alerts.append(
            {
                "alert_type": "oportunidad_comercial",
                "severity": "media",
                "entity_type": "socio",
                "entity_id": int(row.get("socio_id", 0)) or None,
                "entity_label": str(row.get("socio_nombre", "")),
                "score": float(row.get("conversion_score", 0)),
                "details": row,
            }
        )
    for item in alerts:
        db.add(
            IntelicoopBatchAlert(
                batch_run_id=batch_run_id,
                cut_key=cut_key,
                alert_type=item["alert_type"],
                severity=item["severity"],
                entity_type=item["entity_type"],
                entity_id=item["entity_id"],
                entity_label=item["entity_label"],
                score=item["score"],
                status="open",
                details_json=_json_dump(item["details"]),
            )
        )
    db.flush()
    severities: Dict[str, int] = {}
    for item in alerts:
        severities[item["severity"]] = severities.get(item["severity"], 0) + 1
    return {
        "cut_key": cut_key,
        "alertas_generadas": len(alerts),
        "severidades": severities,
    }


def _collect_governance_metrics(db: Session, model_version: str, cut_key: str | None) -> Dict[str, Any]:
    scoring_rows = (
        db.query(IntelicoopScoringResult)
        .filter(IntelicoopScoringResult.model_version == model_version)
        .order_by(IntelicoopScoringResult.fecha_creacion.desc(), IntelicoopScoringResult.id.desc())
        .all()
    )
    total = len(scoring_rows)
    recientes = scoring_rows[: min(20, total)]
    score_prom = round(sum(float(row.score or 0) for row in recientes) / len(recientes), 4) if recientes else 0.0
    confianza_prom = round(sum(float(row.confianza or 0) for row in recientes if row.confianza is not None) / max(1, sum(1 for row in recientes if row.confianza is not None)), 4) if recientes else 0.0
    share_high = round(sum(1 for row in recientes if str(row.riesgo) == "alto") / len(recientes), 4) if recientes else 0.0
    ratio_prom = round(sum(float(row.deuda_actual or 0) / float(row.ingreso_mensual or 1) if float(row.ingreso_mensual or 0) > 0 else 1.0 for row in recientes) / len(recientes), 4) if recientes else 0.0
    monitoring = {
        "total_inferencias": total,
        "muestra_reciente": len(recientes),
        "score_promedio_reciente": score_prom,
        "confianza_promedio_reciente": confianza_prom,
        "share_riesgo_alto_reciente": share_high,
        "ratio_deuda_ingreso_promedio_reciente": ratio_prom,
        "cut_key": cut_key,
    }
    explainability = {
        "trazas_total": int(
            db.query(func.count(IntelicoopScoringTraza.id))
            .filter(IntelicoopScoringTraza.model_version == model_version)
            .scalar()
            or 0
        ),
        "razones_promedio": round(
            sum(len(_json_load(row.razones_json, [])) for row in db.query(IntelicoopScoringTraza).filter(IntelicoopScoringTraza.model_version == model_version).limit(20).all()) / max(
                1,
                len(db.query(IntelicoopScoringTraza).filter(IntelicoopScoringTraza.model_version == model_version).limit(20).all()),
            ),
            4,
        ) if total else 0.0,
        "modelo_version": model_version,
        "cobertura_explicacion": round(
            (
                db.query(func.count(IntelicoopScoringTraza.id))
                .filter(IntelicoopScoringTraza.model_version == model_version)
                .scalar()
                or 0
            ) / max(1, total),
            4,
        ),
    }
    return {"monitoring": monitoring, "explainability": explainability}


def _compute_drift_snapshots(db: Session, model_version: str, cut_key: str | None) -> List[Dict[str, Any]]:
    recent = (
        db.query(IntelicoopScoringResult)
        .filter(IntelicoopScoringResult.model_version == model_version)
        .order_by(IntelicoopScoringResult.fecha_creacion.desc(), IntelicoopScoringResult.id.desc())
        .limit(20)
        .all()
    )
    baseline = (
        db.query(IntelicoopScoringResult)
        .filter(IntelicoopScoringResult.model_version == model_version)
        .order_by(IntelicoopScoringResult.fecha_creacion.asc(), IntelicoopScoringResult.id.asc())
        .limit(20)
        .all()
    )
    def _avg(rows: List[Any], attr: str, ratio: bool = False) -> float:
        if not rows:
            return 0.0
        values = []
        for row in rows:
            if ratio:
                ingreso = float(row.ingreso_mensual or 0)
                deuda = float(row.deuda_actual or 0)
                values.append(deuda / ingreso if ingreso > 0 else 1.0)
            else:
                values.append(float(getattr(row, attr) or 0))
        return round(sum(values) / len(values), 4)
    metrics = [
        ("score", _avg(baseline, "score"), _avg(recent, "score")),
        ("confianza", _avg(baseline, "confianza"), _avg(recent, "confianza")),
        ("ratio_deuda_ingreso", _avg(baseline, "score", ratio=True), _avg(recent, "score", ratio=True)),
    ]
    db.query(IntelicoopModelDriftSnapshot).filter(
        IntelicoopModelDriftSnapshot.cut_key == cut_key,
        IntelicoopModelDriftSnapshot.model_version == model_version,
    ).delete(synchronize_session=False)
    rows = []
    for feature_key, baseline_value, current_value in metrics:
        drift_score = round(abs(current_value - baseline_value), 4)
        drift_level = _drift_level(drift_score)
        row = IntelicoopModelDriftSnapshot(
            cut_key=cut_key,
            model_version=model_version,
            feature_key=feature_key,
            baseline_value=baseline_value,
            current_value=current_value,
            drift_score=drift_score,
            drift_level=drift_level,
            details_json=_json_dump({"window_baseline": len(baseline), "window_current": len(recent)}),
        )
        db.add(row)
        db.flush()
        rows.append(_drift_snapshot_dict(row))
    return rows


def _evaluate_business_rules(
    db: Session,
    monitoring: Dict[str, Any],
    drift_rows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rules = _ensure_business_rules(db)
    drift_max = max((float(row.get("drift_score", 0)) for row in drift_rows), default=0.0)
    evaluations = []
    for rule in rules:
        threshold = float(rule.threshold_value) if rule.threshold_value is not None else None
        if rule.rule_key == "max_high_risk_share":
            current = float(monitoring.get("share_riesgo_alto_reciente", 0))
            status = "fail" if threshold is not None and current > threshold else "pass"
        elif rule.rule_key == "max_ratio_deuda_ingreso_avg":
            current = float(monitoring.get("ratio_deuda_ingreso_promedio_reciente", 0))
            status = "warn" if threshold is not None and current > threshold else "pass"
        elif rule.rule_key == "max_drift_score":
            current = drift_max
            status = "fail" if threshold is not None and current > threshold else "pass"
        else:
            current = 0.0
            status = "pass"
        evaluations.append(
            {
                "rule_key": rule.rule_key,
                "rule_label": rule.rule_label,
                "severity": rule.severity,
                "threshold_value": threshold,
                "current_value": round(current, 4),
                "status": status,
            }
        )
    return evaluations


def _propose_recalibration(
    db: Session,
    model_version: str,
    drift_rows: List[Dict[str, Any]],
    rule_evaluations: List[Dict[str, Any]],
    monitoring: Dict[str, Any],
) -> Dict[str, Any]:
    drift_max = max((float(row.get("drift_score", 0)) for row in drift_rows), default=0.0)
    failed_rules = [row for row in rule_evaluations if row["status"] == "fail"]
    trigger_reason = ""
    status = "stable"
    if drift_max >= 0.2:
        trigger_reason = "drift_alto"
        status = "required"
    elif failed_rules:
        trigger_reason = "reglas_negocio"
        status = "proposed"
    elif float(monitoring.get("share_riesgo_alto_reciente", 0)) >= 0.3:
        trigger_reason = "desempeno_riesgo"
        status = "proposed"
    latest = (
        db.query(IntelicoopModelRecalibration)
        .filter(IntelicoopModelRecalibration.model_version == model_version)
        .order_by(IntelicoopModelRecalibration.created_at.desc(), IntelicoopModelRecalibration.id.desc())
        .first()
    )
    if status in {"required", "proposed"} and (latest is None or latest.status == "stable"):
        row = IntelicoopModelRecalibration(
            model_version=model_version,
            trigger_reason=trigger_reason,
            status=status,
            notes="Generado automaticamente por gobernanza del modelo.",
            before_metrics_json=_json_dump(monitoring),
            after_metrics_json=_json_dump({"target": "pending"}),
        )
        db.add(row)
        db.flush()
        _create_audit_log(
            db,
            event_type="model_recalibration_proposed",
            entity_type="model_version",
            entity_id=row.id,
            actor="system",
            model_version=model_version,
            details={"trigger_reason": trigger_reason, "status": status},
        )
        return _recalibration_dict(row)
    return {
        "model_version": model_version,
        "trigger_reason": trigger_reason or "none",
        "status": status,
        "before_metrics": monitoring,
        "after_metrics": {},
    }


def _run_governance_refresh(db: Session, actor: str = "system") -> Dict[str, Any]:
    _ensure_business_rules(db)
    latest_version = (
        db.query(IntelicoopModelVersionRegistry)
        .filter(IntelicoopModelVersionRegistry.activo == 1)
        .order_by(IntelicoopModelVersionRegistry.fecha_registro.desc(), IntelicoopModelVersionRegistry.id.desc())
        .first()
    )
    model_version = latest_version.version_key if latest_version else "intelicoop_scoring_v1"
    cut_key = _get_latest_cut_key(db)
    metrics = _collect_governance_metrics(db, model_version=model_version, cut_key=cut_key)
    drift_rows = _compute_drift_snapshots(db, model_version=model_version, cut_key=cut_key)
    rule_evaluations = _evaluate_business_rules(db, metrics["monitoring"], drift_rows)
    recalibration = _propose_recalibration(db, model_version, drift_rows, rule_evaluations, metrics["monitoring"])
    status = _governance_status([row["status"] for row in rule_evaluations])
    db.query(IntelicoopGovernanceSnapshot).filter(
        IntelicoopGovernanceSnapshot.cut_key == cut_key,
        IntelicoopGovernanceSnapshot.model_version == model_version,
    ).delete(synchronize_session=False)
    snapshot = IntelicoopGovernanceSnapshot(
        cut_key=cut_key,
        model_version=model_version,
        monitoring_json=_json_dump({**metrics["monitoring"], "rules": rule_evaluations}),
        drift_json=_json_dump({"rows": drift_rows}),
        explainability_json=_json_dump({**metrics["explainability"], "recalibration": recalibration}),
        governance_status=status,
    )
    db.add(snapshot)
    db.flush()
    _create_audit_log(
        db,
        event_type="governance_refresh",
        entity_type="governance_snapshot",
        entity_id=snapshot.id,
        actor=actor,
        model_version=model_version,
        details={"cut_key": cut_key, "status": status},
    )
    db.flush()
    return {
        **_governance_snapshot_dict(snapshot),
        "business_rules": rule_evaluations,
        "drift_rows": drift_rows,
        "recalibration": recalibration,
    }


def run_governance_refresh(actor: str = "system") -> Dict[str, Any]:
    db = _db()
    try:
        result = _run_governance_refresh(db, actor=actor)
        db.commit()
        return result
    finally:
        db.close()


def get_governance_overview() -> Dict[str, Any]:
    db = _db()
    try:
        _ensure_business_rules(db)
        db.commit()
        latest = (
            db.query(IntelicoopGovernanceSnapshot)
            .order_by(IntelicoopGovernanceSnapshot.created_at.desc(), IntelicoopGovernanceSnapshot.id.desc())
            .first()
        )
        drift_rows = (
            db.query(IntelicoopModelDriftSnapshot)
            .order_by(IntelicoopModelDriftSnapshot.created_at.desc(), IntelicoopModelDriftSnapshot.id.desc())
            .limit(10)
            .all()
        )
        recalibrations = (
            db.query(IntelicoopModelRecalibration)
            .order_by(IntelicoopModelRecalibration.created_at.desc(), IntelicoopModelRecalibration.id.desc())
            .limit(10)
            .all()
        )
        audits = (
            db.query(IntelicoopAuditLog)
            .order_by(IntelicoopAuditLog.created_at.desc(), IntelicoopAuditLog.id.desc())
            .limit(20)
            .all()
        )
        rules = (
            db.query(IntelicoopBusinessRule)
            .order_by(IntelicoopBusinessRule.rule_key.asc())
            .all()
        )
        latest_dict = _governance_snapshot_dict(latest) if latest else {
            "monitoring": {},
            "drift": {"rows": []},
            "explainability": {},
            "governance_status": "pending",
            "cut_key": None,
            "model_version": "intelicoop_scoring_v1",
        }
        return {
            "version": GOVERNANCE_VERSION,
            "latest_snapshot": latest_dict,
            "drift_rows": [_drift_snapshot_dict(row) for row in drift_rows],
            "recalibrations": [_recalibration_dict(row) for row in recalibrations],
            "audit_logs": [_audit_log_dict(row) for row in audits],
            "business_rules": [_business_rule_dict(row) for row in rules],
        }
    finally:
        db.close()


def _execute_batch_job(
    db: Session,
    job_key: str,
    trigger_type: str = "manual",
    reference_at: datetime | None = None,
) -> Dict[str, Any]:
    states = {row.job_key: row for row in _ensure_batch_job_states(db)}
    if job_key not in states:
        raise ValueError("Job batch no reconocido.")
    state = states[job_key]
    now = _utcnow()
    run = IntelicoopBatchRun(
        run_key=f"{job_key}-{now.strftime('%Y%m%d%H%M%S%f')}",
        job_key=job_key,
        trigger_type=trigger_type,
        status="running",
        quality_status="pending",
        started_at=now,
    )
    db.add(run)
    db.flush()
    db.commit()
    db.refresh(run)
    try:
        active_cut_key = _get_latest_cut_key(db)
        if job_key == "foundation_refresh":
            metrics = _run_foundation_refresh(db, reference_at=reference_at)
            active_cut_key = str(metrics.get("cut_key") or active_cut_key or "")
            quality_summary = _quality_summary_for_cut(db, active_cut_key)
            records_processed = int(metrics.get("quality_rules", 0)) + int(metrics.get("feature_rows", 0))
            records_created = int(metrics.get("feature_rows", 0)) + int(metrics.get("kpi_rows", 0)) + int(metrics.get("cohorte_rows", 0))
        elif job_key == "segmentation_refresh":
            metrics = _run_segmentation_refresh(db)
            active_cut_key = str(metrics.get("cut_key") or active_cut_key or "")
            quality_summary = _quality_summary_for_cut(db, active_cut_key)
            records_processed = int(metrics.get("socios_evaluados", 0))
            records_created = int(metrics.get("socios_actualizados", 0))
        elif job_key == "scoring_refresh":
            metrics = _run_scoring_refresh(db, active_cut_key)
            quality_summary = _quality_summary_for_cut(db, active_cut_key)
            records_processed = int(metrics.get("socios_total", 0))
            records_created = int(metrics.get("scorings_creados", 0))
        elif job_key == "alerts_refresh":
            metrics = _run_alerts_refresh(db, run.id, active_cut_key)
            quality_summary = _quality_summary_for_cut(db, active_cut_key)
            records_processed = int((get_segmentation_propensity_summary().get("resumen") or {}).get("total_socios", 0))
            records_created = int(metrics.get("alertas_generadas", 0))
        elif job_key == "governance_refresh":
            metrics = _run_governance_refresh(db, actor="batch")
            quality_summary = _quality_summary_for_cut(db, active_cut_key)
            records_processed = int((metrics.get("monitoring") or {}).get("muestra_reciente", 0))
            records_created = int(len(metrics.get("drift_rows") or []))
        else:
            raise ValueError("Job batch no implementado.")

        now_done = _utcnow()
        run.cut_key = active_cut_key
        run.status = "success"
        run.quality_status = _derive_batch_quality_status(quality_summary)
        run.records_processed = records_processed
        run.records_created = records_created
        run.metrics_json = _json_dump(metrics)
        run.quality_summary_json = _json_dump(quality_summary)
        run.finished_at = now_done
        state.last_run_at = now_done
        state.next_run_at = now_done + timedelta(minutes=int(state.cadence_minutes or 0))
        state.last_status = run.status
        state.updated_at = now_done
        db.commit()
        db.refresh(run)
        return _batch_run_dict(run)
    except Exception as exc:
        db.rollback()
        now_fail = _utcnow()
        run.status = "failed"
        run.quality_status = "fail"
        run.error_message = str(exc)
        run.finished_at = now_fail
        state.last_run_at = now_fail
        state.next_run_at = now_fail + timedelta(minutes=int(state.cadence_minutes or 0))
        state.last_status = run.status
        state.updated_at = now_fail
        db.add(run)
        db.add(state)
        db.commit()
        raise


def get_batch_overview() -> Dict[str, Any]:
    db = _db()
    try:
        _ensure_batch_job_states(db)
        db.commit()
        jobs = (
            db.query(IntelicoopBatchJobState)
            .order_by(IntelicoopBatchJobState.job_key.asc())
            .all()
        )
        runs = (
            db.query(IntelicoopBatchRun)
            .order_by(IntelicoopBatchRun.started_at.desc(), IntelicoopBatchRun.id.desc())
            .limit(10)
            .all()
        )
        alerts = (
            db.query(IntelicoopBatchAlert)
            .order_by(IntelicoopBatchAlert.created_at.desc(), IntelicoopBatchAlert.id.desc())
            .limit(10)
            .all()
        )
        due_jobs = [row.job_key for row in jobs if row.enabled and row.next_run_at and row.next_run_at <= _utcnow()]
        return {
            "version": BATCH_VERSION,
            "jobs": [_batch_job_state_dict(row) for row in jobs],
            "runs": [_batch_run_dict(row) for row in runs],
            "alerts": [_batch_alert_dict(row) for row in alerts],
            "due_jobs": due_jobs,
        }
    finally:
        db.close()


def list_batch_runs(limit: int = 20) -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = (
            db.query(IntelicoopBatchRun)
            .order_by(IntelicoopBatchRun.started_at.desc(), IntelicoopBatchRun.id.desc())
            .limit(max(1, min(int(limit), 100)))
            .all()
        )
        return [_batch_run_dict(row) for row in rows]
    finally:
        db.close()


def list_batch_alerts(limit: int = 20) -> List[Dict[str, Any]]:
    db = _db()
    try:
        rows = (
            db.query(IntelicoopBatchAlert)
            .order_by(IntelicoopBatchAlert.created_at.desc(), IntelicoopBatchAlert.id.desc())
            .limit(max(1, min(int(limit), 100)))
            .all()
        )
        return [_batch_alert_dict(row) for row in rows]
    finally:
        db.close()


def run_batch_job(job_key: str, trigger_type: str = "manual") -> Dict[str, Any]:
    db = _db()
    try:
        return _execute_batch_job(db, job_key=job_key, trigger_type=trigger_type)
    finally:
        db.close()


def run_due_batch_jobs() -> Dict[str, Any]:
    db = _db()
    try:
        now = _utcnow()
        states = _ensure_batch_job_states(db)
        db.commit()
        executed = []
        due = [row.job_key for row in states if row.enabled and row.next_run_at and row.next_run_at <= now]
        for job_key in due:
            executed.append(_execute_batch_job(db, job_key=job_key, trigger_type="scheduled"))
        return {
            "executed_jobs": due,
            "runs": executed,
        }
    finally:
        db.close()


def get_dashboard_resumen() -> Dict[str, Any]:
    db = _db()
    try:
        segmentation = get_segmentation_propensity_summary()
        socios = db.query(func.count(IntelicoopSocio.id)).scalar() or 0
        creditos = db.query(func.count(IntelicoopCredito.id)).scalar() or 0
        campanas = db.query(func.count(IntelicoopCampania.id)).scalar() or 0
        prospectos = db.query(func.count(IntelicoopProspecto.id)).scalar() or 0
        scoring_total = db.query(func.count(IntelicoopScoringResult.id)).scalar() or 0
        riesgo_rows = (
            db.query(IntelicoopScoringResult.riesgo, func.count(IntelicoopScoringResult.id))
            .group_by(IntelicoopScoringResult.riesgo)
            .all()
        )
        riesgo = {"bajo": 0, "medio": 0, "alto": 0}
        for key, count in riesgo_rows:
            if key in riesgo:
                riesgo[key] = int(count)
        cartera_total = float(db.query(func.coalesce(func.sum(IntelicoopCredito.monto), 0)).scalar() or 0)
        pagos_total = float(db.query(func.coalesce(func.sum(IntelicoopHistorialPago.monto), 0)).scalar() or 0)
        cartera_vigente = max(0.0, cartera_total - pagos_total)
        cartera_vencida_estimada = 0.0
        if scoring_total:
            cartera_vencida_estimada = cartera_total * (riesgo["alto"] / max(1, int(scoring_total))) * 0.35
        imor_pct = (cartera_vencida_estimada / cartera_total * 100.0) if cartera_total else 0.0
        depositos_total = float(
            db.query(func.coalesce(func.sum(IntelicoopTransaccion.monto), 0))
            .filter(IntelicoopTransaccion.tipo == "deposito")
            .scalar()
            or 0
        )
        retiros_total = float(
            db.query(func.coalesce(func.sum(IntelicoopTransaccion.monto), 0))
            .filter(IntelicoopTransaccion.tipo == "retiro")
            .scalar()
            or 0
        )
        captacion_neta = depositos_total - retiros_total
        campanas_activas = int(
            db.query(func.count(IntelicoopCampania.id))
            .filter(IntelicoopCampania.estado == "activa")
            .scalar()
            or 0
        )
        prospectos_score_prom = float(
            db.query(func.coalesce(func.avg(IntelicoopProspecto.score_propension), 0)).scalar() or 0
        )
        contactos_total = int(db.query(func.count(IntelicoopContactoCampania.id)).scalar() or 0)
        conversiones_total = int(
            db.query(func.count(IntelicoopSeguimientoCampania.id))
            .filter(IntelicoopSeguimientoCampania.conversion == 1)
            .scalar()
            or 0
        )
        conversion_pct = (conversiones_total / contactos_total * 100.0) if contactos_total else 0.0
        aprobados = int(
            db.query(func.count(IntelicoopCredito.id))
            .filter(IntelicoopCredito.estado == "aprobado")
            .scalar()
            or 0
        )
        rechazados = int(
            db.query(func.count(IntelicoopCredito.id))
            .filter(IntelicoopCredito.estado == "rechazado")
            .scalar()
            or 0
        )
        solicitados = int(
            db.query(func.count(IntelicoopCredito.id))
            .filter(IntelicoopCredito.estado == "solicitado")
            .scalar()
            or 0
        )
        semaforos = [
            {
                "ambito": "salud_cartera",
                "label": "Salud de cartera",
                "valor": round(imor_pct, 2),
                "meta": 8.0,
                "semaforo": "verde" if imor_pct <= 8 else ("amarillo" if imor_pct <= 14 else "rojo"),
            },
            {
                "ambito": "captacion",
                "label": "Captacion neta",
                "valor": round(captacion_neta, 2),
                "meta": 0.0,
                "semaforo": "verde" if captacion_neta >= 0 else ("amarillo" if captacion_neta >= -1000 else "rojo"),
            },
            {
                "ambito": "riesgo",
                "label": "Scoring alto riesgo",
                "valor": riesgo["alto"],
                "meta": max(1, int(scoring_total * 0.2)) if scoring_total else 0,
                "semaforo": "verde" if riesgo["alto"] <= max(1, int(scoring_total * 0.2)) else ("amarillo" if riesgo["alto"] <= max(1, int(scoring_total * 0.35)) else "rojo"),
            },
            {
                "ambito": "comercial",
                "label": "Campanas activas",
                "valor": campanas_activas,
                "meta": 1,
                "semaforo": "verde" if campanas_activas >= 1 else "amarillo",
            },
        ]
        return {
            "socios": int(socios),
            "creditos": int(creditos),
            "campanas": int(campanas),
            "prospectos": int(prospectos),
            "scoring_total": int(scoring_total),
            "riesgo": riesgo,
            "salud_cartera": {
                "cartera_total": round(cartera_total, 2),
                "cartera_vigente": round(cartera_vigente, 2),
                "cartera_vencida_estimada": round(cartera_vencida_estimada, 2),
                "imor_pct": round(imor_pct, 2),
            },
            "colocacion": {
                "solicitados": solicitados,
                "aprobados": aprobados,
                "rechazados": rechazados,
                "monto_total": round(cartera_total, 2),
                "ticket_promedio": round((cartera_total / creditos), 2) if creditos else 0.0,
            },
            "captacion": {
                "depositos_total": round(depositos_total, 2),
                "retiros_total": round(retiros_total, 2),
                "captacion_neta": round(captacion_neta, 2),
            },
            "comercial": {
                "campanas_activas": campanas_activas,
                "prospectos_total": int(prospectos),
                "score_propension_promedio": round(prospectos_score_prom, 4),
                "contactos_total": contactos_total,
                "conversiones_total": conversiones_total,
                "conversion_pct": round(conversion_pct, 2),
            },
            "segmentacion": {
                "segmentos_total": int((segmentation.get("resumen") or {}).get("segmentos_total", 0)),
                "oportunidades_comerciales": int((segmentation.get("resumen") or {}).get("oportunidades_comerciales", 0)),
                "alertas_tempranas": int((segmentation.get("resumen") or {}).get("alertas_tempranas", 0)),
                "abandono_alto": int((segmentation.get("resumen") or {}).get("abandono_alto", 0)),
            },
            "semaforos": semaforos,
        }
    finally:
        db.close()
