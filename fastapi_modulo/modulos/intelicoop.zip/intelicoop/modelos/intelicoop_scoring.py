from __future__ import annotations

import pickle
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


MODEL_PATH = (
    Path(__file__).resolve().parent.parent
    / "assets"
    / "modelo_scoring.pkl"
)
MODEL_VERSION = "intelicoop_scoring_v1"
SCORING_TRAZA_VERSION = "intelicoop_traza_v1"
_SCORE_UMBRAL_APROBAR = 0.80
_SCORE_UMBRAL_EVALUAR = 0.55
_MODEL: Any = None
_MODEL_LOADED = False


def _load_model() -> Any:
    global _MODEL, _MODEL_LOADED
    if _MODEL_LOADED:
        return _MODEL
    _MODEL_LOADED = True
    if not MODEL_PATH.exists():
        _MODEL = None
        return None
    try:
        with MODEL_PATH.open("rb") as fh:
            _MODEL = pickle.load(fh)
    except Exception:
        _MODEL = None
    return _MODEL


def _fallback_score(ingreso_mensual: float, deuda_actual: float, antiguedad_meses: int) -> float:
    if ingreso_mensual <= 0:
        return 0.15
    ratio = deuda_actual / ingreso_mensual if ingreso_mensual else 1.0
    ratio_score = max(0.0, min(1.0, 1.0 - ratio))
    antiguedad_score = max(0.0, min(1.0, antiguedad_meses / 36.0))
    return round((ratio_score * 0.75) + (antiguedad_score * 0.25), 4)


def _predict_model_score(model: Any, features: List[float]) -> Optional[float]:
    try:
        if hasattr(model, "predict_proba"):
            result = model.predict_proba([features])[0]
            return float(result[1]) if len(result) > 1 else float(result[0])
        if hasattr(model, "predict"):
            return float(model.predict([features])[0])
    except Exception:
        return None
    return None


def _compute_confianza(score: float, motor: str) -> float:
    umbrales = [_SCORE_UMBRAL_EVALUAR, _SCORE_UMBRAL_APROBAR]
    min_dist = min(abs(score - u) for u in umbrales)
    confianza = 0.5 + min(min_dist / 0.25, 1.0) * 0.5
    if motor == "modelo_ml":
        confianza = min(1.0, confianza * 1.1)
    return round(confianza, 4)


def _build_explicacion(
    ingreso_mensual: float,
    deuda_actual: float,
    antiguedad_meses: int,
    score: float,
    motor: str,
) -> Dict[str, Any]:
    razones: List[str] = []
    reglas: List[Dict[str, Any]] = []

    # Razón 1: ratio deuda/ingreso
    if ingreso_mensual <= 0:
        ratio = 1.0
        razones.append("Sin ingreso mensual registrado: score penalizado al máximo.")
        reglas.append({"regla": "ingreso_cero", "impacto": "negativo", "peso": 0.75})
    else:
        ratio = round(deuda_actual / ingreso_mensual, 4)
        if ratio >= 0.8:
            razones.append(f"Ratio deuda/ingreso muy alto ({ratio:.0%}): riesgo crediticio elevado.")
            reglas.append({"regla": "ratio_deuda_ingreso_alto", "valor": ratio, "impacto": "negativo", "peso": 0.75})
        elif ratio >= 0.5:
            razones.append(f"Ratio deuda/ingreso elevado ({ratio:.0%}): capacidad de pago comprometida.")
            reglas.append({"regla": "ratio_deuda_ingreso_medio", "valor": ratio, "impacto": "negativo_leve", "peso": 0.75})
        elif ratio <= 0.2:
            razones.append(f"Ratio deuda/ingreso favorable ({ratio:.0%}): buena capacidad de pago.")
            reglas.append({"regla": "ratio_deuda_ingreso_bajo", "valor": ratio, "impacto": "positivo", "peso": 0.75})
        else:
            razones.append(f"Ratio deuda/ingreso aceptable ({ratio:.0%}).")
            reglas.append({"regla": "ratio_deuda_ingreso_normal", "valor": ratio, "impacto": "neutro", "peso": 0.75})

    # Razón 2: antigüedad
    if antiguedad_meses < 6:
        razones.append(f"Antigüedad muy baja ({antiguedad_meses} meses): historial insuficiente.")
        reglas.append({"regla": "antiguedad_muy_baja", "valor": antiguedad_meses, "impacto": "negativo", "peso": 0.25})
    elif antiguedad_meses < 12:
        razones.append(f"Antigüedad limitada ({antiguedad_meses} meses): en período de evaluación.")
        reglas.append({"regla": "antiguedad_limitada", "valor": antiguedad_meses, "impacto": "negativo_leve", "peso": 0.25})
    elif antiguedad_meses >= 36:
        razones.append(f"Antigüedad sólida ({antiguedad_meses} meses): historial de relación consolidado.")
        reglas.append({"regla": "antiguedad_solida", "valor": antiguedad_meses, "impacto": "positivo", "peso": 0.25})
    else:
        razones.append(f"Antigüedad aceptable ({antiguedad_meses} meses).")
        reglas.append({"regla": "antiguedad_normal", "valor": antiguedad_meses, "impacto": "neutro", "peso": 0.25})

    # Razón 3: resultado final
    if score >= _SCORE_UMBRAL_APROBAR:
        razones.append(f"Score {score:.4f} ≥ {_SCORE_UMBRAL_APROBAR}: perfil crediticio aprobable.")
    elif score >= _SCORE_UMBRAL_EVALUAR:
        razones.append(f"Score {score:.4f} entre {_SCORE_UMBRAL_EVALUAR} y {_SCORE_UMBRAL_APROBAR}: requiere evaluación adicional.")
    else:
        razones.append(f"Score {score:.4f} < {_SCORE_UMBRAL_EVALUAR}: perfil de alto riesgo, no recomendado para aprobación.")

    reglas.append({"regla": "motor_utilizado", "valor": motor, "impacto": "informativo", "peso": 0})

    return {"razones": razones, "reglas_aplicadas": reglas}


def evaluate_scoring(
    ingreso_mensual: float,
    deuda_actual: float,
    antiguedad_meses: int,
) -> Tuple[float, str, str, str]:
    model = _load_model()
    features = [float(ingreso_mensual), float(deuda_actual), float(antiguedad_meses)]
    score = _predict_model_score(model, features) if model is not None else None
    if score is None:
        score = _fallback_score(*features)
    score = max(0.0, min(1.0, float(score)))
    if score >= _SCORE_UMBRAL_APROBAR:
        recomendacion, riesgo = "aprobar", "bajo"
    elif score >= _SCORE_UMBRAL_EVALUAR:
        recomendacion, riesgo = "evaluar", "medio"
    else:
        recomendacion, riesgo = "rechazar", "alto"
    return round(score, 4), recomendacion, riesgo, MODEL_VERSION


def evaluate_scoring_v2(
    ingreso_mensual: float,
    deuda_actual: float,
    antiguedad_meses: int,
    solicitud_id: str = "",
    socio_id: Optional[int] = None,
    credito_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Scoring con trazabilidad completa: inputs, outputs, razones, confianza y versionado."""
    t0 = time.monotonic()
    model = _load_model()
    features = [float(ingreso_mensual), float(deuda_actual), float(antiguedad_meses)]

    if model is not None:
        raw = _predict_model_score(model, features)
        motor = "modelo_ml" if raw is not None else "reglas"
    else:
        raw, motor = None, "reglas"

    if raw is None:
        raw = _fallback_score(*features)
        motor = "reglas"

    score = round(max(0.0, min(1.0, float(raw))), 4)
    if score >= _SCORE_UMBRAL_APROBAR:
        recomendacion, riesgo = "aprobar", "bajo"
    elif score >= _SCORE_UMBRAL_EVALUAR:
        recomendacion, riesgo = "evaluar", "medio"
    else:
        recomendacion, riesgo = "rechazar", "alto"

    tiempo_ms = max(1, int((time.monotonic() - t0) * 1000))
    confianza = _compute_confianza(score, motor)
    ingreso_f = float(ingreso_mensual)
    deuda_f = float(deuda_actual)
    ratio_deuda_ingreso = round(deuda_f / ingreso_f, 4) if ingreso_f > 0 else 1.0
    explicacion = _build_explicacion(ingreso_f, deuda_f, int(antiguedad_meses), score, motor)

    return {
        "score": score,
        "recomendacion": recomendacion,
        "riesgo": riesgo,
        "model_version": MODEL_VERSION,
        "confianza": confianza,
        "motor": motor,
        "tiempo_ms": tiempo_ms,
        "inputs": {
            "ingreso_mensual": ingreso_f,
            "deuda_actual": deuda_f,
            "antiguedad_meses": int(antiguedad_meses),
        },
        "features_calculados": {
            "ratio_deuda_ingreso": ratio_deuda_ingreso,
            "antiguedad_normalizada": round(min(1.0, int(antiguedad_meses) / 36.0), 4),
            "ingreso_positivo": ingreso_f > 0,
        },
        "razones": explicacion["razones"],
        "reglas_aplicadas": explicacion["reglas_aplicadas"],
        "solicitud_id": solicitud_id,
        "socio_id": socio_id,
        "credito_id": credito_id,
        "traza_version": SCORING_TRAZA_VERSION,
    }


def summarize_scoring(rows: list[Dict[str, Any]]) -> Dict[str, Any]:
    total = len(rows)
    por_riesgo = {"bajo": 0, "medio": 0, "alto": 0}
    por_recomendacion = {"aprobar": 0, "evaluar": 0, "rechazar": 0}
    score_sum = 0.0
    recientes = []
    for row in rows:
        score = float(row.get("score", 0) or 0)
        score_sum += score
        riesgo = str(row.get("riesgo", "")).lower()
        recomendacion = str(row.get("recomendacion", "")).lower()
        if riesgo in por_riesgo:
            por_riesgo[riesgo] += 1
        if recomendacion in por_recomendacion:
            por_recomendacion[recomendacion] += 1
        recientes.append(
            {
                "id": row.get("id"),
                "solicitud_id": row.get("solicitud_id"),
                "socio_id": row.get("socio_id"),
                "credito_id": row.get("credito_id"),
                "score": score,
                "recomendacion": recomendacion,
                "riesgo": riesgo,
                "model_version": row.get("model_version", MODEL_VERSION),
                "fecha_creacion": row.get("fecha_creacion"),
            }
        )
    recientes = list(reversed(recientes[-5:]))
    return {
        "total_inferencias": total,
        "score_promedio": round(score_sum / total, 4) if total else 0.0,
        "por_riesgo": por_riesgo,
        "por_recomendacion": por_recomendacion,
        "recientes": recientes,
    }
