from __future__ import annotations

import os
import sys
import types

import pytest
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient


os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("SQLITE_DB_PATH", "/tmp/sipet_intelicoop_governance.sqlite3")
pytestmark = pytest.mark.filterwarnings("ignore:The 'app' shortcut is now deprecated.*:DeprecationWarning")


fake_main = types.ModuleType("fastapi_modulo.main")


def _fake_render_backend_page(
    request: Request,
    title: str,
    description: str = "",
    content: str = "",
    **_: object,
) -> HTMLResponse:
    html = f"<html><head><title>{title}</title></head><body>{content}</body></html>"
    return HTMLResponse(content=html)


def _fake_get_user_app_access(request: Request) -> list[str]:
    raw = request.headers.get("x-app-access", "")
    return [item.strip() for item in raw.split(",") if item.strip()]


def _fake_is_admin_or_superadmin(request: Request) -> bool:
    return getattr(request.state, "user_role", "").strip().lower() in {
        "administrador",
        "admin",
        "superadministrador",
        "superadmin",
    }


fake_main.render_backend_page = _fake_render_backend_page
fake_main._get_user_app_access = _fake_get_user_app_access
fake_main.is_admin_or_superadmin = _fake_is_admin_or_superadmin
sys.modules["fastapi_modulo.main"] = fake_main


from fastapi_modulo.core.db import MAIN, engine
from fastapi_modulo.modulos.intelicoop.controladores.intelicoop import require_intelicoop_access, router
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_db_models import (
    IntelicoopAnalyticCut,
    IntelicoopAuditLog,
    IntelicoopBusinessRule,
    IntelicoopGovernanceSnapshot,
    IntelicoopHistorialPago,
    IntelicoopModelDriftSnapshot,
    IntelicoopModelRecalibration,
    IntelicoopModelVersionRegistry,
    IntelicoopScoringResult,
    IntelicoopScoringTraza,
    IntelicoopSocio,
)


TABLES = [
    IntelicoopSocio.__table__,
    IntelicoopHistorialPago.__table__,
    IntelicoopScoringResult.__table__,
    IntelicoopScoringTraza.__table__,
    IntelicoopModelVersionRegistry.__table__,
    IntelicoopAnalyticCut.__table__,
    IntelicoopGovernanceSnapshot.__table__,
    IntelicoopModelDriftSnapshot.__table__,
    IntelicoopModelRecalibration.__table__,
    IntelicoopAuditLog.__table__,
    IntelicoopBusinessRule.__table__,
]


def _build_client() -> TestClient:
    app = FastAPI()

    @app.middleware("http")
    async def inject_test_session(request: Request, call_next):
        request.state.user_name = request.headers.get("x-user", "tester")
        request.state.user_role = request.headers.get("x-role", "usuario")
        request.state.tenant_id = "test"
        return await call_next(request)

    app.include_router(router)
    app.dependency_overrides[require_intelicoop_access] = lambda: None
    return TestClient(app)


def setup_function() -> None:
    MAIN.metadata.drop_all(bind=engine, tables=TABLES, checkfirst=True)
    MAIN.metadata.create_all(bind=engine, tables=TABLES, checkfirst=True)


def test_governance_refresh_creates_monitoring_drift_and_audit() -> None:
    client = _build_client()
    headers = {"x-role": "admin", "x-user": "intelicoop.governance"}

    socio = client.post(
        "/api/intelicoop/socios",
        headers=headers,
        json={
            "nombre": "Socio Governance",
            "email": "governance@example.com",
            "telefono": "555-0111",
            "direccion": "Zona 3",
            "segmento": "inactivo",
        },
    )
    assert socio.status_code == 201
    socio_id = socio.json()["id"]

    for payload in (
        {"solicitud_id": "gov-1", "socio_id": socio_id, "ingreso_mensual": 6000, "deuda_actual": 500, "antiguedad_meses": 36},
        {"solicitud_id": "gov-2", "socio_id": socio_id, "ingreso_mensual": 2500, "deuda_actual": 2200, "antiguedad_meses": 4},
    ):
        response = client.post("/api/intelicoop/scoring/evaluar", headers=headers, json=payload)
        assert response.status_code == 201

    refresh = client.post("/api/intelicoop/gobernanza/refresh", headers=headers, json={})

    assert refresh.status_code == 201
    body = refresh.json()
    assert body["model_version"] == "intelicoop_scoring_v1"
    assert body["monitoring"]["total_inferencias"] >= 2
    assert len(body["drift_rows"]) >= 3
    assert body["business_rules"]

    overview = client.get("/api/intelicoop/gobernanza/resumen", headers=headers)
    assert overview.status_code == 200
    data = overview.json()
    assert data["latest_snapshot"]["model_version"] == "intelicoop_scoring_v1"
    assert data["drift_rows"]
    assert data["audit_logs"]
    assert data["business_rules"]
