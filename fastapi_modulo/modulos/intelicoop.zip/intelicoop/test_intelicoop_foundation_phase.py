from __future__ import annotations

import os
import sys
import types

import pytest
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient


os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("SQLITE_DB_PATH", "/tmp/sipet_intelicoop_foundation.sqlite3")
pytestmark = pytest.mark.filterwarnings("ignore:The 'app' shortcut is now deprecated.*:DeprecationWarning")


fake_main = types.ModuleType("fastapi_modulo.main")


def _fake_render_backend_page(
    request: Request,
    title: str,
    description: str = "",
    content: str = "",
    **_: object,
) -> HTMLResponse:
    html = f"<html><head><title>{title}</title></head><body>{content}</body></html>"
    return HTMLResponse(content=html)


def _fake_get_user_app_access(request: Request) -> list[str]:
    raw = request.headers.get("x-app-access", "")
    return [item.strip() for item in raw.split(",") if item.strip()]


def _fake_is_admin_or_superadmin(request: Request) -> bool:
    return getattr(request.state, "user_role", "").strip().lower() in {
        "administrador",
        "admin",
        "superadministrador",
        "superadmin",
    }


fake_main.render_backend_page = _fake_render_backend_page
fake_main._get_user_app_access = _fake_get_user_app_access
fake_main.is_admin_or_superadmin = _fake_is_admin_or_superadmin
sys.modules["fastapi_modulo.main"] = fake_main


from fastapi_modulo.core.db import MAIN, engine
from fastapi_modulo.modulos.intelicoop.controladores.intelicoop import require_intelicoop_access, router
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_db_models import (
    IntelicoopAnalyticCut,
    IntelicoopCampania,
    IntelicoopContactoCampania,
    IntelicoopCredito,
    IntelicoopCuenta,
    IntelicoopDataQualitySnapshot,
    IntelicoopHistorialPago,
    IntelicoopKpiSnapshot,
    IntelicoopModelVersionRegistry,
    IntelicoopProspecto,
    IntelicoopScoringResult,
    IntelicoopScoringTraza,
    IntelicoopSeguimientoCampania,
    IntelicoopSocio,
    IntelicoopSocioFeatureSnapshot,
    IntelicoopTransaccion,
)


INTELICOOP_TABLES = [
    IntelicoopSocio.__table__,
    IntelicoopCredito.__table__,
    IntelicoopHistorialPago.__table__,
    IntelicoopCuenta.__table__,
    IntelicoopTransaccion.__table__,
    IntelicoopCampania.__table__,
    IntelicoopProspecto.__table__,
    IntelicoopContactoCampania.__table__,
    IntelicoopSeguimientoCampania.__table__,
    IntelicoopScoringResult.__table__,
    IntelicoopScoringTraza.__table__,
    IntelicoopModelVersionRegistry.__table__,
    IntelicoopAnalyticCut.__table__,
    IntelicoopDataQualitySnapshot.__table__,
    IntelicoopSocioFeatureSnapshot.__table__,
    IntelicoopKpiSnapshot.__table__,
]


def _build_client() -> TestClient:
    app = FastAPI()

    @app.middleware("http")
    async def inject_test_session(request: Request, call_next):
        request.state.user_name = request.headers.get("x-user", "tester")
        request.state.user_role = request.headers.get("x-role", "usuario")
        request.state.tenant_id = "test"
        return await call_next(request)

    app.include_router(router)
    app.dependency_overrides[require_intelicoop_access] = lambda: None
    return TestClient(app)


def _auth_headers(*access: str, role: str = "admin") -> dict[str, str]:
    headers = {"x-role": role, "x-user": "intelicoop.foundation"}
    if access:
        headers["x-app-access"] = ",".join(access)
    return headers


def setup_function() -> None:
    MAIN.metadata.drop_all(bind=engine, tables=INTELICOOP_TABLES, checkfirst=True)
    MAIN.metadata.create_all(bind=engine, tables=INTELICOOP_TABLES, checkfirst=True)


def test_foundation_overview_exposes_contract() -> None:
    client = _build_client()

    response = client.get("/api/intelicoop/fundamentos/resumen", headers=_auth_headers("Intelicoop"))

    assert response.status_code == 200
    body = response.json()
    assert body["entity_model"]["transactional"]
    assert body["entity_model"]["analytical"]
    assert body["entity_model"]["relationships"]
    assert body["time_cuts"]["active_cut_key"].startswith("day:")


def test_foundation_materialize_creates_analytic_snapshots() -> None:
    client = _build_client()
    headers = _auth_headers("Intelicoop")

    socio = client.post(
        "/api/intelicoop/socios",
        headers=headers,
        json={
            "nombre": "Socio Base",
            "email": "base@example.com",
            "telefono": "555-0101",
            "direccion": "Zona 1",
            "segmento": "hormiga",
        },
    )
    assert socio.status_code == 201
    socio_id = socio.json()["id"]

    credito = client.post(
        "/api/intelicoop/creditos",
        headers=headers,
        json={
            "socio_id": socio_id,
            "monto": 1000,
            "plazo": 10,
            "ingreso_mensual": 4500,
            "deuda_actual": 700,
            "antiguedad_meses": 18,
            "estado": "solicitado",
        },
    )
    assert credito.status_code == 201

    materialize = client.post("/api/intelicoop/fundamentos/materializar", headers=headers, json={})

    assert materialize.status_code == 201
    body = materialize.json()
    assert body["cut_key"].startswith("day:")
    assert body["feature_rows"] >= 1
    assert body["quality_rules"] >= 1

    overview = client.get("/api/intelicoop/fundamentos/resumen", headers=headers)
    assert overview.status_code == 200
    latest = overview.json()["storage_contract"]["latest_materialized_cut"]
    assert latest["cut_key"] == body["cut_key"]
