from __future__ import annotations

import os
import sys
import types

import pytest
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient


os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("SQLITE_DB_PATH", "/tmp/sipet_intelicoop_batch.sqlite3")
pytestmark = pytest.mark.filterwarnings("ignore:The 'app' shortcut is now deprecated.*:DeprecationWarning")


fake_main = types.ModuleType("fastapi_modulo.main")


def _fake_render_backend_page(
    request: Request,
    title: str,
    description: str = "",
    content: str = "",
    **_: object,
) -> HTMLResponse:
    html = f"<html><head><title>{title}</title></head><body>{content}</body></html>"
    return HTMLResponse(content=html)


def _fake_get_user_app_access(request: Request) -> list[str]:
    raw = request.headers.get("x-app-access", "")
    return [item.strip() for item in raw.split(",") if item.strip()]


def _fake_is_admin_or_superadmin(request: Request) -> bool:
    return getattr(request.state, "user_role", "").strip().lower() in {
        "administrador",
        "admin",
        "superadministrador",
        "superadmin",
    }


fake_main.render_backend_page = _fake_render_backend_page
fake_main._get_user_app_access = _fake_get_user_app_access
fake_main.is_admin_or_superadmin = _fake_is_admin_or_superadmin
sys.modules["fastapi_modulo.main"] = fake_main


from fastapi_modulo.core.db import MAIN, engine
from fastapi_modulo.modulos.intelicoop.controladores.intelicoop import require_intelicoop_access, router
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_db_models import (
    IntelicoopAnalyticCut,
    IntelicoopBatchAlert,
    IntelicoopBatchJobState,
    IntelicoopBatchRun,
    IntelicoopCampania,
    IntelicoopCampaniaFeatureSnapshot,
    IntelicoopContactoCampania,
    IntelicoopCohorteSnapshot,
    IntelicoopCredito,
    IntelicoopCreditoFeatureSnapshot,
    IntelicoopCuenta,
    IntelicoopDataQualitySnapshot,
    IntelicoopGovernanceSnapshot,
    IntelicoopHistorialPago,
    IntelicoopKpiSnapshot,
    IntelicoopModelVersionRegistry,
    IntelicoopModelDriftSnapshot,
    IntelicoopModelRecalibration,
    IntelicoopProspecto,
    IntelicoopProspectoFeatureSnapshot,
    IntelicoopScoringResult,
    IntelicoopScoringTraza,
    IntelicoopSeguimientoCampania,
    IntelicoopSocio,
    IntelicoopSocioFeatureSnapshot,
    IntelicoopTransaccion,
    IntelicoopAhorroFeatureSnapshot,
)


INTELICOOP_TABLES = [
    IntelicoopSocio.__table__,
    IntelicoopCredito.__table__,
    IntelicoopHistorialPago.__table__,
    IntelicoopCuenta.__table__,
    IntelicoopTransaccion.__table__,
    IntelicoopCampania.__table__,
    IntelicoopProspecto.__table__,
    IntelicoopContactoCampania.__table__,
    IntelicoopSeguimientoCampania.__table__,
    IntelicoopScoringResult.__table__,
    IntelicoopScoringTraza.__table__,
    IntelicoopModelVersionRegistry.__table__,
    IntelicoopAnalyticCut.__table__,
    IntelicoopDataQualitySnapshot.__table__,
    IntelicoopSocioFeatureSnapshot.__table__,
    IntelicoopCreditoFeatureSnapshot.__table__,
    IntelicoopAhorroFeatureSnapshot.__table__,
    IntelicoopCampaniaFeatureSnapshot.__table__,
    IntelicoopProspectoFeatureSnapshot.__table__,
    IntelicoopKpiSnapshot.__table__,
    IntelicoopCohorteSnapshot.__table__,
    IntelicoopGovernanceSnapshot.__table__,
    IntelicoopModelDriftSnapshot.__table__,
    IntelicoopModelRecalibration.__table__,
    IntelicoopBatchJobState.__table__,
    IntelicoopBatchRun.__table__,
    IntelicoopBatchAlert.__table__,
]


def _build_client() -> TestClient:
    app = FastAPI()

    @app.middleware("http")
    async def inject_test_session(request: Request, call_next):
        request.state.user_name = request.headers.get("x-user", "tester")
        request.state.user_role = request.headers.get("x-role", "usuario")
        request.state.tenant_id = "test"
        return await call_next(request)

    app.include_router(router)
    app.dependency_overrides[require_intelicoop_access] = lambda: None
    return TestClient(app)


def _auth_headers() -> dict[str, str]:
    return {"x-role": "admin", "x-user": "intelicoop.batch"}


def setup_function() -> None:
    MAIN.metadata.drop_all(bind=engine, tables=INTELICOOP_TABLES, checkfirst=True)
    MAIN.metadata.create_all(bind=engine, tables=INTELICOOP_TABLES, checkfirst=True)


def test_batch_jobs_execute_and_persist_bitacora() -> None:
    client = _build_client()
    headers = _auth_headers()

    socio = client.post(
        "/api/intelicoop/socios",
        headers=headers,
        json={
            "nombre": "Socio Batch",
            "email": "batch@example.com",
            "telefono": "555-0110",
            "direccion": "Zona 2",
            "segmento": "inactivo",
        },
    )
    assert socio.status_code == 201
    socio_id = socio.json()["id"]

    credito = client.post(
        "/api/intelicoop/creditos",
        headers=headers,
        json={
            "socio_id": socio_id,
            "monto": 2400,
            "plazo": 12,
            "ingreso_mensual": 2500,
            "deuda_actual": 2100,
            "antiguedad_meses": 4,
            "estado": "mora",
        },
    )
    assert credito.status_code == 201

    cuenta = client.post(
        "/api/intelicoop/ahorros/cuentas",
        headers=headers,
        json={"socio_id": socio_id, "tipo": "ahorro", "saldo": 120},
    )
    assert cuenta.status_code == 201

    for job_key in ("foundation_refresh", "segmentation_refresh", "scoring_refresh", "alerts_refresh", "governance_refresh"):
        response = client.post(f"/api/intelicoop/batch/ejecutar?job_key={job_key}", headers=headers, json={})
        assert response.status_code == 201
        body = response.json()
        assert body["job_key"] == job_key
        assert body["status"] == "success"

    overview = client.get("/api/intelicoop/batch/resumen", headers=headers)
    assert overview.status_code == 200
    data = overview.json()
    assert len(data["jobs"]) >= 5
    assert len(data["runs"]) >= 5
    assert len(data["alerts"]) >= 1
    assert any(row["job_key"] == "alerts_refresh" for row in data["runs"])
    assert any(row["job_key"] == "governance_refresh" for row in data["runs"])


def test_batch_due_runner_executes_scheduled_jobs() -> None:
    client = _build_client()
    headers = _auth_headers()

    response = client.post("/api/intelicoop/batch/ejecutar-programados", headers=headers, json={})

    assert response.status_code == 201
    body = response.json()
    assert set(body["executed_jobs"]) == {
        "foundation_refresh",
        "segmentation_refresh",
        "scoring_refresh",
        "alerts_refresh",
        "governance_refresh",
    }
    assert len(body["runs"]) == 5

    runs = client.get("/api/intelicoop/batch/runs?limit=10", headers=headers)
    assert runs.status_code == 200
    assert len(runs.json()) == 5
