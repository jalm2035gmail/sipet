from __future__ import annotations

import os
import sys
import types

import pytest
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient


os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("SQLITE_DB_PATH", "/tmp/sipet_intelicoop_phase7.sqlite3")
pytestmark = pytest.mark.filterwarnings("ignore:The 'app' shortcut is now deprecated.*:DeprecationWarning")


fake_main = types.ModuleType("fastapi_modulo.main")


def _fake_render_backend_page(
    request: Request,
    title: str,
    description: str = "",
    content: str = "",
    **_: object,
) -> HTMLResponse:
    html = f"<html><head><title>{title}</title></head><body>{content}</body></html>"
    return HTMLResponse(content=html)


def _fake_get_user_app_access(request: Request) -> list[str]:
    raw = request.headers.get("x-app-access", "")
    return [item.strip() for item in raw.split(",") if item.strip()]


def _fake_is_admin_or_superadmin(request: Request) -> bool:
    return getattr(request.state, "user_role", "").strip().lower() in {
        "administrador",
        "admin",
        "superadministrador",
        "superadmin",
    }


fake_main.render_backend_page = _fake_render_backend_page
fake_main._get_user_app_access = _fake_get_user_app_access
fake_main.is_admin_or_superadmin = _fake_is_admin_or_superadmin
sys.modules["fastapi_modulo.main"] = fake_main


from fastapi_modulo.core.db import MAIN, engine
import fastapi_modulo.modulos.intelicoop.controladores.intelicoop as intelicoop_controller
from fastapi_modulo.modulos.intelicoop.controladores.intelicoop import require_intelicoop_access, router
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_db_models import (
    IntelicoopCampania,
    IntelicoopContactoCampania,
    IntelicoopCredito,
    IntelicoopCuenta,
    IntelicoopHistorialPago,
    IntelicoopModelVersionRegistry,
    IntelicoopProspecto,
    IntelicoopScoringResult,
    IntelicoopScoringTraza,
    IntelicoopSeguimientoCampania,
    IntelicoopSocio,
    IntelicoopTransaccion,
)


INTELICOOP_TABLES = [
    IntelicoopSocio.__table__,
    IntelicoopCredito.__table__,
    IntelicoopHistorialPago.__table__,
    IntelicoopCuenta.__table__,
    IntelicoopTransaccion.__table__,
    IntelicoopCampania.__table__,
    IntelicoopProspecto.__table__,
    IntelicoopContactoCampania.__table__,
    IntelicoopSeguimientoCampania.__table__,
    IntelicoopScoringResult.__table__,
    IntelicoopScoringTraza.__table__,
    IntelicoopModelVersionRegistry.__table__,
]


def _build_client() -> TestClient:
    app = FastAPI()

    @app.middleware("http")
    async def inject_test_session(request: Request, call_next):
        request.state.user_name = request.headers.get("x-user", "tester")
        request.state.user_role = request.headers.get("x-role", "usuario")
        request.state.tenant_id = "test"
        return await call_next(request)

    app.include_router(router)
    def _fake_require_access(request: Request) -> None:
        role = request.headers.get("x-role", "").strip().lower()
        if role in {"admin", "administrador", "superadmin", "superadministrador"}:
            return
        raw = request.headers.get("x-app-access", "")
        access = {item.strip() for item in raw.split(",") if item.strip()}
        if "Intelicoop" not in access:
            from fastapi import HTTPException
            raise HTTPException(status_code=403, detail="Acceso restringido a Intelicoop")

    app.dependency_overrides[require_intelicoop_access] = _fake_require_access
    return TestClient(app)


def _auth_headers(*access: str, role: str = "usuario") -> dict[str, str]:
    headers = {"x-role": role, "x-user": "intelicoop.test"}
    if access:
        headers["x-app-access"] = ",".join(access)
    return headers


def setup_function() -> None:
    MAIN.metadata.drop_all(bind=engine, tables=INTELICOOP_TABLES, checkfirst=True)
    MAIN.metadata.create_all(bind=engine, tables=INTELICOOP_TABLES, checkfirst=True)


def test_intelicoop_html_requires_access() -> None:
    client = _build_client()

    response = client.get("/inicio/intelicoop")

    assert response.status_code == 403
    assert response.json()["detail"] == "Acceso restringido a Intelicoop"


def test_intelicoop_html_renders_with_access(monkeypatch: pytest.MonkeyPatch) -> None:
    client = _build_client()
    monkeypatch.setattr(intelicoop_controller, "render_backend_page_html", _fake_render_backend_page)

    response = client.get("/inicio/intelicoop", headers=_auth_headers("Intelicoop", role="admin"))

    assert response.status_code == 200
    assert "Intelicoop" in response.text
    assert "intelicoop-root" in response.text


def test_intelicoop_api_blocks_without_access() -> None:
    client = _build_client()

    response = client.get("/api/intelicoop/socios")

    assert response.status_code == 403
    assert response.json()["detail"] == "Acceso restringido a Intelicoop"


def test_intelicoop_core_flow_persists_data_and_scoring() -> None:
    client = _build_client()
    headers = _auth_headers("Intelicoop")

    socio_response = client.post(
        "/api/intelicoop/socios",
        headers=headers,
        json={
            "nombre": "Ana Perez",
            "email": "ana@example.com",
            "telefono": "555-0101",
            "direccion": "Zona 1",
            "segmento": "hormiga",
        },
    )
    assert socio_response.status_code == 201
    socio_id = socio_response.json()["id"]

    credito_response = client.post(
        "/api/intelicoop/creditos",
        headers=headers,
        json={
            "socio_id": socio_id,
            "monto": 1500,
            "plazo": 12,
            "ingreso_mensual": 5000,
            "deuda_actual": 800,
            "antiguedad_meses": 24,
            "estado": "solicitado",
        },
    )
    assert credito_response.status_code == 201
    credito_payload = credito_response.json()
    credito_id = credito_payload["credito"]["id"]
    scoring = credito_payload["scoring"]
    assert scoring["credito_id"] == credito_id
    assert scoring["model_version"] == "intelicoop_scoring_v1"
    assert scoring["confianza"] is not None
    assert scoring["motor"] in {"reglas", "modelo_ml"}
    assert scoring["traza_id"] is not None
    assert scoring["traza_version"] == "intelicoop_traza_v1"
    assert scoring["explicacion_json"]["razones"]
    assert scoring["explicacion_json"]["reglas_aplicadas"]

    traza_response = client.get(f"/api/intelicoop/scoring/{scoring['id']}/traza", headers=headers)
    assert traza_response.status_code == 200
    traza = traza_response.json()
    assert traza["scoring_result_id"] == scoring["id"]
    assert traza["inputs"]["ingreso_mensual"] == 5000.0
    assert traza["outputs"]["score"] == scoring["score"]
    assert traza["razones"]
    assert traza["reglas_aplicadas"]

    pago_response = client.post(
        "/api/intelicoop/creditos/pagos",
        headers=headers,
        json={"credito_id": credito_id, "monto": 250},
    )
    assert pago_response.status_code == 201

    detalle_response = client.get(f"/api/intelicoop/creditos/{credito_id}/detalle", headers=headers)
    assert detalle_response.status_code == 200
    detalle = detalle_response.json()
    assert detalle["id"] == credito_id
    assert detalle["resumen_pagos"]["monto_pagado"] == 250.0

    cuenta_response = client.post(
        "/api/intelicoop/ahorros/cuentas",
        headers=headers,
        json={"socio_id": socio_id, "tipo": "ahorro", "saldo": 1000},
    )
    assert cuenta_response.status_code == 201
    cuenta_id = cuenta_response.json()["id"]

    tx_response = client.post(
        "/api/intelicoop/ahorros/transacciones",
        headers=headers,
        json={"cuenta_id": cuenta_id, "tipo": "deposito", "monto": 300},
    )
    assert tx_response.status_code == 201

    campana_response = client.post(
        "/api/intelicoop/campanas",
        headers=headers,
        json={
            "nombre": "Campana Primavera",
            "tipo": "Colocacion",
            "fecha_inicio": "2026-03-01T00:00:00",
            "fecha_fin": "2026-03-31T00:00:00",
            "estado": "activa",
        },
    )
    assert campana_response.status_code == 201

    prospecto_response = client.post(
        "/api/intelicoop/prospectos",
        headers=headers,
        json={
            "nombre": "Carlos Ruiz",
            "telefono": "555-0202",
            "direccion": "Zona 4",
            "fuente": "referido",
            "score_propension": 0.7,
        },
    )
    assert prospecto_response.status_code == 201

    resumen_response = client.get("/api/intelicoop/scoring/resumen", headers=headers)
    assert resumen_response.status_code == 200
    resumen = resumen_response.json()
    assert resumen["total_inferencias"] >= 1
    assert resumen["recientes"][0]["model_version"] == "intelicoop_scoring_v1"

    dashboard_response = client.get("/api/intelicoop/dashboard/resumen", headers=headers)
    assert dashboard_response.status_code == 200
    dashboard = dashboard_response.json()
    assert dashboard["socios"] == 1
    assert dashboard["creditos"] == 1
    assert dashboard["campanas"] == 1
    assert dashboard["prospectos"] == 1
    assert dashboard["scoring_total"] >= 1


def test_admin_can_access_intelicoop_without_checkbox() -> None:
    client = _build_client()

    response = client.get("/api/intelicoop/socios", headers=_auth_headers(role="admin"))

    assert response.status_code == 200
    assert response.json() == []


def test_scoring_evaluar_persists_version_and_trace() -> None:
    client = _build_client()
    headers = _auth_headers("Intelicoop")

    response = client.post(
        "/api/intelicoop/scoring/evaluar",
        headers=headers,
        json={
            "solicitud_id": "sol-operativa-001",
            "ingreso_mensual": 6200,
            "deuda_actual": 900,
            "antiguedad_meses": 30,
        },
    )

    assert response.status_code == 201
    body = response.json()
    assert body["solicitud_id"] == "sol-operativa-001"
    assert body["model_version"] == "intelicoop_scoring_v1"
    assert body["confianza"] is not None
    assert body["motor"] in {"reglas", "modelo_ml"}
    assert body["traza_id"] is not None
    assert body["explicacion_json"]["inputs"]["ingreso_mensual"] == 6200.0

    traza_response = client.get(f"/api/intelicoop/scoring/{body['id']}/traza", headers=headers)
    assert traza_response.status_code == 200
    traza = traza_response.json()
    assert traza["model_version"] == "intelicoop_scoring_v1"
    assert traza["traza_version"] == "intelicoop_traza_v1"
    assert traza["inputs"]["deuda_actual"] == 900.0
    assert traza["outputs"]["recomendacion"] == body["recomendacion"]


def test_segmentacion_resumen_calculates_segments_and_propensities() -> None:
    client = _build_client()
    headers = _auth_headers("Intelicoop")

    socio_a = client.post(
        "/api/intelicoop/socios",
        headers=headers,
        json={
            "nombre": "Socio Integral",
            "email": "integral@example.com",
            "telefono": "555-1000",
            "direccion": "Centro",
            "segmento": "gran_ahorrador",
        },
    )
    assert socio_a.status_code == 201
    socio_a_id = socio_a.json()["id"]

    socio_b = client.post(
        "/api/intelicoop/socios",
        headers=headers,
        json={
            "nombre": "Socio Riesgo",
            "email": "riesgo@example.com",
            "telefono": "555-2000",
            "direccion": "Norte",
            "segmento": "inactivo",
        },
    )
    assert socio_b.status_code == 201
    socio_b_id = socio_b.json()["id"]

    cuenta_a = client.post(
        "/api/intelicoop/ahorros/cuentas",
        headers=headers,
        json={"socio_id": socio_a_id, "tipo": "ahorro", "saldo": 6500},
    )
    assert cuenta_a.status_code == 201
    cuenta_a_id = cuenta_a.json()["id"]

    movimiento_a = client.post(
        "/api/intelicoop/ahorros/transacciones",
        headers=headers,
        json={"cuenta_id": cuenta_a_id, "tipo": "deposito", "monto": 1200},
    )
    assert movimiento_a.status_code == 201

    credito_a = client.post(
        "/api/intelicoop/creditos",
        headers=headers,
        json={
            "socio_id": socio_a_id,
            "monto": 3000,
            "plazo": 12,
            "ingreso_mensual": 9000,
            "deuda_actual": 900,
            "antiguedad_meses": 36,
            "estado": "aprobado",
        },
    )
    assert credito_a.status_code == 201

    campana = client.post(
        "/api/intelicoop/campanas",
        headers=headers,
        json={
            "nombre": "Campana Elite",
            "tipo": "Upsell",
            "fecha_inicio": "2026-03-01T00:00:00",
            "fecha_fin": "2026-03-31T00:00:00",
            "estado": "activa",
        },
    )
    assert campana.status_code == 201
    campana_id = campana.json()["id"]

    contacto_a = client.post(
        "/api/intelicoop/campanas/contactos",
        headers=headers,
        json={
            "campania_id": campana_id,
            "socio_id": socio_a_id,
            "ejecutivo_id": "ejecutivo_1",
            "canal": "whatsapp",
            "estado_contacto": "contactado",
        },
    )
    assert contacto_a.status_code == 201

    seguimiento_a = client.post(
        "/api/intelicoop/campanas/seguimientos",
        headers=headers,
        json={
            "campania_id": campana_id,
            "socio_id": socio_a_id,
            "lista": "premium",
            "etapa": "cerrado",
            "conversion": True,
            "monto_colocado": 1800,
        },
    )
    assert seguimiento_a.status_code == 201

    credito_b = client.post(
        "/api/intelicoop/creditos",
        headers=headers,
        json={
            "socio_id": socio_b_id,
            "monto": 2500,
            "plazo": 10,
            "ingreso_mensual": 3200,
            "deuda_actual": 2400,
            "antiguedad_meses": 4,
            "estado": "mora",
        },
    )
    assert credito_b.status_code == 201

    prospecto = client.post(
        "/api/intelicoop/prospectos",
        headers=headers,
        json={
            "nombre": "Prospecto Alto",
            "telefono": "555-3000",
            "direccion": "Sur",
            "fuente": "referido",
            "score_propension": 0.91,
        },
    )
    assert prospecto.status_code == 201

    response = client.get("/api/intelicoop/segmentacion/resumen", headers=headers)

    assert response.status_code == 200
    body = response.json()
    assert body["resumen"]["total_socios"] == 2
    assert body["segmentos"]
    assert body["top_oportunidades"]
    assert body["alertas_tempranas"]
    assert body["prospectos"][0]["score_propension"] == 0.91

    socios = {row["socio_nombre"]: row for row in body["socios"]}
    assert socios["Socio Integral"]["segmento_automatico"] in {"integral_fiel", "crecimiento"}
    assert socios["Socio Integral"]["comercial_score"] > socios["Socio Riesgo"]["comercial_score"]
    assert socios["Socio Riesgo"]["segmento_automatico"] == "alerta_temprana"
    assert socios["Socio Riesgo"]["riesgo_temprano_score"] >= 0.5
