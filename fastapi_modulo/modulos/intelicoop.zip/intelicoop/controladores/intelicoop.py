from __future__ import annotations

import os
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi_modulo.modulos_sipet.web.servicios.module_tools import (
    read_text_file,
    render_backend_page_html,
    require_app_access,
    text_asset_response,
)

from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_models import (
    CampaniaCreate,
    ContactoCampaniaCreate,
    CuentaCreate,
    CreditoCreate,
    HistorialPagoCreate,
    ProspectoCreate,
    ScoringEvaluateInput,
    SeguimientoCampaniaCreate,
    SocioCreate,
    TransaccionCreate,
)
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_scoring import evaluate_scoring_v2, summarize_scoring
from fastapi_modulo.modulos.intelicoop.modelos.intelicoop_store import (
    create_campana,
    create_contacto_campania,
    create_cuenta,
    create_credito,
    create_historial_pago,
    create_prospecto,
    create_scoring_result,
    create_seguimiento_campania,
    create_socio,
    create_transaccion,
    get_basic_catalogs,
    get_ahorros_resumen,
    get_batch_overview,
    get_credito,
    get_credito_detail,
    get_dashboard_resumen,
    get_cohortes,
    get_descriptive_analytics,
    get_foundation_overview,
    get_governance_overview,
    get_segmentation_propensity_summary,
    get_scoring_trace,
    get_tendencias,
    list_campanas,
    list_contactos_campania,
    list_cuentas,
    list_creditos,
    list_historial_pagos,
    list_prospectos,
    list_batch_alerts,
    list_batch_runs,
    list_scoring_results,
    list_seguimientos_campania,
    list_socios,
    list_transacciones,
    materialize_foundation_cut,
    run_batch_job,
    run_due_batch_jobs,
    run_governance_refresh,
)

def require_intelicoop_access(request: Request) -> None:
    require_app_access(request, "Intelicoop", "Acceso restringido a Intelicoop")


router = APIRouter(dependencies=[Depends(require_intelicoop_access)])
INTELICOOP_TEMPLATE_PATH = os.path.join("fastapi_modulo", "modulos", "intelicoop", "vistas", "intelicoop.html")
INTELICOOP_JS_PATH = os.path.join("fastapi_modulo", "modulos", "intelicoop", "static", "js", "intelicoop.js")
@router.get("/intelicoop", response_class=HTMLResponse)
def intelicoop_redirect() -> RedirectResponse:
    return RedirectResponse(url="/inicio/intelicoop", status_code=307)


@router.get("/inicio/intelicoop", response_class=HTMLResponse)
def intelicoop_page(request: Request):
    content = read_text_file(INTELICOOP_TEMPLATE_PATH, "<p>No se pudo cargar la vista de Intelicoop.</p>")
    return render_backend_page_html(
        request,
        title="Intelicoop",
        description="Modulo SIPET para socios, creditos, ahorros, campanas y scoring.",
        content=content,
        show_page_header=False,
    )


@router.get("/api/intelicoop/assets/intelicoop.js")
def intelicoop_js_asset() -> Response:
    return text_asset_response(
        INTELICOOP_JS_PATH,
        media_type="application/javascript",
        fallback="console.error('Intelicoop JS no disponible');",
    )


@router.get("/api/intelicoop/socios")
def api_list_socios():
    return JSONResponse(list_socios())


@router.post("/api/intelicoop/socios")
def api_create_socio(payload: SocioCreate):
    try:
        return JSONResponse(create_socio(payload.model_dump()), status_code=201)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/api/intelicoop/creditos")
def api_list_creditos():
    return JSONResponse(list_creditos())


@router.get("/api/intelicoop/creditos/{credito_id}")
def api_get_credito(credito_id: int):
    credito = get_credito(credito_id)
    if not credito:
        raise HTTPException(status_code=404, detail="Credito no encontrado.")
    return JSONResponse(credito)


@router.get("/api/intelicoop/creditos/{credito_id}/detalle")
def api_get_credito_detail(credito_id: int):
    credito = get_credito_detail(credito_id)
    if not credito:
        raise HTTPException(status_code=404, detail="Credito no encontrado.")
    return JSONResponse(credito)


@router.post("/api/intelicoop/creditos")
def api_create_credito(payload: CreditoCreate):
    try:
        credito = create_credito(payload.model_dump())
        scoring_eval = evaluate_scoring_v2(
            ingreso_mensual=payload.ingreso_mensual,
            deuda_actual=payload.deuda_actual,
            antiguedad_meses=payload.antiguedad_meses,
            solicitud_id=f"cred-{credito['id']}",
            socio_id=credito["socio_id"],
            credito_id=credito["id"],
        )
        scoring = create_scoring_result(
            {
                "ingreso_mensual": payload.ingreso_mensual,
                "deuda_actual": payload.deuda_actual,
                "antiguedad_meses": payload.antiguedad_meses,
                **scoring_eval,
            }
        )
        return JSONResponse({"credito": credito, "scoring": scoring}, status_code=201)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/api/intelicoop/creditos/{credito_id}/pagos")
def api_list_credito_pagos(credito_id: int):
    return JSONResponse(list_historial_pagos(credito_id))


@router.post("/api/intelicoop/creditos/pagos")
def api_create_credito_pago(payload: HistorialPagoCreate):
    try:
        return JSONResponse(create_historial_pago(payload.model_dump()), status_code=201)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/api/intelicoop/ahorros/resumen")
def api_ahorros_resumen():
    return JSONResponse(get_ahorros_resumen())


@router.get("/api/intelicoop/ahorros/cuentas")
def api_list_cuentas():
    return JSONResponse(list_cuentas())


@router.post("/api/intelicoop/ahorros/cuentas")
def api_create_cuenta(payload: CuentaCreate):
    try:
        return JSONResponse(create_cuenta(payload.model_dump()), status_code=201)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/api/intelicoop/ahorros/transacciones")
def api_list_transacciones():
    return JSONResponse(list_transacciones())


@router.post("/api/intelicoop/ahorros/transacciones")
def api_create_transaccion(payload: TransaccionCreate):
    try:
        return JSONResponse(create_transaccion(payload.model_dump()), status_code=201)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/api/intelicoop/campanas")
def api_list_campanas():
    return JSONResponse(list_campanas())


@router.post("/api/intelicoop/campanas")
def api_create_campana(payload: CampaniaCreate):
    return JSONResponse(create_campana(payload.model_dump()), status_code=201)


@router.get("/api/intelicoop/campanas/contactos")
def api_list_contactos_campania():
    return JSONResponse(list_contactos_campania())


@router.post("/api/intelicoop/campanas/contactos")
def api_create_contacto_campania(payload: ContactoCampaniaCreate):
    try:
        return JSONResponse(create_contacto_campania(payload.model_dump()), status_code=201)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/api/intelicoop/campanas/seguimientos")
def api_list_seguimientos_campania():
    return JSONResponse(list_seguimientos_campania())


@router.post("/api/intelicoop/campanas/seguimientos")
def api_create_seguimiento_campania(payload: SeguimientoCampaniaCreate):
    try:
        return JSONResponse(create_seguimiento_campania(payload.model_dump()), status_code=201)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/api/intelicoop/prospectos")
def api_list_prospectos():
    return JSONResponse(list_prospectos())


@router.post("/api/intelicoop/prospectos")
def api_create_prospecto(payload: ProspectoCreate):
    return JSONResponse(create_prospecto(payload.model_dump()), status_code=201)


@router.post("/api/intelicoop/scoring/evaluar")
def api_scoring_evaluar(payload: ScoringEvaluateInput):
    scoring_eval = evaluate_scoring_v2(
        ingreso_mensual=payload.ingreso_mensual,
        deuda_actual=payload.deuda_actual,
        antiguedad_meses=payload.antiguedad_meses,
        solicitud_id=payload.solicitud_id or f"sol-{uuid.uuid4().hex[:10]}",
        socio_id=payload.socio_id,
        credito_id=payload.credito_id,
    )
    result = create_scoring_result(
        {
            "ingreso_mensual": payload.ingreso_mensual,
            "deuda_actual": payload.deuda_actual,
            "antiguedad_meses": payload.antiguedad_meses,
            **scoring_eval,
        }
    )
    return JSONResponse(result, status_code=201)


@router.get("/api/intelicoop/scoring/{scoring_result_id}/traza")
def api_scoring_traza(scoring_result_id: int):
    result = get_scoring_trace(scoring_result_id)
    if not result:
        raise HTTPException(status_code=404, detail="Traza de scoring no encontrada.")
    return JSONResponse(result)


@router.get("/api/intelicoop/scoring/resumen")
def api_scoring_resumen():
    return JSONResponse(summarize_scoring(list_scoring_results()))


@router.get("/api/intelicoop/dashboard/resumen")
def api_dashboard_resumen():
    return JSONResponse(get_dashboard_resumen())


@router.get("/api/intelicoop/catalogos/basicos")
def api_basic_catalogs():
    return JSONResponse(get_basic_catalogs())


@router.get("/api/intelicoop/fundamentos/resumen")
def api_foundation_overview():
    return JSONResponse(get_foundation_overview())


@router.post("/api/intelicoop/fundamentos/materializar")
def api_foundation_materialize(cut_type: str = "daily_close"):
    return JSONResponse(materialize_foundation_cut(cut_type=cut_type), status_code=201)


@router.get("/api/intelicoop/analitica/resumen")
def api_analitica_resumen():
    return JSONResponse(get_descriptive_analytics())


@router.get("/api/intelicoop/analitica/tendencias")
def api_analitica_tendencias(kpi_key: str = "imor_pct", n_cuts: int = 12):
    return JSONResponse(get_tendencias(kpi_key=kpi_key, n_cuts=n_cuts))


@router.get("/api/intelicoop/analitica/cohortes")
def api_analitica_cohortes(dimension: str = ""):
    return JSONResponse(get_cohortes(dimension=dimension or None))


@router.get("/api/intelicoop/segmentacion/resumen")
def api_segmentacion_resumen():
    return JSONResponse(get_segmentation_propensity_summary())


@router.get("/api/intelicoop/batch/resumen")
def api_batch_resumen():
    return JSONResponse(get_batch_overview())


@router.get("/api/intelicoop/batch/runs")
def api_batch_runs(limit: int = 20):
    return JSONResponse(list_batch_runs(limit=limit))


@router.get("/api/intelicoop/batch/alertas")
def api_batch_alertas(limit: int = 20):
    return JSONResponse(list_batch_alerts(limit=limit))


@router.post("/api/intelicoop/batch/ejecutar")
def api_batch_ejecutar(job_key: str):
    return JSONResponse(run_batch_job(job_key=job_key, trigger_type="manual"), status_code=201)


@router.post("/api/intelicoop/batch/ejecutar-programados")
def api_batch_ejecutar_programados():
    return JSONResponse(run_due_batch_jobs(), status_code=201)


@router.get("/api/intelicoop/gobernanza/resumen")
def api_gobernanza_resumen():
    return JSONResponse(get_governance_overview())


@router.post("/api/intelicoop/gobernanza/refresh")
def api_gobernanza_refresh():
    return JSONResponse(run_governance_refresh(actor="manual"), status_code=201)
